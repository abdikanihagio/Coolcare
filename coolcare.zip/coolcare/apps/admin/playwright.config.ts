import { defineConfig, devices } from '@playwright/test';

/**
 * Requires the API running with a seeded database. Set ADMIN_EMAIL / ADMIN_PASSWORD
 * to the seeded super admin (SEED_ADMIN_EMAIL / SEED_ADMIN_PASSWORD).
 */
export default defineConfig({
  testDir: './e2e',
  timeout: 30_000,
  use: { baseURL: process.env.ADMIN_URL ?? 'http://localhost:3000', trace: 'retain-on-failure' },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['Pixel 7'] } },
  ],
  webServer: process.env.ADMIN_URL
    ? undefined
    : { command: 'npm run dev', url: 'http://localhost:3000/login', reuseExistingServer: true, timeout: 120_000 },
});
