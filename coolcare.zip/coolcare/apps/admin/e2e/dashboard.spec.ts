import { expect, test } from '@playwright/test';

const email = process.env.ADMIN_EMAIL ?? 'admin@coolcare.so';
const password = process.env.ADMIN_PASSWORD ?? '';

test.describe('CoolCare dashboard', () => {
  test('redirects to login when signed out', async ({ page }) => {
    await page.goto('/bookings');
    await expect(page).toHaveURL(/\/login$/);
    await expect(page.getByRole('heading', { name: 'Sign in to CoolCare' })).toBeVisible();
  });

  test('rejects a wrong password with a clear message', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Email or phone').fill(email);
    await page.getByLabel('Password').fill('wrong-password-1');
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page.getByRole('alert')).toContainText('Incorrect');
  });

  test('signs in and navigates the main sections', async ({ page }) => {
    test.skip(!password, 'Set ADMIN_PASSWORD to run authenticated tests');
    await page.goto('/login');
    await page.getByLabel('Email or phone').fill(email);
    await page.getByLabel('Password').fill(password);
    await page.getByRole('button', { name: 'Sign in' }).click();
    await expect(page.getByRole('heading', { name: 'Today in Mogadishu' })).toBeVisible();

    for (const [link, heading] of [
      ['Bookings', 'Bookings'],
      ['Customers', 'Customers'],
      ['Technicians', 'Technicians'],
      ['Invoices', 'Invoices'],
    ]) {
      const nav = page.getByRole('navigation', { name: 'Main' });
      if (!(await nav.isVisible())) await page.getByRole('button', { name: 'Open menu' }).click();
      await page.getByRole('navigation', { name: 'Main' }).getByRole('link', { name: link }).first().click();
      await expect(page.getByRole('heading', { level: 1, name: heading })).toBeVisible();
    }
  });

  test('switches the interface to Somali', async ({ page }) => {
    await page.goto('/login');
    await page.getByRole('button', { name: 'Soomaali' }).click();
    await expect(page.getByRole('heading', { name: 'Gal CoolCare' })).toBeVisible();
    await expect(page.locator('html')).toHaveAttribute('lang', 'so');
  });
});
