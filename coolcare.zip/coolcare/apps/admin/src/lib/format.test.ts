import { describe, expect, it } from 'vitest';
import { day, initials, mapsUrl, money, todayIso } from './format';
import { translate } from './i18n-core';
import en from './locales/en.json';
import so from './locales/so.json';

describe('format', () => {
  it('formats money', () => {
    expect(money('45.5')).toBe('$45.50');
    expect(money(null)).toBe('$0.00');
  });

  it('formats date-only values without shifting the day', () => {
    expect(day('2026-10-22T00:00:00.000Z')).toBe('22 Oct 2026');
  });

  it('computes today in Mogadishu', () => {
    expect(todayIso('Africa/Mogadishu', new Date('2026-10-22T22:30:00Z'))).toBe('2026-10-23');
  });

  it('builds initials and map links', () => {
    expect(initials('Amina Hassan Ali')).toBe('AH');
    expect(mapsUrl(2.03, 45.3)).toContain('2.03,45.3');
  });
});

describe('translations', () => {
  it('has a Somali string for every English key', () => {
    const missing = Object.keys(en).filter((k) => !(k in so) || !(so as Record<string, string>)[k]);
    expect(missing).toEqual([]);
  });

  it('interpolates variables and falls back to English', () => {
    expect(translate('so', 'common.page', { page: 2, pages: 5 })).toBe('Bogga 2 ee 5');
    expect(translate('so', 'missing.key')).toBe('missing.key');
  });
});
