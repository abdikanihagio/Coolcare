'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api, loadSession, saveSession, type Session, type SessionUser } from './api';

type Role = SessionUser['role'];

interface AuthValue {
  user: SessionUser | null;
  ready: boolean;
  signIn: (identifier: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  can: (...roles: Role[]) => boolean;
}

const AuthContext = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const sync = () => setSession(loadSession());
    sync();
    setReady(true);
    window.addEventListener('coolcare:session', sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener('coolcare:session', sync);
      window.removeEventListener('storage', sync);
    };
  }, []);

  const signIn = useCallback(async (identifier: string, password: string) => {
    const res = await api<{ user: SessionUser; tokens: { accessToken: string; refreshToken: string } }>('/auth/admin/login', {
      body: { identifier, password },
    });
    saveSession({ user: res.user, accessToken: res.tokens.accessToken, refreshToken: res.tokens.refreshToken });
  }, []);

  const signOut = useCallback(async () => {
    const current = loadSession();
    if (current) await api('/auth/logout', { body: { refreshToken: current.refreshToken } }).catch(() => undefined);
    saveSession(null);
  }, []);

  const can = useCallback(
    (...roles: Role[]) => !!session && (session.user.role === 'SUPER_ADMIN' || roles.includes(session.user.role)),
    [session],
  );

  const value = useMemo(() => ({ user: session?.user ?? null, ready, signIn, signOut, can }), [session, ready, signIn, signOut, can]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
