'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { DICTS, translate, type Locale } from './i18n-core';

export type { Locale };
export { translate };
/** Text direction per locale. Both current locales are LTR; add RTL locales (e.g. 'ar') here. */
export const LOCALE_DIR: Record<Locale, 'ltr' | 'rtl'> = { en: 'ltr', so: 'ltr' };
export const LOCALE_NAMES: Record<Locale, string> = { en: 'English', so: 'Soomaali' };
const STORAGE_KEY = 'coolcare.admin.locale';

interface I18nValue {
  locale: Locale;
  setLocale: (l: Locale) => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
}

const I18nContext = createContext<I18nValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>('en');

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY) as Locale | null;
      if (saved && saved in DICTS) setLocaleState(saved);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = LOCALE_DIR[locale];
  }, [locale]);

  const setLocale = useCallback((l: Locale) => {
    setLocaleState(l);
    try {
      window.localStorage.setItem(STORAGE_KEY, l);
    } catch {
      /* ignore */
    }
  }, []);

  const t = useCallback((key: string, vars?: Record<string, string | number>) => translate(locale, key, vars), [locale]);
  const value = useMemo(() => ({ locale, setLocale, t }), [locale, setLocale, t]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used inside I18nProvider');
  return ctx;
}

/** Picks the Somali or English variant of a bilingual record field. */
export function pick(row: object | null | undefined, field: string, locale: Locale): string {
  if (!row) return '';
  const r = row as Record<string, unknown>;
  const so = r[`${field}So`];
  const en = r[`${field}En`];
  return String((locale === 'so' && so ? so : en) ?? '');
}
