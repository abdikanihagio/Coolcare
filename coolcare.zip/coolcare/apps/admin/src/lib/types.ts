// Shapes returned by the CoolCare API (Decimal fields arrive as strings).

export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'ASSIGNED' | 'ON_THE_WAY' | 'IN_PROGRESS' | 'AWAITING_APPROVAL' | 'COMPLETED' | 'CANCELLED';
export type Slot = 'MORNING' | 'AFTERNOON' | 'EVENING';

export interface Category {
  id: string;
  slug: string;
  nameEn: string;
  nameSo: string;
  descriptionEn?: string | null;
  descriptionSo?: string | null;
  icon: string;
  sortOrder: number;
  isActive: boolean;
  services?: Service[];
}

export interface Service {
  id: string;
  categoryId: string;
  slug: string;
  nameEn: string;
  nameSo: string;
  descriptionEn?: string | null;
  descriptionSo?: string | null;
  basePrice: string;
  priceType: 'FIXED' | 'STARTING_FROM' | 'INSPECTION_REQUIRED';
  durationMinutes: number;
  isActive: boolean;
  sortOrder: number;
}

export interface Technician {
  id: string;
  fullName: string;
  phone: string;
  email?: string | null;
  branchId?: string | null;
  specialties: string[];
  status: 'ACTIVE' | 'ON_LEAVE' | 'INACTIVE';
  isAvailable: boolean;
  photoUrl?: string | null;
  rating: string;
  jobsCompleted: number;
  notes?: string | null;
  activeJobs?: number;
  jobsOnDate?: number;
}

export interface Customer {
  id: string;
  fullName: string;
  phone: string;
  email?: string | null;
  status: 'ACTIVE' | 'SUSPENDED';
  locale: 'en' | 'so';
  phoneVerified: boolean;
  createdAt: string;
  lastLoginAt?: string | null;
  bookingsCount?: number;
}

export interface Address {
  id: string;
  label: string;
  district: string;
  neighborhood?: string | null;
  street?: string | null;
  landmark?: string | null;
  details?: string | null;
  latitude?: string | null;
  longitude?: string | null;
  isDefault: boolean;
}

export interface QuoteItem {
  id?: string;
  kind: 'LABOR' | 'PART' | 'OTHER';
  description: string;
  quantity: string | number;
  unitPrice: string | number;
  total?: string;
}

export interface Quote {
  id: string;
  number: string;
  bookingId: string;
  status: 'DRAFT' | 'SENT' | 'ACCEPTED' | 'REJECTED' | 'EXPIRED';
  currency: string;
  subtotal: string;
  discount: string;
  taxRate: string;
  taxAmount: string;
  total: string;
  notes?: string | null;
  validUntil?: string | null;
  sentAt?: string | null;
  respondedAt?: string | null;
  rejectionReason?: string | null;
  createdAt: string;
  items: QuoteItem[];
  createdBy?: { fullName: string } | null;
  booking?: { id: string; reference: string; customer?: { fullName: string; phone: string } };
}

export interface Payment {
  id: string;
  invoiceId: string;
  amount: string;
  currency: string;
  method: string;
  status: 'PENDING' | 'COMPLETED' | 'FAILED' | 'REFUNDED';
  reference?: string | null;
  payerPhone?: string | null;
  notes?: string | null;
  paidAt: string;
  receivedBy?: { fullName: string } | null;
  invoice?: { id: string; number: string; customer: { fullName: string; phone: string }; booking: { reference: string } };
}

export interface Invoice {
  id: string;
  number: string;
  bookingId: string;
  customerId: string;
  currency: string;
  subtotal: string;
  discount: string;
  taxAmount: string;
  total: string;
  amountPaid: string;
  status: 'UNPAID' | 'PARTIALLY_PAID' | 'PAID' | 'VOID';
  issuedAt: string;
  dueAt?: string | null;
  payments?: Payment[];
  customer?: { id: string; fullName: string; phone: string; email?: string | null };
  booking?: { id: string; reference: string; service?: { nameEn: string; nameSo: string }; unitCount?: number };
  quote?: Quote | null;
  _count?: { payments: number };
}

export interface HistoryEntry {
  id: string;
  fromStatus: BookingStatus | null;
  toStatus: BookingStatus;
  note?: string | null;
  createdAt: string;
  changedBy?: { fullName: string; role: string } | null;
}

export interface Photo {
  id: string;
  url: string;
  kind: 'PROBLEM' | 'BEFORE' | 'AFTER';
  createdAt: string;
}

export interface Booking {
  id: string;
  reference: string;
  status: BookingStatus;
  priority: 'NORMAL' | 'URGENT' | 'EMERGENCY';
  scheduledDate: string;
  timeSlot: Slot;
  unitCount: number;
  problemDescription?: string | null;
  customerNotes?: string | null;
  internalNotes?: string | null;
  addressText: string;
  latitude?: string | null;
  longitude?: string | null;
  estimatedPrice?: string | null;
  cancelledReason?: string | null;
  rating?: number | null;
  review?: string | null;
  completedAt?: string | null;
  createdAt: string;
  customer?: { id: string; fullName: string; phone: string; email?: string | null; locale?: string };
  service?: Service & { category?: { nameEn: string; nameSo: string } };
  technician?: Technician | null;
  equipment?: { id: string; type: string; brand?: string | null; model?: string | null; capacity?: string | null } | null;
  history?: HistoryEntry[];
  photos?: Photo[];
  quotes?: Quote[];
  invoice?: Invoice | null;
  allowedTransitions?: BookingStatus[];
}

export interface StaffUser {
  id: string;
  fullName: string;
  phone: string;
  email: string | null;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'DISPATCHER' | 'ACCOUNTANT';
  status: 'ACTIVE' | 'SUSPENDED';
  lastLoginAt?: string | null;
  branchId?: string | null;
  branch?: { id: string; name: string } | null;
}

export interface Plan {
  id: string;
  nameEn: string;
  nameSo: string;
  descriptionEn?: string | null;
  descriptionSo?: string | null;
  price: string;
  currency: string;
  durationMonths: number;
  visitsPerYear: number;
  maxUnits: number;
  isActive: boolean;
  _count?: { subscriptions: number };
}

export interface Subscription {
  id: string;
  status: 'PENDING' | 'ACTIVE' | 'PAUSED' | 'CANCELLED' | 'EXPIRED';
  startDate: string;
  endDate: string;
  nextVisitDate?: string | null;
  visitsUsed: number;
  notes?: string | null;
  plan: Plan;
  customer: { id: string; fullName: string; phone: string };
  address?: Address | null;
}

export interface Branch {
  id: string;
  name: string;
  city: string;
  country: string;
  timezone: string;
  currency: string;
  phone?: string | null;
  address?: string | null;
  isActive: boolean;
  _count?: { technicians: number; bookings: number };
}
