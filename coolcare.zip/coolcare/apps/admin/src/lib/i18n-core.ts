import en from './locales/en.json';
import so from './locales/so.json';

export type Locale = 'en' | 'so';
export const DICTS: Record<Locale, Record<string, string>> = { en, so };

export function translate(locale: Locale, key: string, vars?: Record<string, string | number>): string {
  const template = DICTS[locale][key] ?? DICTS.en[key] ?? key;
  return vars ? template.replace(/\{(\w+)\}/g, (m, k: string) => (vars[k] !== undefined ? String(vars[k]) : m)) : template;
}
