/**
 * API client for the CoolCare dashboard. Stores the session in localStorage,
 * attaches the access token, and transparently refreshes it once on 401.
 */
export const API_URL = (process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api/v1').replace(/\/$/, '');

const SESSION_KEY = 'coolcare.admin.session';

export interface SessionUser {
  id: string;
  fullName: string;
  email: string | null;
  phone: string;
  role: 'SUPER_ADMIN' | 'ADMIN' | 'DISPATCHER' | 'ACCOUNTANT' | 'CUSTOMER';
  locale: 'en' | 'so';
}

export interface Session {
  user: SessionUser;
  accessToken: string;
  refreshToken: string;
}

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

export function loadSession(): Session | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as Session) : null;
  } catch {
    return null;
  }
}

export function saveSession(session: Session | null) {
  try {
    if (session) window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    else window.localStorage.removeItem(SESSION_KEY);
  } catch {
    /* storage unavailable */
  }
  window.dispatchEvent(new Event('coolcare:session'));
}

let refreshing: Promise<boolean> | null = null;

async function refresh(): Promise<boolean> {
  const session = loadSession();
  if (!session) return false;
  const res = await fetch(`${API_URL}/auth/refresh`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken: session.refreshToken }),
  }).catch(() => null);
  if (!res || !res.ok) {
    saveSession(null);
    return false;
  }
  const body = await res.json();
  saveSession({ user: { ...session.user, ...body.user }, accessToken: body.tokens.accessToken, refreshToken: body.tokens.refreshToken });
  return true;
}

function messageFrom(body: unknown, status: number): string {
  const msg = (body as { message?: unknown } | null)?.message;
  if (Array.isArray(msg)) return msg.join('. ');
  if (typeof msg === 'string') return msg;
  if (status === 0) return 'Cannot reach the server. Check your connection and try again.';
  return `Request failed (${status})`;
}

type Query = Record<string, string | number | boolean | undefined | null>;

export function withQuery(path: string, query?: Query): string {
  if (!query) return path;
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries(query)) {
    if (v !== undefined && v !== null && v !== '') params.set(k, String(v));
  }
  const qs = params.toString();
  return qs ? `${path}?${qs}` : path;
}

export async function api<T = unknown>(
  path: string,
  options: { method?: string; body?: unknown; query?: Query; form?: FormData } = {},
  retry = true,
): Promise<T> {
  const session = loadSession();
  const headers: Record<string, string> = {};
  if (session) headers.Authorization = `Bearer ${session.accessToken}`;
  if (options.body !== undefined) headers['Content-Type'] = 'application/json';

  let res: Response;
  try {
    res = await fetch(`${API_URL}${withQuery(path, options.query)}`, {
      method: options.method ?? (options.body !== undefined || options.form ? 'POST' : 'GET'),
      headers,
      body: options.form ?? (options.body !== undefined ? JSON.stringify(options.body) : undefined),
    });
  } catch {
    throw new ApiError(0, messageFrom(null, 0));
  }

  if (res.status === 401 && retry && session) {
    refreshing ??= refresh().finally(() => (refreshing = null));
    if (await refreshing) return api<T>(path, options, false);
  }

  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) throw new ApiError(res.status, messageFrom(body, res.status));
  return body as T;
}

export async function uploadImage(file: File, folder: 'bookings' | 'technicians' | 'services' | 'avatars') {
  const form = new FormData();
  form.append('file', file);
  return api<{ key: string; url: string }>(`/uploads/image?folder=${folder}`, { form, method: 'POST' });
}

export interface Paginated<T> {
  data: T[];
  meta: { page: number; pageSize: number; total: number; totalPages: number };
}
