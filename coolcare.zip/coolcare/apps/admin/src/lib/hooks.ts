'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from './api';
import type { Category, Technician } from './types';
import { useToast } from '@/components/ui/toast';

/** Wraps a mutation with toast feedback and cache invalidation. */
export function useAction<TVars, TResult = unknown>(
  fn: (vars: TVars) => Promise<TResult>,
  opts: { success?: string | ((r: TResult) => string); invalidate?: unknown[][]; onSuccess?: (r: TResult) => void } = {},
) {
  const qc = useQueryClient();
  const toast = useToast();
  return useMutation({
    mutationFn: fn,
    onSuccess: (r) => {
      opts.invalidate?.forEach((key) => qc.invalidateQueries({ queryKey: key }));
      qc.invalidateQueries({ queryKey: ['shell-counts'] });
      if (opts.success) toast(typeof opts.success === 'function' ? opts.success(r) : opts.success);
      opts.onSuccess?.(r);
    },
    onError: (err) => toast((err as Error).message, 'bad'),
  });
}

export function useCatalog() {
  return useQuery({ queryKey: ['admin-catalog'], queryFn: () => api<Category[]>('/admin/catalog/categories'), staleTime: 60_000 });
}

export function useTechnicians(date?: string) {
  return useQuery({
    queryKey: ['technicians-pick', date],
    queryFn: () => api<{ data: Technician[] }>('/admin/technicians', { query: { status: 'ACTIVE', pageSize: 100, date, sortBy: 'fullName', sortOrder: 'asc' } }),
    staleTime: 30_000,
  });
}

export function useSettings() {
  return useQuery({ queryKey: ['settings'], queryFn: () => api<Record<string, any>>('/settings'), staleTime: 60_000 });
}
