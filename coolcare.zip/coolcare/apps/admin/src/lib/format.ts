export const TIMEZONE = 'Africa/Mogadishu';

export function money(value: number | string | null | undefined, currency = 'USD', locale: 'en' | 'so' = 'en'): string {
  const n = Number(value ?? 0);
  try {
    return new Intl.NumberFormat(locale === 'so' ? 'so-SO' : 'en-US', { style: 'currency', currency, maximumFractionDigits: 2 }).format(n);
  } catch {
    return `${currency} ${n.toFixed(2)}`;
  }
}

/** Formats a date-only value (YYYY-MM-DD or ISO at UTC midnight) without timezone shifting. */
export function day(value: string | Date | null | undefined, locale: 'en' | 'so' = 'en'): string {
  if (!value) return '—';
  const iso = typeof value === 'string' ? value.slice(0, 10) : value.toISOString().slice(0, 10);
  const d = new Date(`${iso}T12:00:00Z`);
  return new Intl.DateTimeFormat(locale === 'so' ? 'so-SO' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(d);
}

/** Formats an instant in the company timezone. */
export function dateTime(value: string | Date | null | undefined, locale: 'en' | 'so' = 'en'): string {
  if (!value) return '—';
  return new Intl.DateTimeFormat(locale === 'so' ? 'so-SO' : 'en-GB', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: TIMEZONE,
  }).format(new Date(value));
}

export function relative(value: string | Date, now = new Date()): string {
  const diff = (now.getTime() - new Date(value).getTime()) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} h ago`;
  return `${Math.floor(diff / 86400)} d ago`;
}

/** Today's date (YYYY-MM-DD) in the company timezone. */
export function todayIso(timeZone = TIMEZONE, at = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' }).format(at);
}

export type Tone = 'neutral' | 'brand' | 'ok' | 'warn' | 'bad' | 'navy';

export const BOOKING_TONE: Record<string, Tone> = {
  PENDING: 'warn',
  CONFIRMED: 'brand',
  ASSIGNED: 'brand',
  ON_THE_WAY: 'navy',
  IN_PROGRESS: 'navy',
  AWAITING_APPROVAL: 'warn',
  COMPLETED: 'ok',
  CANCELLED: 'bad',
};

export const QUOTE_TONE: Record<string, Tone> = { DRAFT: 'neutral', SENT: 'warn', ACCEPTED: 'ok', REJECTED: 'bad', EXPIRED: 'neutral' };
export const INVOICE_TONE: Record<string, Tone> = { UNPAID: 'warn', PARTIALLY_PAID: 'brand', PAID: 'ok', VOID: 'neutral' };
export const PAYMENT_TONE: Record<string, Tone> = { PENDING: 'warn', COMPLETED: 'ok', FAILED: 'bad', REFUNDED: 'neutral' };
export const SUB_TONE: Record<string, Tone> = { PENDING: 'warn', ACTIVE: 'ok', PAUSED: 'neutral', CANCELLED: 'bad', EXPIRED: 'neutral' };
export const PRIORITY_TONE: Record<string, Tone> = { NORMAL: 'neutral', URGENT: 'warn', EMERGENCY: 'bad' };

export const BOOKING_STATUSES = ['PENDING', 'CONFIRMED', 'ASSIGNED', 'ON_THE_WAY', 'IN_PROGRESS', 'AWAITING_APPROVAL', 'COMPLETED', 'CANCELLED'] as const;
export const SLOTS = ['MORNING', 'AFTERNOON', 'EVENING'] as const;
export const PAYMENT_METHODS = ['CASH', 'EVC_PLUS', 'ZAAD', 'SAHAL', 'EDAHAB', 'BANK_TRANSFER', 'CARD'] as const;
export const EQUIPMENT_TYPES = ['SPLIT_AC', 'WINDOW_AC', 'CENTRAL_AC', 'PORTABLE_AC', 'REFRIGERATOR', 'FREEZER', 'COLD_ROOM', 'WATER_COOLER', 'OTHER'] as const;

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join('');
}

export function mapsUrl(lat?: string | number | null, lng?: string | number | null, text?: string): string {
  if (lat != null && lng != null) return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${text ?? ''}, Mogadishu`)}`;
}
