'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useState, type FormEvent } from 'react';
import { useAuth } from '@/lib/auth';
import { LOCALE_NAMES, useI18n, type Locale } from '@/lib/i18n';
import { Button, Field, Input } from '@/components/ui';
import { Logo } from '@/components/layout/logo';

export default function LoginPage() {
  const { signIn, user, ready } = useAuth();
  const { t, locale, setLocale } = useI18n();
  const router = useRouter();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (ready && user) router.replace('/');
  }, [ready, user, router]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await signIn(identifier.trim(), password);
      router.replace('/');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-dvh lg:grid-cols-[1fr_minmax(28rem,36rem)]">
      {/* Brand side: a frost pattern built from the logo geometry */}
      <div className="relative hidden overflow-hidden bg-navy-900 lg:block" aria-hidden>
        <svg className="absolute inset-0 size-full opacity-[0.07]" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="flake" width="120" height="120" patternUnits="userSpaceOnUse">
              <g stroke="#E8F4FC" strokeWidth="2" strokeLinecap="round" fill="none" transform="translate(60 60)">
                <path d="M0-26v52M-22.5-13l45 26M-22.5 13l45-26" />
                <path d="M-7-22l7 6 7-6M-7 22l7-6 7 6" />
              </g>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#flake)" />
        </svg>
        <div className="relative flex h-full flex-col justify-between p-12">
          <Logo inverted tagline />
          <div className="max-w-md">
            <p className="text-3xl font-semibold leading-snug text-white">Every booking, technician and payment for Mogadishu, in one place.</p>
            <p className="mt-4 text-navy-300">Confirm requests, dispatch technicians, send quotations and collect payments.</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col justify-center px-6 py-12 sm:px-12">
        <div className="mx-auto w-full max-w-sm">
          <div className="mb-10 lg:hidden">
            <Logo tagline />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">{t('auth.title')}</h1>
          <p className="mt-1.5 text-sm text-navy-500">{t('auth.subtitle')}</p>

          <form onSubmit={onSubmit} className="mt-8 space-y-4" noValidate>
            <Field label={t('auth.identifier')} htmlFor="identifier">
              <Input id="identifier" autoComplete="username" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required autoFocus />
            </Field>
            <Field label={t('auth.password')} htmlFor="password">
              <Input id="password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            </Field>
            {error && (
              <p role="alert" className="rounded-ctl bg-bad-50 px-3 py-2 text-sm text-bad-700">
                {error}
              </p>
            )}
            <Button type="submit" className="w-full" loading={loading} disabled={!identifier || !password}>
              {loading ? t('auth.signingIn') : t('auth.signIn')}
            </Button>
          </form>

          <div className="mt-10 flex gap-3 text-sm">
            {(Object.keys(LOCALE_NAMES) as Locale[]).map((l) => (
              <button
                key={l}
                onClick={() => setLocale(l)}
                className={l === locale ? 'font-semibold text-brand-600' : 'text-navy-500 hover:text-navy-900'}
                aria-pressed={l === locale}
              >
                {LOCALE_NAMES[l]}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
