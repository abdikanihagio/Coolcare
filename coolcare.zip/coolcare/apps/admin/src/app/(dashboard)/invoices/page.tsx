'use client';

import { Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Receipt } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { day, money } from '@/lib/format';
import type { Invoice } from '@/lib/types';
import { Badge, EmptyState, PageHeader, Select, Spinner } from '@/components/ui';
import { DataTable, SearchBox, useServerList, type Column } from '@/components/ui/data-table';
import { InvoiceStatusBadge } from '@/components/status';

export default function InvoicesPage() {
  return (
    <Suspense fallback={<Spinner />}>
      <InvoicesList />
    </Suspense>
  );
}

function InvoicesList() {
  const { t, locale } = useI18n();
  const router = useRouter();
  const params = useSearchParams();
  const list = useServerList<Invoice>('/admin/invoices', { sortBy: 'issuedAt', filters: { status: params.get('status') ?? undefined } });

  const columns: Column<Invoice>[] = [
    {
      key: 'num',
      header: t('inv.number'),
      sort: 'number',
      render: (i) => (
        <span className="flex items-center gap-2">
          <span className="num font-medium">{i.number}</span>
          {!!i._count?.payments && <Badge tone="warn">{t('payment.PENDING')}</Badge>}
        </span>
      ),
    },
    { key: 'cust', header: t('bk.customer'), render: (i) => i.customer?.fullName },
    { key: 'bk', header: t('bk.reference'), hideOnMobile: true, render: (i) => <span className="num">{i.booking?.reference}</span> },
    { key: 'issued', header: t('common.date'), sort: 'issuedAt', hideOnMobile: true, render: (i) => day(i.issuedAt, locale) },
    { key: 'status', header: t('common.status'), render: (i) => <InvoiceStatusBadge status={i.status} /> },
    { key: 'total', header: t('common.total'), sort: 'total', className: 'text-end', render: (i) => <span className="num">{money(i.total, i.currency, locale)}</span> },
    {
      key: 'bal',
      header: t('inv.balance'),
      className: 'text-end',
      hideOnMobile: true,
      render: (i) => <span className="num">{i.status === 'VOID' ? '—' : money(Number(i.total) - Number(i.amountPaid), i.currency, locale)}</span>,
    },
  ];

  return (
    <>
      <PageHeader title={t('inv.title')} />
      <DataTable
        list={list}
        columns={columns}
        onRowClick={(i) => router.push(`/invoices/${i.id}`)}
        empty={<EmptyState icon={<Receipt className="size-5" />} title={t('inv.empty')} />}
        toolbar={
          <>
            <SearchBox value={list.state.search} onChange={list.setSearch} placeholder={t('common.search')} />
            <Select className="w-full sm:w-44" value={list.state.filters.status ?? ''} onChange={(e) => list.setFilter('status', e.target.value)} aria-label={t('common.status')}>
              <option value="">{t('common.all')}</option>
              {(['UNPAID', 'PARTIALLY_PAID', 'PAID', 'VOID'] as const).map((s) => (
                <option key={s} value={s}>
                  {t(`invoice.${s}`)}
                </option>
              ))}
            </Select>
          </>
        }
      />
    </>
  );
}
