'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Printer } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { pick, useI18n } from '@/lib/i18n';
import { dateTime, day, money } from '@/lib/format';
import { useSettings } from '@/lib/hooks';
import type { Invoice } from '@/lib/types';
import { Button, ErrorState, Spinner } from '@/components/ui';
import { InvoiceStatusBadge, PaymentStatusBadge } from '@/components/status';
import { LogoMark } from '@/components/layout/logo';
import { RecordPaymentModal } from '@/components/record-payment';

export default function InvoicePage() {
  const { id } = useParams<{ id: string }>();
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const settings = useSettings();
  const [paying, setPaying] = useState(false);
  const q = useQuery({ queryKey: ['invoice', id], queryFn: () => api<Invoice>(`/admin/invoices/${id}`) });

  if (q.isLoading) return <Spinner label={t('common.loading')} />;
  if (q.isError || !q.data) return <ErrorState message={(q.error as Error)?.message ?? t('err.loadFailed')} onRetry={() => q.refetch()} />;
  const inv = q.data;
  const balance = Number(inv.total) - Number(inv.amountPaid);
  const items = inv.quote?.items ?? [
    { kind: 'LABOR' as const, description: pick(inv.booking?.service, 'name', locale), quantity: 1, unitPrice: inv.subtotal, total: inv.subtotal },
  ];

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="no-print flex flex-wrap items-center justify-between gap-3">
        <Link href="/invoices" className="inline-flex items-center gap-1 text-sm text-navy-500 hover:text-navy-900">
          <ArrowLeft className="size-4 rtl:rotate-180" />
          {t('inv.title')}
        </Link>
        <div className="flex gap-2">
          {can('ADMIN', 'ACCOUNTANT') && balance > 0 && inv.status !== 'VOID' && <Button onClick={() => setPaying(true)}>{t('inv.recordPayment')}</Button>}
          <Button variant="secondary" icon={<Printer className="size-4" />} onClick={() => window.print()}>
            {t('common.print')}
          </Button>
        </div>
      </div>

      <article className="rounded-panel border border-line bg-white p-8 print:border-0 print:p-0">
        <header className="flex flex-wrap items-start justify-between gap-6 border-b border-line pb-6">
          <div className="flex items-center gap-3">
            <LogoMark className="size-10" />
            <div>
              <div className="text-lg font-bold">{settings.data?.companyName ?? 'CoolCare'}</div>
              <div className="text-[13px] text-navy-500">
                {settings.data?.supportPhone} · {settings.data?.supportEmail}
              </div>
            </div>
          </div>
          <div className="text-end">
            <div className="text-2xl font-semibold tracking-tight">{inv.number}</div>
            <div className="mt-1">
              <InvoiceStatusBadge status={inv.status} />
            </div>
          </div>
        </header>

        <div className="grid gap-6 py-6 text-sm sm:grid-cols-3">
          <div>
            <div className="text-navy-500">{t('inv.billTo')}</div>
            <div className="mt-1 font-medium">{inv.customer?.fullName}</div>
            <div className="num text-navy-700">{inv.customer?.phone}</div>
          </div>
          <div>
            <div className="text-navy-500">{t('bk.reference')}</div>
            <Link href={`/bookings/${inv.bookingId}`} className="num mt-1 block font-medium hover:text-brand-600">
              {inv.booking?.reference}
            </Link>
          </div>
          <div>
            <div className="text-navy-500">{t('common.date')}</div>
            <div className="mt-1">{day(inv.issuedAt, locale)}</div>
            {inv.dueAt && (
              <div className="text-navy-500">
                {t('inv.due')}: {day(inv.dueAt, locale)}
              </div>
            )}
          </div>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="border-y border-line text-[13px] text-navy-500">
              <th className="py-2 text-start font-medium">{t('common.description')}</th>
              <th className="py-2 text-end font-medium">{t('q.qty')}</th>
              <th className="py-2 text-end font-medium">{t('q.unitPrice')}</th>
              <th className="py-2 text-end font-medium">{t('common.amount')}</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, i) => (
              <tr key={i} className="border-b border-line">
                <td className="py-2.5">{it.description}</td>
                <td className="num py-2.5 text-end">{Number(it.quantity)}</td>
                <td className="num py-2.5 text-end">{money(it.unitPrice, inv.currency, locale)}</td>
                <td className="num py-2.5 text-end">{money(it.total ?? 0, inv.currency, locale)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <dl className="num ms-auto mt-4 w-full max-w-xs space-y-1 text-sm">
          <div className="flex justify-between">
            <dt className="text-navy-500">{t('q.subtotal')}</dt>
            <dd>{money(inv.subtotal, inv.currency, locale)}</dd>
          </div>
          {Number(inv.discount) > 0 && (
            <div className="flex justify-between">
              <dt className="text-navy-500">{t('q.discount')}</dt>
              <dd>−{money(inv.discount, inv.currency, locale)}</dd>
            </div>
          )}
          {Number(inv.taxAmount) > 0 && (
            <div className="flex justify-between">
              <dt className="text-navy-500">{t('q.tax')}</dt>
              <dd>{money(inv.taxAmount, inv.currency, locale)}</dd>
            </div>
          )}
          <div className="flex justify-between border-t border-line pt-1 text-base font-semibold">
            <dt>{t('common.total')}</dt>
            <dd>{money(inv.total, inv.currency, locale)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-navy-500">{t('inv.paid')}</dt>
            <dd>{money(inv.amountPaid, inv.currency, locale)}</dd>
          </div>
          <div className="flex justify-between font-semibold">
            <dt>{t('inv.balance')}</dt>
            <dd>{money(balance, inv.currency, locale)}</dd>
          </div>
        </dl>

        {!!inv.payments?.length && (
          <section className="mt-8">
            <h2 className="mb-2 text-sm font-semibold">{t('pay.title')}</h2>
            <ul className="divide-y divide-line border-y border-line text-sm">
              {inv.payments.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                  <span>
                    {t(`method.${p.method}`)} {p.reference && <span className="num text-navy-500">· {p.reference}</span>}
                  </span>
                  <span className="flex items-center gap-3">
                    <span className="text-navy-500">{dateTime(p.paidAt, locale)}</span>
                    <span className="num">{money(p.amount, p.currency, locale)}</span>
                    <PaymentStatusBadge status={p.status} />
                  </span>
                </li>
              ))}
            </ul>
          </section>
        )}

        {settings.data && (
          <p className="mt-8 text-[13px] text-navy-500">{locale === 'so' ? settings.data.mobileMoneyInstructionsSo : settings.data.mobileMoneyInstructionsEn}</p>
        )}
      </article>

      {paying && <RecordPaymentModal invoice={inv} onClose={() => setPaying(false)} invalidate={[['invoice', id]]} />}
    </div>
  );
}
