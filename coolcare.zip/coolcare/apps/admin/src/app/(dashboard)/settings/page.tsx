'use client';

import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import { api } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { PAYMENT_METHODS } from '@/lib/format';
import { useAction, useSettings } from '@/lib/hooks';
import type { Branch } from '@/lib/types';
import { Badge, Button, Checkbox, ErrorState, Field, Input, Modal, PageHeader, Panel, Select, Spinner, Textarea } from '@/components/ui';

type S = Record<string, any>;

export default function SettingsPage() {
  const { t } = useI18n();
  const settings = useSettings();
  const [f, setF] = useState<S | null>(null);
  const [districts, setDistricts] = useState('');

  useEffect(() => {
    if (settings.data) {
      setF(settings.data);
      setDistricts((settings.data.serviceDistricts ?? []).join('\n'));
    }
  }, [settings.data]);

  const save = useAction(
    () => {
      const { companyName, supportPhone, supportWhatsapp, supportEmail, currency, taxRate, timezone, defaultLocale, bookingLeadHours, maxBookingsPerSlot,
        quoteValidityDays, invoiceDueDays, emergencySurcharge, paymentMethods, mobileMoneyInstructionsEn, mobileMoneyInstructionsSo, maintenanceReminderDays,
        allowCustomerCancellation } = f!;
      return api('/settings', {
        method: 'PATCH',
        body: {
          companyName, supportPhone, supportWhatsapp, supportEmail, currency, timezone, defaultLocale, paymentMethods,
          mobileMoneyInstructionsEn, mobileMoneyInstructionsSo, allowCustomerCancellation,
          taxRate: Number(taxRate), bookingLeadHours: Number(bookingLeadHours), maxBookingsPerSlot: Number(maxBookingsPerSlot),
          quoteValidityDays: Number(quoteValidityDays), invoiceDueDays: Number(invoiceDueDays), emergencySurcharge: Number(emergencySurcharge),
          maintenanceReminderDays: Number(maintenanceReminderDays),
          serviceDistricts: districts.split('\n').map((d) => d.trim()).filter(Boolean),
        },
      });
    },
    { success: t('common.saved'), invalidate: [['settings']] },
  );

  if (settings.isError) return <ErrorState message={(settings.error as Error).message} onRetry={() => settings.refetch()} />;
  if (!f) return <Spinner label={t('common.loading')} />;

  const input = (key: string, props: Record<string, unknown> = {}) => (
    <Input id={key} value={f[key] ?? ''} onChange={(e) => setF({ ...f, [key]: e.target.value })} {...props} />
  );

  return (
    <>
      <PageHeader
        title={t('se.title')}
        actions={
          <Button onClick={() => save.mutate(undefined)} loading={save.isPending}>
            {t('common.save')}
          </Button>
        }
      />
      <div className="grid gap-6 xl:grid-cols-2">
        <Panel title={t('se.company')}>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Field label={t('se.companyName')} htmlFor="companyName">
                {input('companyName')}
              </Field>
            </div>
            <Field label={t('se.supportPhone')} htmlFor="supportPhone">
              {input('supportPhone', { type: 'tel' })}
            </Field>
            <Field label={t('se.supportWhatsapp')} htmlFor="supportWhatsapp">
              {input('supportWhatsapp', { type: 'tel' })}
            </Field>
            <Field label={t('se.supportEmail')} htmlFor="supportEmail">
              {input('supportEmail', { type: 'email' })}
            </Field>
            <Field label={t('common.language')} htmlFor="defaultLocale">
              <Select id="defaultLocale" value={f.defaultLocale} onChange={(e) => setF({ ...f, defaultLocale: e.target.value })}>
                <option value="en">English</option>
                <option value="so">Soomaali</option>
              </Select>
            </Field>
          </div>
        </Panel>

        <Panel title={t('se.money')}>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t('se.currency')} htmlFor="currency">
              <Select id="currency" value={f.currency} onChange={(e) => setF({ ...f, currency: e.target.value })}>
                {(f.supportedCurrencies ?? ['USD']).map((c: string) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label={t('se.taxRate')} htmlFor="taxRate">
              {input('taxRate', { type: 'number', min: 0, max: 100, step: '0.01' })}
            </Field>
            <Field label={t('se.emergency')} htmlFor="emergencySurcharge">
              {input('emergencySurcharge', { type: 'number', min: 0, step: '0.01' })}
            </Field>
            <Field label={t('se.invoiceDue')} htmlFor="invoiceDueDays">
              {input('invoiceDueDays', { type: 'number', min: 0 })}
            </Field>
            <Field label={t('se.quoteValidity')} htmlFor="quoteValidityDays">
              {input('quoteValidityDays', { type: 'number', min: 1 })}
            </Field>
            <fieldset className="sm:col-span-2">
              <legend className="mb-2 text-[13px] font-medium text-navy-800">{t('se.paymentMethods')}</legend>
              <div className="flex flex-wrap gap-x-5 gap-y-2">
                {PAYMENT_METHODS.map((m) => (
                  <Checkbox
                    key={m}
                    label={t(`method.${m}`)}
                    checked={(f.paymentMethods ?? []).includes(m)}
                    onChange={(v) =>
                      setF({ ...f, paymentMethods: v ? [...(f.paymentMethods ?? []), m] : (f.paymentMethods ?? []).filter((x: string) => x !== m) })
                    }
                  />
                ))}
              </div>
            </fieldset>
            <Field label={t('se.mmEn')} htmlFor="mmEn">
              <Textarea id="mmEn" value={f.mobileMoneyInstructionsEn} onChange={(e) => setF({ ...f, mobileMoneyInstructionsEn: e.target.value })} />
            </Field>
            <Field label={t('se.mmSo')} htmlFor="mmSo">
              <Textarea id="mmSo" value={f.mobileMoneyInstructionsSo} onChange={(e) => setF({ ...f, mobileMoneyInstructionsSo: e.target.value })} />
            </Field>
          </div>
        </Panel>

        <Panel title={t('se.scheduling')}>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t('se.timezone')} htmlFor="timezone">
              {input('timezone')}
            </Field>
            <Field label={t('se.leadHours')} htmlFor="bookingLeadHours">
              {input('bookingLeadHours', { type: 'number', min: 0 })}
            </Field>
            <Field label={t('se.maxPerSlot')} htmlFor="maxBookingsPerSlot">
              {input('maxBookingsPerSlot', { type: 'number', min: 1 })}
            </Field>
            <Field label={t('se.reminderDays')} htmlFor="maintenanceReminderDays">
              {input('maintenanceReminderDays', { type: 'number', min: 1 })}
            </Field>
            <div className="sm:col-span-2">
              <Checkbox label={t('se.allowCancel')} checked={!!f.allowCustomerCancellation} onChange={(v) => setF({ ...f, allowCustomerCancellation: v })} />
            </div>
          </div>
        </Panel>

        <Panel title={t('se.districts')}>
          <Field label={t('se.districts')} hint={t('se.districtsHint')} htmlFor="districts">
            <Textarea id="districts" className="min-h-48" value={districts} onChange={(e) => setDistricts(e.target.value)} />
          </Field>
        </Panel>

        <BranchesPanel />
      </div>
    </>
  );
}

function BranchesPanel() {
  const { t } = useI18n();
  const q = useQuery({ queryKey: ['branches'], queryFn: () => api<Branch[]>('/admin/branches') });
  const [edit, setEdit] = useState<Branch | 'new' | null>(null);
  return (
    <Panel
      title={t('se.branches')}
      action={
        <Button size="sm" variant="secondary" icon={<Plus className="size-4" />} onClick={() => setEdit('new')}>
          {t('se.newBranch')}
        </Button>
      }
      bodyClassName="p-0"
    >
      <ul className="divide-y divide-line">
        {q.data?.map((b) => (
          <li key={b.id} className="flex items-center justify-between gap-3 px-5 py-3 text-sm">
            <div>
              <div className="font-medium">
                {b.name} {!b.isActive && <Badge>{t('common.inactive')}</Badge>}
              </div>
              <div className="text-[13px] text-navy-500">
                {b.city}, {b.country} · {b.timezone} · {b.currency}
              </div>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setEdit(b)}>
              {t('common.edit')}
            </Button>
          </li>
        ))}
      </ul>
      {edit && <BranchForm branch={edit === 'new' ? null : edit} onClose={() => setEdit(null)} />}
    </Panel>
  );
}

function BranchForm({ branch, onClose }: { branch: Branch | null; onClose: () => void }) {
  const { t } = useI18n();
  const [f, setF] = useState({
    name: branch?.name ?? '',
    city: branch?.city ?? '',
    country: branch?.country ?? 'Somalia',
    timezone: branch?.timezone ?? 'Africa/Mogadishu',
    currency: branch?.currency ?? 'USD',
    phone: branch?.phone ?? '',
    address: branch?.address ?? '',
    isActive: branch?.isActive ?? true,
  });
  const save = useAction(
    () => {
      const body = { ...f, phone: f.phone || undefined, address: f.address || undefined };
      return branch ? api(`/admin/branches/${branch.id}`, { method: 'PATCH', body }) : api('/admin/branches', { body });
    },
    { success: t('common.saved'), invalidate: [['branches']], onSuccess: onClose },
  );
  return (
    <Modal
      open
      onClose={onClose}
      title={branch ? branch.name : t('se.newBranch')}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => save.mutate(undefined)} loading={save.isPending} disabled={!f.name || !f.city}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={t('common.name')} htmlFor="bn">
          <Input id="bn" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        </Field>
        <Field label={t('se.city')} htmlFor="bc">
          <Input id="bc" value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} />
        </Field>
        <Field label={t('se.timezone')} htmlFor="btz">
          <Input id="btz" value={f.timezone} onChange={(e) => setF({ ...f, timezone: e.target.value })} />
        </Field>
        <Field label={t('se.currency')} htmlFor="bcur">
          <Input id="bcur" maxLength={3} value={f.currency} onChange={(e) => setF({ ...f, currency: e.target.value.toUpperCase() })} />
        </Field>
        <Field label={t('common.phone')} htmlFor="bp" optional>
          <Input id="bp" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        </Field>
        <Field label={t('bk.address')} htmlFor="ba" optional>
          <Input id="ba" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
        </Field>
        <Checkbox label={t('common.active')} checked={f.isActive} onChange={(v) => setF({ ...f, isActive: v })} />
      </div>
    </Modal>
  );
}
