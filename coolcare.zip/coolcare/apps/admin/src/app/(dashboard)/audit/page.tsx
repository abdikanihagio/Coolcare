'use client';

import { History } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { dateTime } from '@/lib/format';
import { EmptyState, PageHeader } from '@/components/ui';
import { DataTable, SearchBox, useServerList, type Column } from '@/components/ui/data-table';

interface Log {
  id: string;
  action: string;
  entity: string;
  entityId: string | null;
  meta: Record<string, unknown> | null;
  createdAt: string;
  actor: { fullName: string; role: string } | null;
}

export default function AuditPage() {
  const { t, locale } = useI18n();
  const list = useServerList<Log>('/admin/reports/audit-logs', { pageSize: 50 });
  const columns: Column<Log>[] = [
    { key: 'when', header: t('au.when'), render: (l) => <span className="whitespace-nowrap">{dateTime(l.createdAt, locale)}</span> },
    { key: 'who', header: t('au.who'), render: (l) => l.actor?.fullName ?? 'System' },
    { key: 'action', header: t('au.action'), render: (l) => <code className="rounded bg-surface px-1.5 py-0.5 text-[13px]">{l.action}</code> },
    {
      key: 'rec',
      header: t('au.record'),
      hideOnMobile: true,
      render: (l) => (
        <span className="text-[13px] text-navy-500">
          {l.entity} {l.entityId?.slice(0, 8)}
        </span>
      ),
    },
  ];
  return (
    <>
      <PageHeader title={t('au.title')} />
      <DataTable
        list={list}
        columns={columns}
        empty={<EmptyState icon={<History className="size-5" />} title="—" />}
        toolbar={<SearchBox value={list.state.search} onChange={list.setSearch} placeholder={t('common.search')} />}
      />
    </>
  );
}
