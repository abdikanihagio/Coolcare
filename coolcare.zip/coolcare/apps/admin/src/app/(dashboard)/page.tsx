'use client';

import Link from 'next/link';
import { useState, type ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import { AlertTriangle, Star } from 'lucide-react';
import { api } from '@/lib/api';
import { useI18n, pick } from '@/lib/i18n';
import { day, money } from '@/lib/format';
import type { BookingStatus, Slot } from '@/lib/types';
import { cx, ErrorState, Panel, Skeleton } from '@/components/ui';
import { BookingStatusBadge, PriorityBadge } from '@/components/status';

interface Overview {
  range: { from: string; to: string; timezone: string; currency: string };
  kpis: {
    bookingsToday: number;
    pending: number;
    active: number;
    unassigned: number;
    completed: number;
    createdInPeriod: number;
    revenue: number;
    outstanding: number;
    averageRating: number | null;
    ratingsCount: number;
    customers: number;
    newCustomers: number;
    techniciansAvailable: number;
    pendingPayments: number;
    quotesAwaiting: number;
  };
  byStatus: { status: BookingStatus; count: number }[];
  topServices: { serviceId: string; nameEn: string; nameSo: string; count: number }[];
  daily: { date: string; revenue: number; bookings: number }[];
  todaysSchedule: {
    id: string;
    reference: string;
    status: BookingStatus;
    priority: string;
    timeSlot: Slot;
    addressText: string;
    service: { nameEn: string; nameSo: string };
    technician: { id: string; fullName: string } | null;
    customer: { fullName: string; phone: string };
  }[];
  technicianPerformance: { id: string; fullName: string; completed: number; avgRating: number | null }[];
}

export default function DashboardPage() {
  const { t, locale } = useI18n();
  const q = useQuery({ queryKey: ['overview'], queryFn: () => api<Overview>('/admin/reports/overview'), refetchInterval: 60_000 });

  if (q.isError) return <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />;
  const d = q.data;
  const cur = d?.range.currency ?? 'USD';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <h1 className="text-2xl font-semibold tracking-tight">{t('dash.title')}</h1>
        {d && <p className="text-sm text-navy-500">{day(d.range.to, locale)}</p>}
      </div>

      {/* Work that needs attention now */}
      <div className="grid grid-cols-2 gap-px overflow-hidden rounded-panel border border-line bg-line sm:grid-cols-4">
        <Stat label={t('dash.bookingsToday')} value={d?.kpis.bookingsToday} href="/bookings" />
        <Stat label={t('dash.newRequests')} value={d?.kpis.pending} href="/bookings?status=PENDING" alert={!!d?.kpis.pending} />
        <Stat label={t('dash.unassigned')} value={d?.kpis.unassigned} href="/bookings?unassigned=true" alert={!!d?.kpis.unassigned} />
        <Stat label={t('dash.activeJobs')} value={d?.kpis.active} href="/bookings?scope=active" />
      </div>

      <SchedulePanel data={d} />

      <div className="grid gap-6 xl:grid-cols-3">
        <Panel title={t('dash.trend')} className="xl:col-span-2">
          {d ? <TrendChart daily={d.daily} currency={cur} /> : <Skeleton className="h-48 w-full" />}
        </Panel>

        <Panel title={t('nav.groupFinance')} bodyClassName="p-0">
          <dl className="divide-y divide-line text-sm">
            <Row label={t('dash.revenue')} value={d ? money(d.kpis.revenue, cur, locale) : undefined} />
            <Row label={t('dash.outstanding')} value={d ? money(d.kpis.outstanding, cur, locale) : undefined} href="/invoices?status=UNPAID" />
            <Row label={t('dash.toVerify')} value={d?.kpis.pendingPayments} href="/payments?status=PENDING" warn={!!d?.kpis.pendingPayments} />
            <Row label={t('dash.quotesAwaiting')} value={d?.kpis.quotesAwaiting} href="/quotes?status=SENT" />
            <Row
              label={t('dash.rating')}
              value={
                d?.kpis.averageRating ? (
                  <span className="inline-flex items-center gap-1">
                    <Star className="size-3.5 fill-warn-600 text-warn-600" />
                    {d.kpis.averageRating.toFixed(1)}
                    <span className="text-navy-500">({d.kpis.ratingsCount})</span>
                  </span>
                ) : (
                  '—'
                )
              }
            />
          </dl>
        </Panel>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title={t('dash.topServices')}>
          {d ? (
            d.topServices.length ? (
              <ol className="space-y-3">
                {d.topServices.map((s) => {
                  const max = d.topServices[0]!.count || 1;
                  return (
                    <li key={s.serviceId} className="text-sm">
                      <div className="mb-1 flex justify-between">
                        <span>{pick(s, 'name', locale)}</span>
                        <span className="num text-navy-500">{s.count}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-brand-50">
                        <div className="h-full rounded-full bg-brand-500" style={{ width: `${(s.count / max) * 100}%` }} />
                      </div>
                    </li>
                  );
                })}
              </ol>
            ) : (
              <p className="text-sm text-navy-500">—</p>
            )
          ) : (
            <Skeleton className="h-32 w-full" />
          )}
        </Panel>

        <Panel title={t('dash.technicians')} bodyClassName="p-0">
          {d ? (
            <ul className="divide-y divide-line">
              {d.technicianPerformance.map((tp) => (
                <li key={tp.id}>
                  <Link href={`/technicians/${tp.id}`} className="flex items-center justify-between px-5 py-3 text-sm hover:bg-surface">
                    <span>{tp.fullName}</span>
                    <span className="flex items-center gap-4 text-navy-500">
                      <span className="num">{t('dash.jobsDone', { count: tp.completed })}</span>
                      <span className="num inline-flex w-10 items-center justify-end gap-1">
                        {tp.avgRating ? (
                          <>
                            <Star className="size-3 fill-warn-600 text-warn-600" />
                            {tp.avgRating.toFixed(1)}
                          </>
                        ) : (
                          '—'
                        )}
                      </span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <div className="p-5">
              <Skeleton className="h-32 w-full" />
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

function Stat({ label, value, href, alert }: { label: string; value?: number; href: string; alert?: boolean }) {
  return (
    <Link href={href} className="bg-white px-5 py-4 hover:bg-surface">
      <div className="flex items-center gap-1.5 text-[13px] text-navy-500">
        {alert && <span className="size-1.5 rounded-full bg-warn-600" aria-hidden />}
        {label}
      </div>
      <div className="num mt-1 text-3xl font-semibold tracking-tight text-navy-900">{value ?? <Skeleton className="mt-2 h-7 w-12" />}</div>
    </Link>
  );
}

function Row({ label, value, href, warn }: { label: string; value: ReactNode; href?: string; warn?: boolean }) {
  const content = (
    <div className={cx('flex items-center justify-between gap-3 px-5 py-3', href && 'hover:bg-surface')}>
      <dt className="text-navy-500">{label}</dt>
      <dd className={cx('num font-medium', warn && 'text-warn-700')}>{value ?? <Skeleton className="h-4 w-16" />}</dd>
    </div>
  );
  return href ? <Link href={href}>{content}</Link> : content;
}

/** Dispatch board: today's jobs grouped by time slot. */
function SchedulePanel({ data }: { data?: Overview }) {
  const { t, locale } = useI18n();
  const slots: Slot[] = ['MORNING', 'AFTERNOON', 'EVENING'];
  return (
    <Panel title={t('dash.schedule')} bodyClassName="p-0">
      <div className="grid divide-y divide-line md:grid-cols-3 md:divide-x md:divide-y-0 rtl:md:divide-x-reverse">
        {slots.map((slot) => {
          const jobs = data?.todaysSchedule.filter((j) => j.timeSlot === slot) ?? [];
          return (
            <div key={slot} className="p-4">
              <h3 className="mb-3 flex items-center justify-between text-[13px] font-medium text-navy-700">
                {t(`slot.${slot}`)}
                <span className="num text-navy-500">{data ? jobs.length : ''}</span>
              </h3>
              {!data ? (
                <div className="space-y-2">
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
                </div>
              ) : jobs.length === 0 ? (
                <p className="rounded-lg border border-dashed border-line px-3 py-6 text-center text-[13px] text-navy-500">{t('dash.noJobs')}</p>
              ) : (
                <ul className="space-y-2">
                  {jobs.map((j) => (
                    <li key={j.id}>
                      <Link
                        href={`/bookings/${j.id}`}
                        className={cx(
                          'block rounded-lg border px-3 py-2.5 text-sm hover:border-brand-300',
                          j.status === 'COMPLETED' ? 'border-line bg-surface/60' : 'border-line bg-white',
                          !j.technician && j.status !== 'CANCELLED' && 'border-s-4 border-s-warn-600',
                        )}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="font-medium">{pick(j.service, 'name', locale)}</span>
                          <BookingStatusBadge status={j.status} />
                        </div>
                        <div className="mt-1 truncate text-[13px] text-navy-500">
                          {j.customer.fullName} · {j.addressText}
                        </div>
                        <div className="mt-1.5 flex items-center justify-between text-[13px]">
                          {j.technician ? (
                            <span className="text-navy-700">{j.technician.fullName}</span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-warn-700">
                              <AlertTriangle className="size-3.5" />
                              {t('common.unassigned')}
                            </span>
                          )}
                          <PriorityBadge priority={j.priority} />
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

/** Bookings as bars, revenue as a line; plain SVG so it themes and prints cleanly. */
function TrendChart({ daily, currency }: { daily: Overview['daily']; currency: string }) {
  const { t, locale } = useI18n();
  const [hover, setHover] = useState<number | null>(null);
  const W = 640;
  const H = 200;
  const pad = { top: 12, bottom: 24, left: 4, right: 4 };
  const maxB = Math.max(1, ...daily.map((d) => d.bookings));
  const maxR = Math.max(1, ...daily.map((d) => d.revenue));
  const step = (W - pad.left - pad.right) / Math.max(1, daily.length);
  const y = (v: number, max: number) => pad.top + (H - pad.top - pad.bottom) * (1 - v / max);
  const line = daily.map((d, i) => `${i ? 'L' : 'M'}${pad.left + step * i + step / 2},${y(d.revenue, maxR)}`).join(' ');
  const active = hover !== null ? daily[hover] : daily[daily.length - 1];

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-x-5 gap-y-1 text-[13px] text-navy-500">
        <span className="inline-flex items-center gap-1.5">
          <span className="size-2.5 rounded-sm bg-brand-200" /> {t('nav.bookings')}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="h-0.5 w-3 bg-navy-900" /> {t('common.amount')}
        </span>
        {active && (
          <span className="num ms-auto text-navy-900">
            {day(active.date, locale)}: {active.bookings} · {money(active.revenue, currency, locale)}
          </span>
        )}
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="h-52 w-full" role="img" aria-label={t('dash.trend')} onMouseLeave={() => setHover(null)}>
        {daily.map((d, i) => {
          const x = pad.left + step * i;
          const top = y(d.bookings, maxB);
          return (
            <g key={d.date} onMouseEnter={() => setHover(i)}>
              <rect x={x} y={pad.top} width={step} height={H - pad.top - pad.bottom} fill="transparent" />
              <rect
                x={x + step * 0.18}
                y={top}
                width={step * 0.64}
                height={Math.max(0, H - pad.bottom - top)}
                rx={2}
                className={hover === i ? 'fill-brand-400' : 'fill-brand-200'}
              />
            </g>
          );
        })}
        <path d={line} fill="none" strokeWidth={2} className="stroke-navy-900" strokeLinejoin="round" />
        {[0, Math.floor(daily.length / 2), daily.length - 1].map((i) =>
          daily[i] ? (
            <text key={i} x={pad.left + step * i + step / 2} y={H - 6} textAnchor="middle" className="fill-navy-500 text-[11px]">
              {day(daily[i]!.date, locale).replace(/ \d{4}$/, '')}
            </text>
          ) : null,
        )}
      </svg>
    </div>
  );
}
