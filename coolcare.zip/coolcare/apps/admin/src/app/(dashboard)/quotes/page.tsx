'use client';

import { Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { FileText } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { dateTime, money } from '@/lib/format';
import type { Quote } from '@/lib/types';
import { EmptyState, PageHeader, Select, Spinner } from '@/components/ui';
import { DataTable, SearchBox, useServerList, type Column } from '@/components/ui/data-table';
import { QuoteStatusBadge } from '@/components/status';

export default function QuotesPage() {
  return (
    <Suspense fallback={<Spinner />}>
      <QuotesList />
    </Suspense>
  );
}

function QuotesList() {
  const { t, locale } = useI18n();
  const router = useRouter();
  const params = useSearchParams();
  const list = useServerList<Quote>('/admin/quotes', { filters: { status: params.get('status') ?? undefined } });

  const columns: Column<Quote>[] = [
    { key: 'num', header: t('q.number'), sort: 'number', render: (q) => <span className="num font-medium">{q.number}</span> },
    { key: 'bk', header: t('bk.reference'), render: (q) => <span className="num">{q.booking?.reference}</span> },
    { key: 'cust', header: t('bk.customer'), hideOnMobile: true, render: (q) => q.booking?.customer?.fullName },
    { key: 'status', header: t('common.status'), sort: 'status', render: (q) => <QuoteStatusBadge status={q.status} /> },
    { key: 'created', header: t('common.created'), sort: 'createdAt', hideOnMobile: true, render: (q) => dateTime(q.createdAt, locale) },
    { key: 'total', header: t('common.total'), sort: 'total', className: 'text-end', render: (q) => <span className="num">{money(q.total, q.currency, locale)}</span> },
  ];

  return (
    <>
      <PageHeader title={t('q.title')} />
      <DataTable
        list={list}
        columns={columns}
        onRowClick={(q) => q.booking && router.push(`/bookings/${q.booking.id}`)}
        empty={<EmptyState icon={<FileText className="size-5" />} title={t('q.empty')} />}
        toolbar={
          <>
            <SearchBox value={list.state.search} onChange={list.setSearch} placeholder={t('common.search')} />
            <Select className="w-full sm:w-44" value={list.state.filters.status ?? ''} onChange={(e) => list.setFilter('status', e.target.value)} aria-label={t('common.status')}>
              <option value="">{t('common.all')}</option>
              {(['DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'EXPIRED'] as const).map((s) => (
                <option key={s} value={s}>
                  {t(`quote.${s}`)}
                </option>
              ))}
            </Select>
          </>
        }
      />
    </>
  );
}
