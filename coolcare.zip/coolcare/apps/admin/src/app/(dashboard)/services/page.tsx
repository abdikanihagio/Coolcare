'use client';

import { useState } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { api } from '@/lib/api';
import { pick, useI18n } from '@/lib/i18n';
import { money } from '@/lib/format';
import { useAction, useCatalog } from '@/lib/hooks';
import type { Category, Service } from '@/lib/types';
import { Badge, Button, Checkbox, ConfirmDialog, cx, EmptyState, ErrorState, Field, Input, Modal, PageHeader, Select, Skeleton, Textarea } from '@/components/ui';

const slugify = (s: string) =>
  s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

export default function ServicesPage() {
  const { t, locale } = useI18n();
  const catalog = useCatalog();
  const [selected, setSelected] = useState<string | null>(null);
  const [editCat, setEditCat] = useState<Category | 'new' | null>(null);
  const [editSvc, setEditSvc] = useState<Service | 'new' | null>(null);
  const [deleting, setDeleting] = useState<Service | null>(null);

  const del = useAction((id: string) => api(`/admin/catalog/services/${id}`, { method: 'DELETE' }), {
    success: t('common.saved'),
    invalidate: [['admin-catalog']],
    onSuccess: () => setDeleting(null),
  });

  if (catalog.isError) return <ErrorState message={(catalog.error as Error).message} onRetry={() => catalog.refetch()} />;
  const cats = catalog.data ?? [];
  const current = cats.find((c) => c.id === selected) ?? cats[0];

  return (
    <>
      <PageHeader
        title={t('sv.title')}
        actions={
          <>
            <Button variant="secondary" icon={<Plus className="size-4" />} onClick={() => setEditCat('new')}>
              {t('sv.newCategory')}
            </Button>
            <Button icon={<Plus className="size-4" />} onClick={() => setEditSvc('new')} disabled={!cats.length}>
              {t('sv.newService')}
            </Button>
          </>
        }
      />
      <div className="grid gap-6 lg:grid-cols-[16rem_1fr]">
        <nav aria-label={t('sv.category')} className="space-y-1">
          {catalog.isLoading
            ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)
            : cats.map((c) => (
                <div key={c.id} className="group flex items-center">
                  <button
                    onClick={() => setSelected(c.id)}
                    className={cx(
                      'flex flex-1 items-center justify-between rounded-lg px-3 py-2 text-start text-sm',
                      current?.id === c.id ? 'bg-white font-medium ring-1 ring-line' : 'text-navy-700 hover:bg-white/60',
                    )}
                  >
                    <span className={cx(!c.isActive && 'text-navy-300 line-through')}>{pick(c, 'name', locale)}</span>
                    <span className="num text-xs text-navy-500">{c.services?.length ?? 0}</span>
                  </button>
                  <button onClick={() => setEditCat(c)} className="ms-1 rounded p-1.5 text-navy-300 hover:text-navy-900" aria-label={`${t('common.edit')} ${c.nameEn}`}>
                    <Pencil className="size-3.5" />
                  </button>
                </div>
              ))}
        </nav>

        <div className="rounded-panel border border-line bg-white">
          {current?.services?.length ? (
            <ul className="divide-y divide-line">
              {current.services.map((s) => (
                <li key={s.id} className="flex flex-wrap items-start justify-between gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-medium">{pick(s, 'name', locale)}</span>
                      {!s.isActive && <Badge>{t('common.inactive')}</Badge>}
                    </div>
                    <p className="mt-0.5 text-[13px] text-navy-500">{locale === 'so' ? s.nameEn : s.nameSo}</p>
                    {pick(s, 'description', locale) && <p className="mt-1.5 max-w-prose text-sm text-navy-700">{pick(s, 'description', locale)}</p>}
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-end text-sm">
                      <div className="num font-medium">{s.priceType === 'INSPECTION_REQUIRED' ? t('price.INSPECTION_REQUIRED') : money(s.basePrice, 'USD', locale)}</div>
                      {s.priceType !== 'INSPECTION_REQUIRED' && <div className="text-[13px] text-navy-500">{t(`price.${s.priceType}`)}</div>}
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => setEditSvc(s)} aria-label={t('common.edit')}>
                      <Pencil className="size-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => setDeleting(s)} aria-label={t('common.delete')}>
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyState title={t('sv.empty')} />
          )}
        </div>
      </div>

      {editCat && <CategoryForm category={editCat === 'new' ? null : editCat} onClose={() => setEditCat(null)} />}
      {editSvc && <ServiceForm service={editSvc === 'new' ? null : editSvc} categories={cats} defaultCategory={current?.id} onClose={() => setEditSvc(null)} />}
      <ConfirmDialog
        open={!!deleting}
        title={t('common.delete')}
        message={t('sv.deleteConfirm', { name: deleting ? pick(deleting, 'name', locale) : '' })}
        confirmLabel={t('common.delete')}
        cancelLabel={t('common.cancel')}
        loading={del.isPending}
        onClose={() => setDeleting(null)}
        onConfirm={() => deleting && del.mutate(deleting.id)}
      />
    </>
  );
}

function CategoryForm({ category, onClose }: { category: Category | null; onClose: () => void }) {
  const { t } = useI18n();
  const [f, setF] = useState({
    nameEn: category?.nameEn ?? '',
    nameSo: category?.nameSo ?? '',
    slug: category?.slug ?? '',
    descriptionEn: category?.descriptionEn ?? '',
    descriptionSo: category?.descriptionSo ?? '',
    sortOrder: category?.sortOrder ?? 0,
    isActive: category?.isActive ?? true,
  });
  const save = useAction(
    () => {
      const body = { ...f, slug: f.slug || slugify(f.nameEn), sortOrder: Number(f.sortOrder) };
      return category ? api(`/admin/catalog/categories/${category.id}`, { method: 'PATCH', body }) : api('/admin/catalog/categories', { body });
    },
    { success: t('common.saved'), invalidate: [['admin-catalog']], onSuccess: onClose },
  );
  return (
    <Modal
      open
      onClose={onClose}
      title={category ? category.nameEn : t('sv.newCategory')}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => save.mutate(undefined)} loading={save.isPending} disabled={!f.nameEn.trim() || !f.nameSo.trim()}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={t('sv.nameEn')} htmlFor="cne">
          <Input id="cne" value={f.nameEn} onChange={(e) => setF({ ...f, nameEn: e.target.value })} />
        </Field>
        <Field label={t('sv.nameSo')} htmlFor="cns">
          <Input id="cns" value={f.nameSo} onChange={(e) => setF({ ...f, nameSo: e.target.value })} />
        </Field>
        <Field label={t('sv.descEn')} htmlFor="cde" optional>
          <Textarea id="cde" value={f.descriptionEn} onChange={(e) => setF({ ...f, descriptionEn: e.target.value })} />
        </Field>
        <Field label={t('sv.descSo')} htmlFor="cds" optional>
          <Textarea id="cds" value={f.descriptionSo} onChange={(e) => setF({ ...f, descriptionSo: e.target.value })} />
        </Field>
        <Field label={t('sv.slug')} htmlFor="csl" hint={slugify(f.nameEn) || undefined}>
          <Input id="csl" value={f.slug} placeholder={slugify(f.nameEn)} onChange={(e) => setF({ ...f, slug: slugify(e.target.value) })} />
        </Field>
        <div className="flex items-end pb-2">
          <Checkbox label={t('sv.visible')} checked={f.isActive} onChange={(v) => setF({ ...f, isActive: v })} />
        </div>
      </div>
    </Modal>
  );
}

function ServiceForm({ service, categories, defaultCategory, onClose }: { service: Service | null; categories: Category[]; defaultCategory?: string; onClose: () => void }) {
  const { t, locale } = useI18n();
  const [f, setF] = useState({
    categoryId: service?.categoryId ?? defaultCategory ?? categories[0]?.id ?? '',
    nameEn: service?.nameEn ?? '',
    nameSo: service?.nameSo ?? '',
    slug: service?.slug ?? '',
    descriptionEn: service?.descriptionEn ?? '',
    descriptionSo: service?.descriptionSo ?? '',
    basePrice: service ? String(Number(service.basePrice)) : '',
    priceType: service?.priceType ?? 'STARTING_FROM',
    durationMinutes: service?.durationMinutes ?? 60,
    isActive: service?.isActive ?? true,
  });
  const save = useAction(
    () => {
      const body = { ...f, slug: f.slug || slugify(f.nameEn), basePrice: Number(f.basePrice || 0), durationMinutes: Number(f.durationMinutes) };
      return service ? api(`/admin/catalog/services/${service.id}`, { method: 'PATCH', body }) : api('/admin/catalog/services', { body });
    },
    { success: t('common.saved'), invalidate: [['admin-catalog']], onSuccess: onClose },
  );
  return (
    <Modal
      open
      onClose={onClose}
      size="lg"
      title={service ? service.nameEn : t('sv.newService')}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => save.mutate(undefined)} loading={save.isPending} disabled={!f.nameEn.trim() || !f.nameSo.trim() || !f.categoryId}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={t('sv.category')} htmlFor="sc">
          <Select id="sc" value={f.categoryId} onChange={(e) => setF({ ...f, categoryId: e.target.value })}>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {pick(c, 'name', locale)}
              </option>
            ))}
          </Select>
        </Field>
        <Field label={t('sv.slug')} htmlFor="ssl">
          <Input id="ssl" value={f.slug} placeholder={slugify(f.nameEn)} onChange={(e) => setF({ ...f, slug: slugify(e.target.value) })} />
        </Field>
        <Field label={t('sv.nameEn')} htmlFor="sne">
          <Input id="sne" value={f.nameEn} onChange={(e) => setF({ ...f, nameEn: e.target.value })} />
        </Field>
        <Field label={t('sv.nameSo')} htmlFor="sns">
          <Input id="sns" value={f.nameSo} onChange={(e) => setF({ ...f, nameSo: e.target.value })} />
        </Field>
        <Field label={t('sv.descEn')} htmlFor="sde" optional>
          <Textarea id="sde" value={f.descriptionEn} onChange={(e) => setF({ ...f, descriptionEn: e.target.value })} />
        </Field>
        <Field label={t('sv.descSo')} htmlFor="sds" optional>
          <Textarea id="sds" value={f.descriptionSo} onChange={(e) => setF({ ...f, descriptionSo: e.target.value })} />
        </Field>
        <Field label={t('sv.priceType')} htmlFor="spt">
          <Select id="spt" value={f.priceType} onChange={(e) => setF({ ...f, priceType: e.target.value as Service['priceType'] })}>
            {(['FIXED', 'STARTING_FROM', 'INSPECTION_REQUIRED'] as const).map((p) => (
              <option key={p} value={p}>
                {t(`price.${p}`)}
              </option>
            ))}
          </Select>
        </Field>
        <Field label={t('sv.basePrice')} htmlFor="sbp">
          <Input id="sbp" type="number" min={0} step="0.01" disabled={f.priceType === 'INSPECTION_REQUIRED'} value={f.basePrice} onChange={(e) => setF({ ...f, basePrice: e.target.value })} />
        </Field>
        <Field label={t('sv.duration')} htmlFor="sdu">
          <Input id="sdu" type="number" min={15} step={15} value={f.durationMinutes} onChange={(e) => setF({ ...f, durationMinutes: Number(e.target.value) })} />
        </Field>
        <div className="flex items-end pb-2">
          <Checkbox label={t('sv.visible')} checked={f.isActive} onChange={(v) => setF({ ...f, isActive: v })} />
        </div>
      </div>
    </Modal>
  );
}
