'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { CalendarClock, Pencil, Plus } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { pick, useI18n } from '@/lib/i18n';
import { day, money, SLOTS, todayIso } from '@/lib/format';
import { useAction, useCatalog, useTechnicians } from '@/lib/hooks';
import type { Plan, Subscription } from '@/lib/types';
import { Badge, Button, Checkbox, cx, EmptyState, Field, Input, Modal, PageHeader, Panel, Select, Skeleton, Textarea } from '@/components/ui';
import { DataTable, SearchBox, useServerList, type Column } from '@/components/ui/data-table';
import { SubscriptionStatusBadge } from '@/components/status';

export default function MaintenancePage() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const plans = useQuery({ queryKey: ['plans'], queryFn: () => api<Plan[]>('/admin/maintenance/plans') });
  const subs = useServerList<Subscription>('/admin/maintenance/subscriptions');
  const [editPlan, setEditPlan] = useState<Plan | 'new' | null>(null);
  const [visitFor, setVisitFor] = useState<Subscription | null>(null);
  const invalidate = [['/admin/maintenance/subscriptions'], ['plans']];

  const update = useAction((v: { id: string; status: string }) => api(`/admin/maintenance/subscriptions/${v.id}`, { method: 'PATCH', body: { status: v.status } }), {
    success: t('common.saved'),
    invalidate,
  });
  const run = useAction(() => api<{ reminded: number }>('/admin/maintenance/run-reminders', { method: 'POST' }), {
    success: (r) => `${r.reminded} ✓`,
  });

  const columns: Column<Subscription>[] = [
    {
      key: 'cust',
      header: t('bk.customer'),
      render: (s) => (
        <Link href={`/customers/${s.customer.id}`} className="font-medium hover:text-brand-600" onClick={(e) => e.stopPropagation()}>
          {s.customer.fullName}
          <div className="num text-[13px] font-normal text-navy-500">{s.customer.phone}</div>
        </Link>
      ),
    },
    { key: 'plan', header: t('mt.plans'), render: (s) => pick(s.plan, 'name', locale) },
    { key: 'status', header: t('common.status'), render: (s) => <SubscriptionStatusBadge status={s.status} /> },
    { key: 'next', header: t('mt.nextVisit'), sort: 'nextVisitDate', hideOnMobile: true, render: (s) => day(s.nextVisitDate, locale) },
    {
      key: 'used',
      header: t('mt.visitsUsed'),
      hideOnMobile: true,
      render: (s) => (
        <span className="num">
          {s.visitsUsed} / {Math.ceil((s.plan.visitsPerYear * s.plan.durationMonths) / 12)}
        </span>
      ),
    },
    { key: 'end', header: t('mt.ends'), sort: 'endDate', hideOnMobile: true, render: (s) => day(s.endDate, locale) },
    {
      key: 'act',
      header: '',
      className: 'text-end',
      render: (s) =>
        s.status === 'PENDING' ? (
          <Button size="sm" title={t('mt.activateHint')} onClick={() => update.mutate({ id: s.id, status: 'ACTIVE' })}>
            {t('mt.activate')}
          </Button>
        ) : s.status === 'ACTIVE' ? (
          <Button size="sm" variant="secondary" onClick={() => setVisitFor(s)}>
            {t('mt.scheduleVisit')}
          </Button>
        ) : null,
    },
  ];

  return (
    <>
      <PageHeader
        title={t('nav.maintenance')}
        actions={
          <>
            <Button variant="secondary" onClick={() => run.mutate(undefined)} loading={run.isPending}>
              {t('mt.runReminders')}
            </Button>
            {can('ADMIN') && (
              <Button icon={<Plus className="size-4" />} onClick={() => setEditPlan('new')}>
                {t('mt.newPlan')}
              </Button>
            )}
          </>
        }
      />

      <div className="mb-8 grid gap-4 md:grid-cols-3">
        {plans.isLoading
          ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-36 w-full" />)
          : plans.data?.map((p) => (
              <div key={p.id} className={cx('rounded-panel border bg-white p-5', p.isActive ? 'border-line' : 'border-dashed border-line opacity-70')}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-semibold">{pick(p, 'name', locale)}</h3>
                    <p className="num mt-1 text-xl font-semibold text-brand-600">
                      {money(p.price, p.currency, locale)}
                      <span className="text-sm font-normal text-navy-500"> / {t('mt.months', { count: p.durationMonths })}</span>
                    </p>
                  </div>
                  {can('ADMIN') && (
                    <Button variant="ghost" size="sm" onClick={() => setEditPlan(p)} aria-label={t('common.edit')}>
                      <Pencil className="size-4" />
                    </Button>
                  )}
                </div>
                <p className="mt-2 text-sm text-navy-700">{pick(p, 'description', locale)}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <Badge>
                    {p.visitsPerYear} × {t('mt.visitsPerYear').toLowerCase()}
                  </Badge>
                  <Badge>
                    {p.maxUnits} {t('bk.units').toLowerCase()}
                  </Badge>
                  <Badge tone="brand">
                    {p._count?.subscriptions ?? 0} {t('common.active').toLowerCase()}
                  </Badge>
                </div>
              </div>
            ))}
      </div>

      <h2 className="mb-3 text-lg font-semibold">{t('mt.subscriptions')}</h2>
      <DataTable
        list={subs}
        columns={columns}
        empty={<EmptyState icon={<CalendarClock className="size-5" />} title={t('mt.empty')} />}
        toolbar={
          <>
            <SearchBox value={subs.state.search} onChange={subs.setSearch} placeholder={t('cu.searchPlaceholder')} />
            <Select className="w-full sm:w-44" value={subs.state.filters.status ?? ''} onChange={(e) => subs.setFilter('status', e.target.value)} aria-label={t('common.status')}>
              <option value="">{t('common.all')}</option>
              {(['PENDING', 'ACTIVE', 'PAUSED', 'CANCELLED', 'EXPIRED'] as const).map((s) => (
                <option key={s} value={s}>
                  {t(`sub.${s}`)}
                </option>
              ))}
            </Select>
          </>
        }
      />

      {editPlan && <PlanForm plan={editPlan === 'new' ? null : editPlan} onClose={() => setEditPlan(null)} />}
      {visitFor && <VisitForm sub={visitFor} onClose={() => setVisitFor(null)} />}
    </>
  );
}

function PlanForm({ plan, onClose }: { plan: Plan | null; onClose: () => void }) {
  const { t } = useI18n();
  const [f, setF] = useState({
    nameEn: plan?.nameEn ?? '',
    nameSo: plan?.nameSo ?? '',
    descriptionEn: plan?.descriptionEn ?? '',
    descriptionSo: plan?.descriptionSo ?? '',
    price: plan ? String(Number(plan.price)) : '',
    durationMonths: plan?.durationMonths ?? 12,
    visitsPerYear: plan?.visitsPerYear ?? 4,
    maxUnits: plan?.maxUnits ?? 2,
    isActive: plan?.isActive ?? true,
  });
  const save = useAction(
    () => {
      const body = { ...f, price: Number(f.price), durationMonths: Number(f.durationMonths), visitsPerYear: Number(f.visitsPerYear), maxUnits: Number(f.maxUnits) };
      return plan ? api(`/admin/maintenance/plans/${plan.id}`, { method: 'PATCH', body }) : api('/admin/maintenance/plans', { body });
    },
    { success: t('common.saved'), invalidate: [['plans']], onSuccess: onClose },
  );
  return (
    <Modal
      open
      onClose={onClose}
      title={plan ? plan.nameEn : t('mt.newPlan')}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => save.mutate(undefined)} loading={save.isPending} disabled={!f.nameEn || !f.nameSo || f.price === ''}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={t('sv.nameEn')} htmlFor="pne">
          <Input id="pne" value={f.nameEn} onChange={(e) => setF({ ...f, nameEn: e.target.value })} />
        </Field>
        <Field label={t('sv.nameSo')} htmlFor="pns">
          <Input id="pns" value={f.nameSo} onChange={(e) => setF({ ...f, nameSo: e.target.value })} />
        </Field>
        <Field label={t('sv.descEn')} htmlFor="pde" optional>
          <Textarea id="pde" value={f.descriptionEn} onChange={(e) => setF({ ...f, descriptionEn: e.target.value })} />
        </Field>
        <Field label={t('sv.descSo')} htmlFor="pds" optional>
          <Textarea id="pds" value={f.descriptionSo} onChange={(e) => setF({ ...f, descriptionSo: e.target.value })} />
        </Field>
        <Field label={t('common.price')} htmlFor="pp">
          <Input id="pp" type="number" min={0} step="0.01" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} />
        </Field>
        <Field label={t('mt.duration')} htmlFor="pdm">
          <Input id="pdm" type="number" min={1} value={f.durationMonths} onChange={(e) => setF({ ...f, durationMonths: Number(e.target.value) })} />
        </Field>
        <Field label={t('mt.visitsPerYear')} htmlFor="pv">
          <Input id="pv" type="number" min={1} value={f.visitsPerYear} onChange={(e) => setF({ ...f, visitsPerYear: Number(e.target.value) })} />
        </Field>
        <Field label={t('mt.maxUnits')} htmlFor="pmu">
          <Input id="pmu" type="number" min={1} value={f.maxUnits} onChange={(e) => setF({ ...f, maxUnits: Number(e.target.value) })} />
        </Field>
        <Checkbox label={t('sv.visible')} checked={f.isActive} onChange={(v) => setF({ ...f, isActive: v })} />
      </div>
    </Modal>
  );
}

function VisitForm({ sub, onClose }: { sub: Subscription; onClose: () => void }) {
  const { t, locale } = useI18n();
  const catalog = useCatalog();
  const maintenanceService = catalog.data?.flatMap((c) => c.services ?? []).find((s) => s.slug === 'preventive-maintenance');
  const [f, setF] = useState({ serviceId: '', scheduledDate: sub.nextVisitDate?.slice(0, 10) ?? todayIso(), timeSlot: 'MORNING', technicianId: '' });
  const techs = useTechnicians(f.scheduledDate);
  const serviceId = f.serviceId || maintenanceService?.id || '';

  const save = useAction(
    () => api(`/admin/maintenance/subscriptions/${sub.id}/visits`, { body: { ...f, serviceId, technicianId: f.technicianId || undefined } }),
    { success: t('common.saved'), invalidate: [['/admin/maintenance/subscriptions'], ['/admin/bookings']], onSuccess: onClose },
  );

  return (
    <Modal
      open
      onClose={onClose}
      title={`${t('mt.scheduleVisit')} · ${sub.customer.fullName}`}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => save.mutate(undefined)} loading={save.isPending} disabled={!serviceId}>
            {t('mt.scheduleVisit')}
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label={t('bk.service')} htmlFor="vs">
            <Select id="vs" value={serviceId} onChange={(e) => setF({ ...f, serviceId: e.target.value })}>
              {catalog.data?.map((c) => (
                <optgroup key={c.id} label={pick(c, 'name', locale)}>
                  {c.services?.map((s) => (
                    <option key={s.id} value={s.id}>
                      {pick(s, 'name', locale)}
                    </option>
                  ))}
                </optgroup>
              ))}
            </Select>
          </Field>
        </div>
        <Field label={t('common.date')} htmlFor="vd">
          <Input id="vd" type="date" value={f.scheduledDate} onChange={(e) => setF({ ...f, scheduledDate: e.target.value })} />
        </Field>
        <Field label={t('bk.timeSlot')} htmlFor="vt">
          <Select id="vt" value={f.timeSlot} onChange={(e) => setF({ ...f, timeSlot: e.target.value })}>
            {SLOTS.map((s) => (
              <option key={s} value={s}>
                {t(`slot.${s}`)}
              </option>
            ))}
          </Select>
        </Field>
        <div className="sm:col-span-2">
          <Field label={t('bk.technician')} htmlFor="vtech" optional>
            <Select id="vtech" value={f.technicianId} onChange={(e) => setF({ ...f, technicianId: e.target.value })}>
              <option value="">{t('common.unassigned')}</option>
              {techs.data?.data.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.fullName} — {t('bk.jobsThatDay', { count: x.jobsOnDate ?? 0 })}
                </option>
              ))}
            </Select>
          </Field>
        </div>
      </div>
    </Modal>
  );
}
