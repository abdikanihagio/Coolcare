'use client';

import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Star } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { pick, useI18n } from '@/lib/i18n';
import { day } from '@/lib/format';
import { useAction } from '@/lib/hooks';
import type { Booking, Technician } from '@/lib/types';
import { Badge, Button, ConfirmDialog, ErrorState, KeyValue, Panel, Spinner } from '@/components/ui';
import { BookingStatusBadge } from '@/components/status';
import { TechnicianForm } from '@/components/technician-form';

export default function TechnicianDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [removing, setRemoving] = useState(false);
  const q = useQuery({ queryKey: ['technician', id], queryFn: () => api<Technician & { bookings: Booking[] }>(`/admin/technicians/${id}`) });
  const remove = useAction(() => api(`/admin/technicians/${id}`, { method: 'DELETE' }), {
    success: t('common.saved'),
    invalidate: [['/admin/technicians']],
    onSuccess: () => router.replace('/technicians'),
  });

  if (q.isLoading) return <Spinner label={t('common.loading')} />;
  if (q.isError || !q.data) return <ErrorState message={(q.error as Error)?.message ?? t('err.loadFailed')} onRetry={() => q.refetch()} />;
  const x = q.data;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/technicians" className="inline-flex items-center gap-1 text-sm text-navy-500 hover:text-navy-900">
          <ArrowLeft className="size-4 rtl:rotate-180" />
          {t('te.title')}
        </Link>
        <div className="mt-2 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold tracking-tight">{x.fullName}</h1>
            <Badge tone={x.status === 'ACTIVE' ? 'ok' : 'warn'}>{t(`tech.${x.status}`)}</Badge>
          </div>
          <div className="flex gap-2">
            {can('ADMIN', 'DISPATCHER') && (
              <Button variant="secondary" onClick={() => setEditing(true)}>
                {t('common.edit')}
              </Button>
            )}
            {can('ADMIN') && (
              <Button variant="ghost" onClick={() => setRemoving(true)}>
                {t('te.remove')}
              </Button>
            )}
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[22rem_1fr]">
        <Panel>
          <dl>
            <KeyValue label={t('common.phone')}>
              <a className="num hover:text-brand-600" href={`tel:${x.phone}`}>
                {x.phone}
              </a>
            </KeyValue>
            <KeyValue label={t('common.email')}>{x.email ?? '—'}</KeyValue>
            <KeyValue label={t('te.available')}>{x.isAvailable ? t('common.yes') : t('common.no')}</KeyValue>
            <KeyValue label={t('te.completed')}>
              <span className="num">{x.jobsCompleted}</span>
            </KeyValue>
            <KeyValue label={t('te.rating')}>
              {Number(x.rating) > 0 ? (
                <span className="num inline-flex items-center gap-1">
                  <Star className="size-3.5 fill-warn-600 text-warn-600" />
                  {Number(x.rating).toFixed(2)}
                </span>
              ) : (
                '—'
              )}
            </KeyValue>
            <KeyValue label={t('te.specialties')}>
              <div className="flex flex-wrap gap-1">
                {x.specialties.map((s) => (
                  <Badge key={s}>{t(`equip.${s}`)}</Badge>
                ))}
              </div>
            </KeyValue>
          </dl>
          {x.notes && <p className="mt-4 whitespace-pre-line rounded-lg bg-surface p-3 text-sm">{x.notes}</p>}
        </Panel>

        <Panel title={t('te.recentJobs')} bodyClassName="p-0">
          {x.bookings.length ? (
            <ul className="divide-y divide-line">
              {x.bookings.map((b) => (
                <li key={b.id}>
                  <Link href={`/bookings/${b.id}`} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-sm hover:bg-surface">
                    <span>
                      <span className="num font-medium">{b.reference}</span>{' '}
                      <span className="text-navy-500">
                        · {pick(b.service, 'name', locale)} · {b.customer?.fullName}
                      </span>
                    </span>
                    <span className="flex items-center gap-3">
                      <span className="text-navy-500">
                        {day(b.scheduledDate, locale)} · {t(`slot.${b.timeSlot}`)}
                      </span>
                      <BookingStatusBadge status={b.status} />
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-5 py-6 text-sm text-navy-500">—</p>
          )}
        </Panel>
      </div>

      {editing && <TechnicianForm tech={x} onClose={() => setEditing(false)} />}
      <ConfirmDialog
        open={removing}
        title={t('te.remove')}
        message={t('te.removeConfirm', { name: x.fullName })}
        confirmLabel={t('te.remove')}
        cancelLabel={t('common.cancel')}
        loading={remove.isPending}
        onClose={() => setRemoving(false)}
        onConfirm={() => remove.mutate(undefined)}
      />
    </div>
  );
}
