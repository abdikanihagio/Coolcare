'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Plus, Star, Wrench } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import type { Technician } from '@/lib/types';
import { Badge, Button, EmptyState, PageHeader, Select } from '@/components/ui';
import { DataTable, SearchBox, useServerList, type Column } from '@/components/ui/data-table';
import { TechnicianForm } from '@/components/technician-form';

export default function TechniciansPage() {
  const { t } = useI18n();
  const { can } = useAuth();
  const router = useRouter();
  const [adding, setAdding] = useState(false);
  const list = useServerList<Technician>('/admin/technicians', { sortBy: 'fullName', sortOrder: 'asc' });

  const columns: Column<Technician>[] = [
    {
      key: 'name',
      header: t('common.name'),
      sort: 'fullName',
      render: (x) => (
        <div>
          <div className="font-medium">{x.fullName}</div>
          <div className="num text-[13px] text-navy-500">{x.phone}</div>
        </div>
      ),
    },
    {
      key: 'spec',
      header: t('te.specialties'),
      hideOnMobile: true,
      render: (x) => (
        <div className="flex flex-wrap gap-1">
          {x.specialties.map((s) => (
            <Badge key={s}>{t(`equip.${s}`)}</Badge>
          ))}
        </div>
      ),
    },
    {
      key: 'status',
      header: t('common.status'),
      render: (x) => (
        <div className="flex flex-wrap gap-1">
          <Badge tone={x.status === 'ACTIVE' ? 'ok' : x.status === 'ON_LEAVE' ? 'warn' : 'neutral'}>{t(`tech.${x.status}`)}</Badge>
          {x.status === 'ACTIVE' && !x.isAvailable && <Badge tone="warn">{t('te.unavailable')}</Badge>}
        </div>
      ),
    },
    { key: 'active', header: t('te.activeJobs'), className: 'text-end', hideOnMobile: true, render: (x) => <span className="num">{x.activeJobs ?? 0}</span> },
    { key: 'done', header: t('te.completed'), sort: 'jobsCompleted', className: 'text-end', hideOnMobile: true, render: (x) => <span className="num">{x.jobsCompleted}</span> },
    {
      key: 'rating',
      header: t('te.rating'),
      sort: 'rating',
      className: 'text-end',
      render: (x) =>
        Number(x.rating) > 0 ? (
          <span className="num inline-flex items-center gap-1">
            <Star className="size-3.5 fill-warn-600 text-warn-600" />
            {Number(x.rating).toFixed(1)}
          </span>
        ) : (
          '—'
        ),
    },
  ];

  return (
    <>
      <PageHeader
        title={t('te.title')}
        actions={
          can('ADMIN') && (
            <Button icon={<Plus className="size-4" />} onClick={() => setAdding(true)}>
              {t('te.new')}
            </Button>
          )
        }
      />
      <DataTable
        list={list}
        columns={columns}
        onRowClick={(x) => router.push(`/technicians/${x.id}`)}
        empty={<EmptyState icon={<Wrench className="size-5" />} title={t('te.empty')} />}
        toolbar={
          <>
            <SearchBox value={list.state.search} onChange={list.setSearch} placeholder={t('common.search')} />
            <Select className="w-full sm:w-44" value={list.state.filters.status ?? ''} onChange={(e) => list.setFilter('status', e.target.value)} aria-label={t('common.status')}>
              <option value="">{t('common.all')}</option>
              {(['ACTIVE', 'ON_LEAVE', 'INACTIVE'] as const).map((s) => (
                <option key={s} value={s}>
                  {t(`tech.${s}`)}
                </option>
              ))}
            </Select>
          </>
        }
      />
      {adding && <TechnicianForm tech={null} onClose={() => setAdding(false)} />}
    </>
  );
}
