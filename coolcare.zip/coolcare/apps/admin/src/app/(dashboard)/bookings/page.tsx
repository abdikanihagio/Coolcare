'use client';

import { Suspense, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { ClipboardList, Plus } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { pick, useI18n } from '@/lib/i18n';
import { BOOKING_STATUSES, day, money, SLOTS, todayIso } from '@/lib/format';
import { useAction, useCatalog, useTechnicians } from '@/lib/hooks';
import type { Address, Booking, Customer } from '@/lib/types';
import { Button, Checkbox, EmptyState, Field, Input, Modal, PageHeader, Select, Spinner, Textarea } from '@/components/ui';
import { DataTable, SearchBox, useServerList, type Column } from '@/components/ui/data-table';
import { BookingStatusBadge, PriorityBadge } from '@/components/status';

export default function BookingsPage() {
  return (
    <Suspense fallback={<Spinner />}>
      <BookingsList />
    </Suspense>
  );
}

function BookingsList() {
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const router = useRouter();
  const params = useSearchParams();
  const [creating, setCreating] = useState(false);

  const list = useServerList<Booking>('/admin/bookings', {
    filters: {
      status: params.get('status') ?? undefined,
      unassigned: params.get('unassigned') ?? undefined,
      scope: params.get('scope') ?? undefined,
      customerId: params.get('customerId') ?? undefined,
    },
  });

  const columns: Column<Booking>[] = [
    {
      key: 'ref',
      header: t('bk.reference'),
      sort: 'reference',
      render: (b) => (
        <div>
          <div className="num font-medium">{b.reference}</div>
          <div className="mt-0.5 md:hidden">
            <BookingStatusBadge status={b.status} />
          </div>
        </div>
      ),
    },
    {
      key: 'customer',
      header: t('bk.customer'),
      render: (b) => (
        <div className="min-w-0">
          <div className="truncate">{b.customer?.fullName}</div>
          <div className="num text-[13px] text-navy-500">{b.customer?.phone}</div>
        </div>
      ),
    },
    { key: 'service', header: t('bk.service'), hideOnMobile: true, render: (b) => pick(b.service, 'name', locale) },
    {
      key: 'date',
      header: t('bk.scheduled'),
      sort: 'scheduledDate',
      hideOnMobile: true,
      render: (b) => (
        <div>
          <div>{day(b.scheduledDate, locale)}</div>
          <div className="text-[13px] text-navy-500">{t(`slot.${b.timeSlot}`)}</div>
        </div>
      ),
    },
    {
      key: 'tech',
      header: t('bk.technician'),
      hideOnMobile: true,
      render: (b) => (b.technician ? b.technician.fullName : <span className="text-warn-700">{t('common.unassigned')}</span>),
    },
    {
      key: 'status',
      header: t('common.status'),
      sort: 'status',
      hideOnMobile: true,
      render: (b) => (
        <div className="flex flex-wrap gap-1">
          <BookingStatusBadge status={b.status} />
          <PriorityBadge priority={b.priority} />
        </div>
      ),
    },
    {
      key: 'est',
      header: t('bk.estimate'),
      className: 'text-end',
      hideOnMobile: true,
      render: (b) => <span className="num">{b.estimatedPrice ? money(b.estimatedPrice, 'USD', locale) : '—'}</span>,
    },
  ];

  return (
    <>
      <PageHeader
        title={t('bk.title')}
        actions={
          can('ADMIN', 'DISPATCHER') && (
            <Button icon={<Plus className="size-4" />} onClick={() => setCreating(true)}>
              {t('bk.new')}
            </Button>
          )
        }
      />
      <DataTable
        list={list}
        columns={columns}
        onRowClick={(b) => router.push(`/bookings/${b.id}`)}
        empty={<EmptyState icon={<ClipboardList className="size-5" />} title={t('bk.empty')} />}
        toolbar={
          <>
            <SearchBox value={list.state.search} onChange={list.setSearch} placeholder={t('bk.searchPlaceholder')} />
            <Select
              className="w-full sm:w-48"
              value={list.state.filters.status ?? ''}
              onChange={(e) => list.setFilter('status', e.target.value)}
              aria-label={t('common.status')}
            >
              <option value="">{t('common.all')}</option>
              {BOOKING_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {t(`status.${s}`)}
                </option>
              ))}
            </Select>
            <Input
              type="date"
              className="w-full sm:w-40"
              value={list.state.filters.dateFrom ?? ''}
              onChange={(e) => list.setFilter('dateFrom', e.target.value)}
              aria-label={t('common.from')}
            />
            <Input
              type="date"
              className="w-full sm:w-40"
              value={list.state.filters.dateTo ?? ''}
              onChange={(e) => list.setFilter('dateTo', e.target.value)}
              aria-label={t('common.to')}
            />
            <Checkbox
              label={t('bk.onlyUnassigned')}
              checked={list.state.filters.unassigned === 'true'}
              onChange={(v) => list.setFilter('unassigned', v ? 'true' : undefined)}
            />
          </>
        }
      />
      {creating && <CreateBookingModal onClose={() => setCreating(false)} onCreated={(b) => router.push(`/bookings/${b.id}`)} />}
    </>
  );
}

function CreateBookingModal({ onClose, onCreated }: { onClose: () => void; onCreated: (b: Booking) => void }) {
  const { t, locale } = useI18n();
  const catalog = useCatalog();
  const [customerSearch, setCustomerSearch] = useState('');
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [form, setForm] = useState({
    serviceId: '',
    addressId: '',
    addressText: '',
    scheduledDate: todayIso(),
    timeSlot: 'MORNING',
    priority: 'NORMAL',
    unitCount: 1,
    problemDescription: '',
    internalNotes: '',
    technicianId: '',
  });
  const techs = useTechnicians(form.scheduledDate);

  const customers = useQuery({
    queryKey: ['customer-search', customerSearch],
    queryFn: () => api<{ data: Customer[] }>('/admin/customers', { query: { search: customerSearch, pageSize: 8 } }),
    enabled: customerSearch.trim().length >= 2 && !customer,
  });
  const detail = useQuery({
    queryKey: ['customer', customer?.id],
    queryFn: () => api<{ addresses: Address[] }>(`/admin/customers/${customer!.id}`),
    enabled: !!customer,
  });

  useEffect(() => {
    const def = detail.data?.addresses.find((a) => a.isDefault) ?? detail.data?.addresses[0];
    if (def) setForm((f) => ({ ...f, addressId: def.id }));
  }, [detail.data]);

  const create = useAction(
    () =>
      api<Booking>('/admin/bookings', {
        body: {
          customerId: customer!.id,
          serviceId: form.serviceId,
          addressId: form.addressId || undefined,
          addressText: form.addressId ? undefined : form.addressText,
          scheduledDate: form.scheduledDate,
          timeSlot: form.timeSlot,
          priority: form.priority,
          unitCount: Number(form.unitCount),
          problemDescription: form.problemDescription || undefined,
          internalNotes: form.internalNotes || undefined,
          technicianId: form.technicianId || undefined,
        },
      }),
    { success: (b) => t('bk.created', { ref: b.reference }), invalidate: [['/admin/bookings'], ['overview']], onSuccess: onCreated },
  );

  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const valid = customer && form.serviceId && (form.addressId || form.addressText.trim()) && form.scheduledDate;

  return (
    <Modal
      open
      onClose={onClose}
      title={t('bk.new')}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => create.mutate(undefined)} loading={create.isPending} disabled={!valid}>
            {t('common.create')}
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label={t('bk.customer')} htmlFor="cust">
            {customer ? (
              <div className="flex items-center justify-between rounded-ctl border border-line px-3 py-2 text-sm">
                <span>
                  {customer.fullName} <span className="num text-navy-500">· {customer.phone}</span>
                </span>
                <Button variant="ghost" size="sm" onClick={() => setCustomer(null)}>
                  {t('common.edit')}
                </Button>
              </div>
            ) : (
              <div className="relative">
                <Input id="cust" value={customerSearch} onChange={(e) => setCustomerSearch(e.target.value)} placeholder={t('bk.selectCustomer')} autoComplete="off" />
                {!!customers.data?.data.length && (
                  <ul className="absolute inset-x-0 top-full z-10 mt-1 max-h-60 overflow-auto rounded-ctl border border-line bg-white shadow-lg">
                    {customers.data.data.map((c) => (
                      <li key={c.id}>
                        <button type="button" className="w-full px-3 py-2 text-start text-sm hover:bg-brand-50" onClick={() => setCustomer(c)}>
                          {c.fullName} <span className="num text-navy-500">· {c.phone}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </Field>
        </div>

        <Field label={t('bk.service')} htmlFor="svc">
          <Select id="svc" value={form.serviceId} onChange={set('serviceId')}>
            <option value="">—</option>
            {catalog.data?.map((c) => (
              <optgroup key={c.id} label={pick(c, 'name', locale)}>
                {c.services?.map((s) => (
                  <option key={s.id} value={s.id}>
                    {pick(s, 'name', locale)}
                  </option>
                ))}
              </optgroup>
            ))}
          </Select>
        </Field>

        <Field label={t('bk.address')} htmlFor="addr">
          {detail.data?.addresses.length ? (
            <Select id="addr" value={form.addressId} onChange={set('addressId')}>
              {detail.data.addresses.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.label} — {a.district}
                </option>
              ))}
              <option value="">{t('bk.addressText')}…</option>
            </Select>
          ) : (
            <Input id="addr" value={form.addressText} onChange={set('addressText')} placeholder="Hodan, near KM4" />
          )}
        </Field>
        {!!detail.data?.addresses.length && !form.addressId && (
          <div className="sm:col-span-2">
            <Field label={t('bk.addressText')} htmlFor="addrText">
              <Input id="addrText" value={form.addressText} onChange={set('addressText')} />
            </Field>
          </div>
        )}

        <Field label={t('common.date')} htmlFor="date">
          <Input id="date" type="date" value={form.scheduledDate} onChange={set('scheduledDate')} />
        </Field>
        <Field label={t('bk.timeSlot')} htmlFor="slot">
          <Select id="slot" value={form.timeSlot} onChange={set('timeSlot')}>
            {SLOTS.map((s) => (
              <option key={s} value={s}>
                {t(`slot.${s}`)}
              </option>
            ))}
          </Select>
        </Field>
        <Field label={t('bk.priority')} htmlFor="prio">
          <Select id="prio" value={form.priority} onChange={set('priority')}>
            {['NORMAL', 'URGENT', 'EMERGENCY'].map((p) => (
              <option key={p} value={p}>
                {t(`priority.${p}`)}
              </option>
            ))}
          </Select>
        </Field>
        <Field label={t('bk.units')} htmlFor="units">
          <Input id="units" type="number" min={1} max={50} value={form.unitCount} onChange={set('unitCount')} />
        </Field>
        <div className="sm:col-span-2">
          <Field label={t('bk.technician')} htmlFor="tech" optional>
            <Select id="tech" value={form.technicianId} onChange={set('technicianId')}>
              <option value="">{t('common.unassigned')}</option>
              {techs.data?.data.map((tech) => (
                <option key={tech.id} value={tech.id} disabled={!tech.isAvailable}>
                  {tech.fullName} — {t('bk.jobsThatDay', { count: tech.jobsOnDate ?? 0 })}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label={t('bk.problem')} htmlFor="problem" optional>
            <Textarea id="problem" value={form.problemDescription} onChange={set('problemDescription')} />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label={t('bk.internal')} hint={t('bk.internalHint')} htmlFor="internal" optional>
            <Textarea id="internal" value={form.internalNotes} onChange={set('internalNotes')} />
          </Field>
        </div>
      </div>
    </Modal>
  );
}
