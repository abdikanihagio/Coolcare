'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Camera, MapPin, MessageCircle, Phone, Plus, Star, Trash2 } from 'lucide-react';
import { api, uploadImage } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { pick, useI18n } from '@/lib/i18n';
import { dateTime, day, mapsUrl, money, SLOTS } from '@/lib/format';
import { useAction, useTechnicians } from '@/lib/hooks';
import type { Booking, BookingStatus, Quote } from '@/lib/types';
import { Badge, Button, ConfirmDialog, ErrorState, Field, Input, KeyValue, Modal, Panel, Select, Spinner, Textarea, cx } from '@/components/ui';
import { BookingStatusBadge, InvoiceStatusBadge, PaymentStatusBadge, PriorityBadge, QuoteStatusBadge } from '@/components/status';
import { QuoteEditor } from '@/components/quote-editor';
import { RecordPaymentModal } from '@/components/record-payment';

/** Forward actions shown as primary buttons; other allowed transitions go in the "Move to" menu. */
const NEXT_STEP: Partial<Record<BookingStatus, BookingStatus>> = {
  PENDING: 'CONFIRMED',
  ASSIGNED: 'ON_THE_WAY',
  ON_THE_WAY: 'IN_PROGRESS',
  IN_PROGRESS: 'COMPLETED',
};

export default function BookingDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const key = ['booking', id];
  const q = useQuery({ queryKey: key, queryFn: () => api<Booking>(`/admin/bookings/${id}`) });
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [quoteEdit, setQuoteEdit] = useState<Quote | 'new' | null>(null);
  const [paying, setPaying] = useState(false);
  const [voiding, setVoiding] = useState(false);

  const invalidate = [key, ['/admin/bookings'], ['overview']];
  const setStatus = useAction(
    (vars: { status: BookingStatus; note?: string }) => api<Booking>(`/admin/bookings/${id}/status`, { body: vars }),
    { success: (b) => t('bk.statusUpdated', { status: t(`status.${b.status}`) }), invalidate, onSuccess: () => setCancelOpen(false) },
  );
  const issueInvoice = useAction(() => api(`/admin/bookings/${id}/invoice`, { method: 'POST' }), { invalidate });
  const voidInvoice = useAction(() => api(`/admin/invoices/${q.data?.invoice?.id}/void`, { method: 'POST' }), {
    invalidate,
    onSuccess: () => setVoiding(false),
  });
  const sendQuote = useAction((quoteId: string) => api(`/admin/quotes/${quoteId}/send`, { method: 'POST' }), { success: t('q.sent'), invalidate });
  const deleteQuote = useAction((quoteId: string) => api(`/admin/quotes/${quoteId}`, { method: 'DELETE' }), { invalidate });

  if (q.isLoading) return <Spinner label={t('common.loading')} />;
  if (q.isError || !q.data) return <ErrorState message={(q.error as Error)?.message ?? t('err.loadFailed')} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />;

  const b = q.data;
  const ops = can('ADMIN', 'DISPATCHER');
  const finance = can('ADMIN', 'ACCOUNTANT');
  const closed = b.status === 'COMPLETED' || b.status === 'CANCELLED';
  const next = NEXT_STEP[b.status];
  const others = (b.allowedTransitions ?? []).filter((s) => s !== next && s !== 'CANCELLED' && s !== 'ASSIGNED');
  const balance = b.invoice ? Number(b.invoice.total) - Number(b.invoice.amountPaid) : 0;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/bookings" className="inline-flex items-center gap-1 text-sm text-navy-500 hover:text-navy-900">
          <ArrowLeft className="size-4 rtl:rotate-180" />
          {t('bk.title')}
        </Link>
        <div className="mt-2 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="num text-2xl font-semibold tracking-tight">{b.reference}</h1>
            <BookingStatusBadge status={b.status} />
            <PriorityBadge priority={b.priority} />
          </div>
          {ops && !closed && (
            <div className="flex flex-wrap items-center gap-2">
              {others.length > 0 && (
                <Select
                  className="h-10 w-auto"
                  value=""
                  aria-label={t('bk.moveTo')}
                  onChange={(e) => e.target.value && setStatus.mutate({ status: e.target.value as BookingStatus })}
                >
                  <option value="">{t('bk.moveTo')}…</option>
                  {others.map((s) => (
                    <option key={s} value={s}>
                      {t(`status.${s}`)}
                    </option>
                  ))}
                </Select>
              )}
              {(b.allowedTransitions ?? []).includes('CANCELLED') && (
                <Button variant="secondary" onClick={() => setCancelOpen(true)}>
                  {t('bk.cancelBooking')}
                </Button>
              )}
              {next && (b.allowedTransitions ?? []).includes(next) && (next !== 'ON_THE_WAY' || b.technician) && (
                <Button onClick={() => setStatus.mutate({ status: next })} loading={setStatus.isPending}>
                  {t(`status.${next}`)}
                </Button>
              )}
            </div>
          )}
        </div>
        {b.status === 'CANCELLED' && b.cancelledReason && <p className="mt-2 text-sm text-bad-700">{b.cancelledReason}</p>}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_22rem]">
        <div className="min-w-0 space-y-6">
          <Panel title={pick(b.service, 'name', locale)}>
            <dl>
              <KeyValue label={t('bk.scheduled')}>
                {day(b.scheduledDate, locale)} · {t(`slot.${b.timeSlot}`)}
              </KeyValue>
              <KeyValue label={t('bk.units')}>{b.unitCount}</KeyValue>
              <KeyValue label={t('bk.estimate')}>
                <span className="num">{b.estimatedPrice ? money(b.estimatedPrice, 'USD', locale) : t('price.INSPECTION_REQUIRED')}</span>
              </KeyValue>
              {b.equipment && (
                <KeyValue label={t('bk.equipment')}>
                  {t(`equip.${b.equipment.type}`)} {[b.equipment.brand, b.equipment.model, b.equipment.capacity].filter(Boolean).join(' · ')}
                </KeyValue>
              )}
              {b.rating && (
                <KeyValue label={t('bk.rating')}>
                  <span className="inline-flex items-center gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={cx('size-4', i < b.rating! ? 'fill-warn-600 text-warn-600' : 'text-line')} />
                    ))}
                  </span>
                  {b.review && <p className="mt-1 text-navy-700">“{b.review}”</p>}
                </KeyValue>
              )}
            </dl>
            {(b.problemDescription || b.customerNotes) && (
              <div className="mt-4 rounded-lg bg-surface p-4 text-sm">
                <p className="mb-1 font-medium text-navy-700">{t('bk.problem')}</p>
                <p className="whitespace-pre-line text-navy-900">{b.problemDescription}</p>
                {b.customerNotes && <p className="mt-2 whitespace-pre-line text-navy-700">{b.customerNotes}</p>}
              </div>
            )}
          </Panel>

          {/* Quotations */}
          <Panel
            title={t('q.title')}
            action={
              ops &&
              !closed && (
                <Button size="sm" variant="secondary" icon={<Plus className="size-4" />} onClick={() => setQuoteEdit('new')}>
                  {t('q.new')}
                </Button>
              )
            }
            bodyClassName="p-0"
          >
            {b.quotes?.length ? (
              <ul className="divide-y divide-line">
                {b.quotes.map((quote) => (
                  <li key={quote.id} className="px-5 py-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="num font-medium">{quote.number}</span>
                        <QuoteStatusBadge status={quote.status} />
                      </div>
                      <span className="num text-base font-semibold">{money(quote.total, quote.currency, locale)}</span>
                    </div>
                    <table className="mt-3 w-full text-[13px]">
                      <tbody>
                        {quote.items.map((it, i) => (
                          <tr key={i} className="text-navy-700">
                            <td className="py-0.5">
                              {it.description} <span className="text-navy-500">({t(`q.kind.${it.kind}`)})</span>
                            </td>
                            <td className="num py-0.5 text-end text-navy-500">
                              {Number(it.quantity)} × {money(it.unitPrice, quote.currency, locale)}
                            </td>
                            <td className="num w-24 py-0.5 text-end">{money(it.total ?? 0, quote.currency, locale)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {quote.status === 'REJECTED' && quote.rejectionReason && (
                      <p className="mt-2 text-[13px] text-bad-700">
                        {t('q.rejectReason')}: {quote.rejectionReason}
                      </p>
                    )}
                    {quote.status === 'DRAFT' && ops && (
                      <div className="mt-3 flex gap-2">
                        <Button size="sm" onClick={() => sendQuote.mutate(quote.id)} loading={sendQuote.isPending}>
                          {t('q.send')}
                        </Button>
                        <Button size="sm" variant="secondary" onClick={() => setQuoteEdit(quote)}>
                          {t('common.edit')}
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => deleteQuote.mutate(quote.id)}>
                          {t('common.delete')}
                        </Button>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-5 py-6 text-sm text-navy-500">{t('q.empty')}</p>
            )}
          </Panel>

          {/* Invoice & payments */}
          <Panel
            title={b.invoice ? `${t('inv.number')} ${b.invoice.number}` : t('nav.invoices')}
            action={b.invoice && <InvoiceStatusBadge status={b.invoice.status} />}
          >
            {b.invoice && b.invoice.status !== 'VOID' ? (
              <>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-navy-500">{t('common.total')}</div>
                    <div className="num mt-0.5 text-lg font-semibold">{money(b.invoice.total, b.invoice.currency, locale)}</div>
                  </div>
                  <div>
                    <div className="text-navy-500">{t('inv.paid')}</div>
                    <div className="num mt-0.5 text-lg font-semibold text-ok-700">{money(b.invoice.amountPaid, b.invoice.currency, locale)}</div>
                  </div>
                  <div>
                    <div className="text-navy-500">{t('inv.balance')}</div>
                    <div className={cx('num mt-0.5 text-lg font-semibold', balance > 0 && 'text-warn-700')}>{money(balance, b.invoice.currency, locale)}</div>
                  </div>
                </div>
                {!!b.invoice.payments?.length && (
                  <ul className="mt-4 divide-y divide-line border-t border-line text-sm">
                    {b.invoice.payments.map((p) => (
                      <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                        <span>
                          {t(`method.${p.method}`)} {p.reference && <span className="num text-navy-500">· {p.reference}</span>}
                        </span>
                        <span className="flex items-center gap-3">
                          <span className="text-[13px] text-navy-500">{dateTime(p.paidAt, locale)}</span>
                          <span className="num font-medium">{money(p.amount, p.currency, locale)}</span>
                          <PaymentStatusBadge status={p.status} />
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
                <div className="mt-4 flex flex-wrap gap-2">
                  {finance && balance > 0 && <Button onClick={() => setPaying(true)}>{t('inv.recordPayment')}</Button>}
                  <Link href={`/invoices/${b.invoice.id}`}>
                    <Button variant="secondary">{t('common.view')}</Button>
                  </Link>
                  {finance && Number(b.invoice.amountPaid) === 0 && (
                    <Button variant="ghost" onClick={() => setVoiding(true)}>
                      {t('inv.void')}
                    </Button>
                  )}
                </div>
              </>
            ) : (
              <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-navy-500">
                <span>{t('inv.empty')}</span>
                {finance && b.status !== 'CANCELLED' && (
                  <Button variant="secondary" onClick={() => issueInvoice.mutate(undefined)} loading={issueInvoice.isPending}>
                    {t('inv.issue')}
                  </Button>
                )}
              </div>
            )}
          </Panel>

          <PhotosPanel booking={b} canEdit={ops} />
          <TimelinePanel booking={b} />
        </div>

        <aside className="space-y-6">
          <Panel title={t('bk.customer')}>
            <Link href={`/customers/${b.customer?.id}`} className="font-medium hover:text-brand-600">
              {b.customer?.fullName}
            </Link>
            <div className="mt-3 flex flex-wrap gap-2">
              <a href={`tel:${b.customer?.phone}`} className="inline-flex items-center gap-1.5 rounded-ctl border border-line px-3 py-1.5 text-sm hover:bg-surface">
                <Phone className="size-4" />
                <span className="num">{b.customer?.phone}</span>
              </a>
              <a
                href={`https://wa.me/${b.customer?.phone.replace(/\D/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 rounded-ctl border border-line px-3 py-1.5 text-sm hover:bg-surface"
              >
                <MessageCircle className="size-4" />
                WhatsApp
              </a>
            </div>
            <div className="mt-4 border-t border-line pt-4 text-sm">
              <p className="text-navy-500">{t('bk.address')}</p>
              <p className="mt-1">{b.addressText}</p>
              <a
                href={mapsUrl(b.latitude, b.longitude, b.addressText)}
                target="_blank"
                rel="noreferrer"
                className="mt-2 inline-flex items-center gap-1 text-brand-600 hover:underline"
              >
                <MapPin className="size-4" />
                {t('bk.openMap')}
              </a>
            </div>
          </Panel>

          <AssignPanel booking={b} canEdit={ops && !closed} />
          {ops && <SchedulePanel booking={b} closed={closed} />}
        </aside>
      </div>

      <ConfirmDialog
        open={cancelOpen}
        title={t('bk.cancelBooking')}
        message={t('bk.cancelConfirm', { ref: b.reference })}
        confirmLabel={t('bk.cancelBooking')}
        cancelLabel={t('common.close')}
        loading={setStatus.isPending}
        onClose={() => setCancelOpen(false)}
        onConfirm={() => setStatus.mutate({ status: 'CANCELLED', note: cancelReason || undefined })}
      >
        <Field label={t('bk.cancelReason')} htmlFor="reason" optional>
          <Textarea id="reason" value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} />
        </Field>
      </ConfirmDialog>

      {b.invoice && (
        <ConfirmDialog
          open={voiding}
          title={t('inv.void')}
          message={t('inv.voidConfirm', { number: b.invoice.number })}
          confirmLabel={t('inv.void')}
          cancelLabel={t('common.close')}
          loading={voidInvoice.isPending}
          onClose={() => setVoiding(false)}
          onConfirm={() => voidInvoice.mutate(undefined)}
        />
      )}

      {quoteEdit && <QuoteEditor bookingId={b.id} quote={quoteEdit === 'new' ? null : quoteEdit} onClose={() => setQuoteEdit(null)} invalidate={invalidate} />}
      {paying && b.invoice && <RecordPaymentModal invoice={b.invoice} onClose={() => setPaying(false)} invalidate={invalidate} />}
    </div>
  );
}

function AssignPanel({ booking, canEdit }: { booking: Booking; canEdit: boolean }) {
  const { t } = useI18n();
  const techs = useTechnicians(booking.scheduledDate.slice(0, 10));
  const [choice, setChoice] = useState(booking.technician?.id ?? '');
  useEffect(() => setChoice(booking.technician?.id ?? ''), [booking.technician?.id]);

  const assign = useAction(() => api<Booking>(`/admin/bookings/${booking.id}/assign`, { body: { technicianId: choice } }), {
    success: (b) => t('bk.assigned', { name: b.technician?.fullName ?? '' }),
    invalidate: [['booking', booking.id], ['/admin/bookings'], ['overview']],
  });

  const assignable = ['PENDING', 'CONFIRMED', 'ASSIGNED', 'ON_THE_WAY'].includes(booking.status);

  return (
    <Panel title={t('bk.technician')}>
      {booking.technician ? (
        <div className="mb-4">
          <Link href={`/technicians/${booking.technician.id}`} className="font-medium hover:text-brand-600">
            {booking.technician.fullName}
          </Link>
          <a href={`tel:${booking.technician.phone}`} className="num mt-0.5 block text-sm text-navy-500">
            {booking.technician.phone}
          </a>
        </div>
      ) : (
        <p className="mb-4 text-sm text-warn-700">{t('common.unassigned')}</p>
      )}
      {canEdit && assignable && (
        <div className="space-y-2">
          <Select value={choice} onChange={(e) => setChoice(e.target.value)} aria-label={t('bk.chooseTech')}>
            <option value="">{t('bk.chooseTech')}</option>
            {techs.data?.data.map((tech) => (
              <option key={tech.id} value={tech.id} disabled={!tech.isAvailable}>
                {tech.fullName} — {t('bk.jobsThatDay', { count: tech.jobsOnDate ?? 0 })}
              </option>
            ))}
          </Select>
          <Button
            className="w-full"
            variant={booking.technician ? 'secondary' : 'primary'}
            disabled={!choice || choice === booking.technician?.id}
            loading={assign.isPending}
            onClick={() => assign.mutate(undefined)}
          >
            {booking.technician ? t('bk.reassign') : t('bk.assign')}
          </Button>
        </div>
      )}
    </Panel>
  );
}

function SchedulePanel({ booking, closed }: { booking: Booking; closed: boolean }) {
  const { t } = useI18n();
  const [form, setForm] = useState({
    scheduledDate: booking.scheduledDate.slice(0, 10),
    timeSlot: booking.timeSlot,
    priority: booking.priority,
    estimatedPrice: booking.estimatedPrice ?? '',
    internalNotes: booking.internalNotes ?? '',
  });
  const save = useAction(
    () =>
      api(`/admin/bookings/${booking.id}`, {
        method: 'PATCH',
        body: {
          ...(closed ? {} : { scheduledDate: form.scheduledDate, timeSlot: form.timeSlot }),
          priority: form.priority,
          estimatedPrice: form.estimatedPrice === '' ? undefined : Number(form.estimatedPrice),
          internalNotes: form.internalNotes,
        },
      }),
    { success: t('common.saved'), invalidate: [['booking', booking.id], ['/admin/bookings']] },
  );

  return (
    <Panel title={t('bk.reschedule')}>
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Field label={t('common.date')} htmlFor="sd">
            <Input id="sd" type="date" disabled={closed} value={form.scheduledDate} onChange={(e) => setForm({ ...form, scheduledDate: e.target.value })} />
          </Field>
          <Field label={t('bk.timeSlot')} htmlFor="ts">
            <Select id="ts" disabled={closed} value={form.timeSlot} onChange={(e) => setForm({ ...form, timeSlot: e.target.value as Booking['timeSlot'] })}>
              {SLOTS.map((s) => (
                <option key={s} value={s}>
                  {t(`slot.${s}`)}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={t('bk.priority')} htmlFor="pr">
            <Select id="pr" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as Booking['priority'] })}>
              {['NORMAL', 'URGENT', 'EMERGENCY'].map((p) => (
                <option key={p} value={p}>
                  {t(`priority.${p}`)}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={t('bk.estimate')} htmlFor="est">
            <Input id="est" type="number" min={0} step="0.01" value={form.estimatedPrice} onChange={(e) => setForm({ ...form, estimatedPrice: e.target.value })} />
          </Field>
        </div>
        <Field label={t('bk.internal')} hint={t('bk.internalHint')} htmlFor="in">
          <Textarea id="in" value={form.internalNotes} onChange={(e) => setForm({ ...form, internalNotes: e.target.value })} />
        </Field>
        <Button className="w-full" variant="secondary" onClick={() => save.mutate(undefined)} loading={save.isPending}>
          {t('common.save')}
        </Button>
      </div>
    </Panel>
  );
}

function PhotosPanel({ booking, canEdit }: { booking: Booking; canEdit: boolean }) {
  const { t } = useI18n();
  const input = useRef<HTMLInputElement>(null);
  const [kind, setKind] = useState<'BEFORE' | 'AFTER'>('BEFORE');
  const [preview, setPreview] = useState<string | null>(null);
  const invalidate = [['booking', booking.id]];
  const upload = useAction(
    async (file: File) => {
      const stored = await uploadImage(file, 'bookings');
      return api(`/admin/bookings/${booking.id}/photos`, { body: { url: stored.url, key: stored.key, kind } });
    },
    { invalidate },
  );
  const remove = useAction((photoId: string) => api(`/admin/bookings/${booking.id}/photos/${photoId}`, { method: 'DELETE' }), { invalidate });

  return (
    <Panel
      title={t('bk.photos')}
      action={
        canEdit && (
          <div className="flex items-center gap-2">
            <Select className="h-8 w-auto text-[13px]" value={kind} onChange={(e) => setKind(e.target.value as 'BEFORE' | 'AFTER')} aria-label="Photo type">
              <option value="BEFORE">Before</option>
              <option value="AFTER">After</option>
            </Select>
            <Button size="sm" variant="secondary" icon={<Camera className="size-4" />} loading={upload.isPending} onClick={() => input.current?.click()}>
              {t('common.upload')}
            </Button>
            <input
              ref={input}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) upload.mutate(f);
                e.target.value = '';
              }}
            />
          </div>
        )
      }
    >
      {booking.photos?.length ? (
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {booking.photos.map((p) => (
            <li key={p.id} className="group relative">
              <button onClick={() => setPreview(p.url)} className="block aspect-square w-full overflow-hidden rounded-lg bg-surface">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.url} alt={`${p.kind} photo`} className="size-full object-cover" loading="lazy" />
              </button>
              <Badge className="absolute start-2 top-2" tone={p.kind === 'AFTER' ? 'ok' : p.kind === 'BEFORE' ? 'brand' : 'neutral'}>
                {p.kind === 'PROBLEM' ? 'Customer' : p.kind === 'BEFORE' ? 'Before' : 'After'}
              </Badge>
              {canEdit && (
                <button
                  onClick={() => remove.mutate(p.id)}
                  className="absolute end-2 top-2 hidden rounded bg-white/90 p-1 text-bad-700 group-hover:block focus:block"
                  aria-label={t('common.delete')}
                >
                  <Trash2 className="size-4" />
                </button>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-navy-500">{t('bk.noPhotos')}</p>
      )}
      <Modal open={!!preview} onClose={() => setPreview(null)} title={t('bk.photos')} size="lg">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        {preview && <img src={preview} alt="" className="w-full rounded-lg" />}
      </Modal>
    </Panel>
  );
}

function TimelinePanel({ booking }: { booking: Booking }) {
  const { t, locale } = useI18n();
  const entries = [...(booking.history ?? [])].reverse();
  return (
    <Panel title={t('bk.timeline')}>
      <ol className="relative space-y-5 border-s border-line ps-6">
        {entries.map((h) => (
          <li key={h.id} className="relative">
            <span className="absolute -start-[1.95rem] top-1 size-3 rounded-full border-2 border-white bg-brand-500 ring-1 ring-line" aria-hidden />
            <div className="flex flex-wrap items-center gap-2 text-sm">
              <BookingStatusBadge status={h.toStatus} />
              <span className="text-[13px] text-navy-500">{dateTime(h.createdAt, locale)}</span>
              {h.changedBy && <span className="text-[13px] text-navy-500">{t('bk.history', { name: h.changedBy.fullName })}</span>}
            </div>
            {h.note && <p className="mt-1 text-sm text-navy-700">{h.note}</p>}
          </li>
        ))}
      </ol>
    </Panel>
  );
}
