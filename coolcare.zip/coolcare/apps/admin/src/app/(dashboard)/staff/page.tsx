'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Plus } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { dateTime } from '@/lib/format';
import { useAction } from '@/lib/hooks';
import type { Branch, StaffUser } from '@/lib/types';
import { Badge, Button, ErrorState, Field, Input, Modal, PageHeader, Select, Skeleton } from '@/components/ui';

const ROLES = ['ADMIN', 'DISPATCHER', 'ACCOUNTANT', 'SUPER_ADMIN'] as const;

export default function StaffPage() {
  const { t, locale } = useI18n();
  const { user } = useAuth();
  const q = useQuery({ queryKey: ['staff'], queryFn: () => api<StaffUser[]>('/admin/staff') });
  const [edit, setEdit] = useState<StaffUser | 'new' | null>(null);

  return (
    <>
      <PageHeader
        title={t('st.title')}
        subtitle={t('st.roleHelp')}
        actions={
          <Button icon={<Plus className="size-4" />} onClick={() => setEdit('new')}>
            {t('st.new')}
          </Button>
        }
      />
      <div className="overflow-x-auto rounded-panel border border-line bg-white">
        {q.isError ? (
          <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-[13px] text-navy-500">
                <th className="px-4 py-2.5 text-start font-medium">{t('common.name')}</th>
                <th className="px-4 py-2.5 text-start font-medium">{t('st.role')}</th>
                <th className="hidden px-4 py-2.5 text-start font-medium md:table-cell">{t('st.branch')}</th>
                <th className="hidden px-4 py-2.5 text-start font-medium md:table-cell">{t('cu.lastSeen')}</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody>
              {q.isLoading
                ? Array.from({ length: 3 }).map((_, i) => (
                    <tr key={i}>
                      <td colSpan={5} className="px-4 py-3">
                        <Skeleton className="w-full" />
                      </td>
                    </tr>
                  ))
                : q.data?.map((s) => (
                    <tr key={s.id} className="border-b border-line last:border-0">
                      <td className="px-4 py-3">
                        <div className="font-medium">{s.fullName}</div>
                        <div className="text-[13px] text-navy-500">{s.email}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          <Badge tone={s.role === 'SUPER_ADMIN' ? 'navy' : 'brand'}>{t(`role.${s.role}`)}</Badge>
                          {s.status === 'SUSPENDED' && <Badge tone="bad">{t('st.suspended')}</Badge>}
                        </div>
                      </td>
                      <td className="hidden px-4 py-3 md:table-cell">{s.branch?.name ?? '—'}</td>
                      <td className="hidden px-4 py-3 md:table-cell">{dateTime(s.lastLoginAt, locale)}</td>
                      <td className="px-4 py-3 text-end">
                        {(s.role !== 'SUPER_ADMIN' || user?.role === 'SUPER_ADMIN') && (
                          <Button size="sm" variant="ghost" onClick={() => setEdit(s)}>
                            {t('common.edit')}
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
            </tbody>
          </table>
        )}
      </div>
      {edit && <StaffForm staff={edit === 'new' ? null : edit} onClose={() => setEdit(null)} />}
    </>
  );
}

function StaffForm({ staff, onClose }: { staff: StaffUser | null; onClose: () => void }) {
  const { t } = useI18n();
  const { user } = useAuth();
  const branches = useQuery({ queryKey: ['branches'], queryFn: () => api<Branch[]>('/admin/branches') });
  const [f, setF] = useState({
    fullName: staff?.fullName ?? '',
    email: staff?.email ?? '',
    phone: staff?.phone ?? '',
    role: staff?.role ?? 'DISPATCHER',
    status: staff?.status ?? 'ACTIVE',
    branchId: staff?.branchId ?? '',
    password: '',
  });
  const self = staff?.id === user?.id;
  const save = useAction(
    () =>
      staff
        ? api(`/admin/staff/${staff.id}`, {
            method: 'PATCH',
            body: { fullName: f.fullName, role: self ? undefined : f.role, status: self ? undefined : f.status, branchId: f.branchId || undefined, password: f.password || undefined },
          })
        : api('/admin/staff', { body: { fullName: f.fullName, email: f.email, phone: f.phone, role: f.role, password: f.password, branchId: f.branchId || undefined } }),
    { success: t('common.saved'), invalidate: [['staff']], onSuccess: onClose },
  );
  const pwOk = /^(?=.*[A-Za-z])(?=.*\d).{8,72}$/.test(f.password);
  const valid = f.fullName.trim() && (staff ? !f.password || pwOk : f.email && f.phone && pwOk);
  const roles = ROLES.filter((r) => r !== 'SUPER_ADMIN' || user?.role === 'SUPER_ADMIN');

  return (
    <Modal
      open
      onClose={onClose}
      title={staff ? staff.fullName : t('st.new')}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => save.mutate(undefined)} loading={save.isPending} disabled={!valid}>
            {t('common.save')}
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label={t('common.name')} htmlFor="sfn">
            <Input id="sfn" value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} />
          </Field>
        </div>
        <Field label={t('common.email')} htmlFor="sfe">
          <Input id="sfe" type="email" disabled={!!staff} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        </Field>
        <Field label={t('common.phone')} htmlFor="sfp">
          <Input id="sfp" type="tel" disabled={!!staff} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        </Field>
        <Field label={t('st.role')} htmlFor="sfr">
          <Select id="sfr" disabled={self} value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as StaffUser['role'] })}>
            {roles.map((r) => (
              <option key={r} value={r}>
                {t(`role.${r}`)}
              </option>
            ))}
          </Select>
        </Field>
        <Field label={t('st.branch')} htmlFor="sfb" optional>
          <Select id="sfb" value={f.branchId} onChange={(e) => setF({ ...f, branchId: e.target.value })}>
            <option value="">—</option>
            {branches.data?.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </Select>
        </Field>
        {staff && (
          <Field label={t('common.status')} htmlFor="sfs">
            <Select id="sfs" disabled={self} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as StaffUser['status'] })}>
              <option value="ACTIVE">{t('common.active')}</option>
              <option value="SUSPENDED">{t('st.suspended')}</option>
            </Select>
          </Field>
        )}
        <Field label={staff ? t('st.newPassword') : t('st.password')} htmlFor="sfpw" hint={t('st.passwordHint')} optional={!!staff}>
          <Input id="sfpw" type="password" autoComplete="new-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
        </Field>
      </div>
    </Modal>
  );
}
