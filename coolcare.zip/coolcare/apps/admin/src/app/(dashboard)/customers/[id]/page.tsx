'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, CheckCircle2, MapPin } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { pick, useI18n } from '@/lib/i18n';
import { dateTime, day, mapsUrl, money } from '@/lib/format';
import { useAction } from '@/lib/hooks';
import type { Address, Booking, Customer, Invoice, Subscription } from '@/lib/types';
import { Badge, Button, ConfirmDialog, ErrorState, KeyValue, Panel, Spinner } from '@/components/ui';
import { BookingStatusBadge, InvoiceStatusBadge, SubscriptionStatusBadge } from '@/components/status';

interface CustomerDetail extends Customer {
  totalPaid: string | number;
  addresses: Address[];
  equipment: { id: string; type: string; brand?: string | null; model?: string | null; capacity?: string | null; location?: string | null }[];
  bookings: Booking[];
  invoices: Invoice[];
  subscriptions: Subscription[];
}

export default function CustomerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { t, locale } = useI18n();
  const { can } = useAuth();
  const [confirm, setConfirm] = useState(false);
  const q = useQuery({ queryKey: ['customer', id], queryFn: () => api<CustomerDetail>(`/admin/customers/${id}`) });
  const setStatus = useAction(
    (status: 'ACTIVE' | 'SUSPENDED') => api(`/admin/customers/${id}/status`, { method: 'PATCH', body: { status } }),
    { success: t('common.saved'), invalidate: [['customer', id], ['/admin/customers']], onSuccess: () => setConfirm(false) },
  );

  if (q.isLoading) return <Spinner label={t('common.loading')} />;
  if (q.isError || !q.data) return <ErrorState message={(q.error as Error)?.message ?? t('err.loadFailed')} onRetry={() => q.refetch()} />;
  const c = q.data;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/customers" className="inline-flex items-center gap-1 text-sm text-navy-500 hover:text-navy-900">
          <ArrowLeft className="size-4 rtl:rotate-180" />
          {t('cu.title')}
        </Link>
        <div className="mt-2 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold tracking-tight">{c.fullName}</h1>
            {c.status === 'SUSPENDED' && <Badge tone="bad">{t('st.suspended')}</Badge>}
          </div>
          {can('ADMIN') &&
            (c.status === 'ACTIVE' ? (
              <Button variant="secondary" onClick={() => setConfirm(true)}>
                {t('cu.suspend')}
              </Button>
            ) : (
              <Button variant="secondary" onClick={() => setStatus.mutate('ACTIVE')} loading={setStatus.isPending}>
                {t('cu.activate')}
              </Button>
            ))}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[22rem_1fr]">
        <div className="space-y-6">
          <Panel>
            <dl>
              <KeyValue label={t('common.phone')}>
                <a className="num hover:text-brand-600" href={`tel:${c.phone}`}>
                  {c.phone}
                </a>
                {c.phoneVerified && <CheckCircle2 className="ms-1 inline size-4 text-ok-600" aria-label={t('cu.verified')} />}
              </KeyValue>
              <KeyValue label={t('common.email')}>{c.email ?? '—'}</KeyValue>
              <KeyValue label={t('common.language')}>{c.locale === 'so' ? 'Soomaali' : 'English'}</KeyValue>
              <KeyValue label={t('cu.joined')}>{day(c.createdAt, locale)}</KeyValue>
              <KeyValue label={t('cu.lastSeen')}>{dateTime(c.lastLoginAt, locale)}</KeyValue>
              <KeyValue label={t('cu.totalPaid')}>
                <span className="num font-medium">{money(c.totalPaid, 'USD', locale)}</span>
              </KeyValue>
            </dl>
          </Panel>

          <Panel title={t('cu.addresses')}>
            {c.addresses.length ? (
              <ul className="space-y-3 text-sm">
                {c.addresses.map((a) => (
                  <li key={a.id}>
                    <div className="font-medium">
                      {a.label} {a.isDefault && <Badge tone="brand">✓</Badge>}
                    </div>
                    <div className="text-navy-700">{[a.street, a.neighborhood, a.district].filter(Boolean).join(', ')}</div>
                    {a.landmark && <div className="text-navy-500">{a.landmark}</div>}
                    <a className="mt-1 inline-flex items-center gap-1 text-brand-600" href={mapsUrl(a.latitude, a.longitude, `${a.neighborhood ?? ''} ${a.district}`)} target="_blank" rel="noreferrer">
                      <MapPin className="size-3.5" />
                      {t('bk.openMap')}
                    </a>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-navy-500">—</p>
            )}
          </Panel>

          <Panel title={t('cu.equipment')}>
            {c.equipment.length ? (
              <ul className="space-y-2 text-sm">
                {c.equipment.map((e) => (
                  <li key={e.id}>
                    <span className="font-medium">{t(`equip.${e.type}`)}</span>{' '}
                    <span className="text-navy-500">{[e.brand, e.model, e.capacity, e.location].filter(Boolean).join(' · ')}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-navy-500">—</p>
            )}
          </Panel>
        </div>

        <div className="min-w-0 space-y-6">
          <Panel
            title={t('cu.bookings')}
            bodyClassName="p-0"
            action={
              <Link href={`/bookings?customerId=${c.id}`} className="text-sm text-brand-600 hover:underline">
                {t('common.view')}
              </Link>
            }
          >
            {c.bookings.length ? (
              <ul className="divide-y divide-line">
                {c.bookings.map((b) => (
                  <li key={b.id}>
                    <Link href={`/bookings/${b.id}`} className="flex flex-wrap items-center justify-between gap-2 px-5 py-3 text-sm hover:bg-surface">
                      <span>
                        <span className="num font-medium">{b.reference}</span> <span className="text-navy-500">· {pick(b.service, 'name', locale)}</span>
                      </span>
                      <span className="flex items-center gap-3">
                        <span className="text-navy-500">{day(b.scheduledDate, locale)}</span>
                        <BookingStatusBadge status={b.status} />
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-5 py-6 text-sm text-navy-500">—</p>
            )}
          </Panel>

          <Panel title={t('nav.invoices')} bodyClassName="p-0">
            {c.invoices.length ? (
              <ul className="divide-y divide-line">
                {c.invoices.map((i) => (
                  <li key={i.id}>
                    <Link href={`/invoices/${i.id}`} className="flex items-center justify-between gap-2 px-5 py-3 text-sm hover:bg-surface">
                      <span className="num font-medium">{i.number}</span>
                      <span className="flex items-center gap-3">
                        <span className="num">{money(i.total, i.currency, locale)}</span>
                        <InvoiceStatusBadge status={i.status} />
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="px-5 py-6 text-sm text-navy-500">—</p>
            )}
          </Panel>

          {c.subscriptions.length > 0 && (
            <Panel title={t('cu.plans')}>
              <ul className="space-y-2 text-sm">
                {c.subscriptions.map((s) => (
                  <li key={s.id} className="flex items-center justify-between">
                    <span>{pick(s.plan, 'name', locale)}</span>
                    <SubscriptionStatusBadge status={s.status} />
                  </li>
                ))}
              </ul>
            </Panel>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={confirm}
        title={t('cu.suspend')}
        message={t('cu.suspendConfirm', { name: c.fullName })}
        confirmLabel={t('cu.suspend')}
        cancelLabel={t('common.cancel')}
        loading={setStatus.isPending}
        onClose={() => setConfirm(false)}
        onConfirm={() => setStatus.mutate('SUSPENDED')}
      />
    </div>
  );
}
