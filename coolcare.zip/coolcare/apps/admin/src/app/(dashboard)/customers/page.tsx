'use client';

import { useRouter } from 'next/navigation';
import { Users } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { day, dateTime } from '@/lib/format';
import type { Customer } from '@/lib/types';
import { Badge, EmptyState, PageHeader, Select } from '@/components/ui';
import { DataTable, SearchBox, useServerList, type Column } from '@/components/ui/data-table';

export default function CustomersPage() {
  const { t, locale } = useI18n();
  const router = useRouter();
  const list = useServerList<Customer>('/admin/customers');

  const columns: Column<Customer>[] = [
    {
      key: 'name',
      header: t('common.name'),
      sort: 'fullName',
      render: (c) => (
        <div className="flex items-center gap-2">
          <span className="font-medium">{c.fullName}</span>
          {c.status === 'SUSPENDED' && <Badge tone="bad">{t('st.suspended')}</Badge>}
        </div>
      ),
    },
    { key: 'phone', header: t('common.phone'), render: (c) => <span className="num">{c.phone}</span> },
    { key: 'email', header: t('common.email'), hideOnMobile: true, render: (c) => c.email ?? '—' },
    { key: 'bookings', header: t('cu.bookings'), hideOnMobile: true, className: 'text-end', render: (c) => <span className="num">{c.bookingsCount ?? 0}</span> },
    { key: 'joined', header: t('cu.joined'), sort: 'createdAt', hideOnMobile: true, render: (c) => day(c.createdAt, locale) },
    { key: 'seen', header: t('cu.lastSeen'), sort: 'lastLoginAt', hideOnMobile: true, render: (c) => dateTime(c.lastLoginAt, locale) },
  ];

  return (
    <>
      <PageHeader title={t('cu.title')} />
      <DataTable
        list={list}
        columns={columns}
        onRowClick={(c) => router.push(`/customers/${c.id}`)}
        empty={<EmptyState icon={<Users className="size-5" />} title={t('cu.empty')} />}
        toolbar={
          <>
            <SearchBox value={list.state.search} onChange={list.setSearch} placeholder={t('cu.searchPlaceholder')} />
            <Select className="w-full sm:w-44" value={list.state.filters.status ?? ''} onChange={(e) => list.setFilter('status', e.target.value)} aria-label={t('common.status')}>
              <option value="">{t('common.all')}</option>
              <option value="ACTIVE">{t('common.active')}</option>
              <option value="SUSPENDED">{t('st.suspended')}</option>
            </Select>
          </>
        }
      />
    </>
  );
}
