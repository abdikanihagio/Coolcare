'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Bell, Megaphone } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { relative } from '@/lib/format';
import { useAction } from '@/lib/hooks';
import { Button, cx, EmptyState, ErrorState, Field, Input, Modal, PageHeader, Skeleton, Textarea } from '@/components/ui';

interface Note {
  id: string;
  type: string;
  title: string;
  body: string;
  data?: { bookingId?: string; invoiceId?: string; subscriptionId?: string } | null;
  readAt: string | null;
  createdAt: string;
}

export default function NotificationsPage() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [page, setPage] = useState(1);
  const [broadcast, setBroadcast] = useState(false);
  const q = useQuery({ queryKey: ['notifications', page], queryFn: () => api<{ data: Note[]; meta: { totalPages: number }; unread: number }>('/notifications', { query: { page, pageSize: 30 } }) });
  const invalidate = [['notifications']];
  const markAll = useAction(() => api('/notifications/read-all', { method: 'PATCH' }), { invalidate });
  const markOne = useAction((id: string) => api(`/notifications/${id}/read`, { method: 'PATCH' }), { invalidate });

  const href = (n: Note) =>
    n.data?.bookingId ? `/bookings/${n.data.bookingId}` : n.data?.invoiceId ? `/invoices/${n.data.invoiceId}` : n.data?.subscriptionId ? '/maintenance' : undefined;

  return (
    <>
      <PageHeader
        title={t('no.title')}
        actions={
          <>
            {!!q.data?.unread && (
              <Button variant="secondary" onClick={() => markAll.mutate(undefined)} loading={markAll.isPending}>
                {t('no.markAll')}
              </Button>
            )}
            {can('ADMIN') && (
              <Button icon={<Megaphone className="size-4" />} onClick={() => setBroadcast(true)}>
                {t('no.broadcast')}
              </Button>
            )}
          </>
        }
      />
      <div className="rounded-panel border border-line bg-white">
        {q.isError ? (
          <ErrorState message={(q.error as Error).message} onRetry={() => q.refetch()} />
        ) : q.isLoading ? (
          <div className="space-y-3 p-5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : q.data?.data.length ? (
          <ul className="divide-y divide-line">
            {q.data.data.map((n) => {
              const link = href(n);
              const content = (
                <div className={cx('flex gap-3 px-5 py-4', !n.readAt && 'bg-brand-50/50')}>
                  <span className={cx('mt-1.5 size-2 shrink-0 rounded-full', n.readAt ? 'bg-transparent' : 'bg-brand-500')} aria-hidden />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <p className={cx('text-sm', !n.readAt && 'font-semibold')}>{n.title}</p>
                      <span className="text-xs text-navy-500">{relative(n.createdAt)}</span>
                    </div>
                    <p className="mt-0.5 text-sm text-navy-700">{n.body}</p>
                  </div>
                </div>
              );
              return (
                <li key={n.id} onClick={() => !n.readAt && markOne.mutate(n.id)}>
                  {link ? <Link href={link}>{content}</Link> : content}
                </li>
              );
            })}
          </ul>
        ) : (
          <EmptyState icon={<Bell className="size-5" />} title={t('no.empty')} />
        )}
        {q.data && q.data.meta.totalPages > 1 && (
          <div className="flex justify-end gap-2 border-t border-line px-4 py-2.5">
            <Button size="sm" variant="secondary" disabled={page <= 1} onClick={() => setPage(page - 1)}>
              {t('common.prev')}
            </Button>
            <Button size="sm" variant="secondary" disabled={page >= q.data.meta.totalPages} onClick={() => setPage(page + 1)}>
              {t('common.next')}
            </Button>
          </div>
        )}
      </div>
      {broadcast && <BroadcastModal onClose={() => setBroadcast(false)} />}
    </>
  );
}

function BroadcastModal({ onClose }: { onClose: () => void }) {
  const { t } = useI18n();
  const [f, setF] = useState({ titleEn: '', bodyEn: '', titleSo: '', bodySo: '' });
  const send = useAction(() => api<{ recipients: number }>('/notifications/broadcast', { body: { ...f, titleSo: f.titleSo || undefined, bodySo: f.bodySo || undefined } }), {
    success: (r) => t('no.sentTo', { count: r.recipients }),
    onSuccess: onClose,
  });
  return (
    <Modal
      open
      onClose={onClose}
      title={t('no.broadcast')}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => send.mutate(undefined)} loading={send.isPending} disabled={!f.titleEn.trim() || !f.bodyEn.trim()}>
            {t('no.sendBroadcast')}
          </Button>
        </>
      }
    >
      <p className="mb-4 text-sm text-navy-500">{t('no.broadcastHint')}</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={t('no.titleEn')} htmlFor="bte">
          <Input id="bte" maxLength={120} value={f.titleEn} onChange={(e) => setF({ ...f, titleEn: e.target.value })} />
        </Field>
        <Field label={t('no.titleSo')} htmlFor="bts" optional>
          <Input id="bts" maxLength={120} value={f.titleSo} onChange={(e) => setF({ ...f, titleSo: e.target.value })} />
        </Field>
        <Field label={t('no.bodyEn')} htmlFor="bbe">
          <Textarea id="bbe" maxLength={500} value={f.bodyEn} onChange={(e) => setF({ ...f, bodyEn: e.target.value })} />
        </Field>
        <Field label={t('no.bodySo')} htmlFor="bbs" optional>
          <Textarea id="bbs" maxLength={500} value={f.bodySo} onChange={(e) => setF({ ...f, bodySo: e.target.value })} />
        </Field>
      </div>
    </Modal>
  );
}
