'use client';

import Link from 'next/link';
import { Suspense, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { CreditCard } from 'lucide-react';
import { api } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { dateTime, money, PAYMENT_METHODS } from '@/lib/format';
import { useAction } from '@/lib/hooks';
import type { Payment } from '@/lib/types';
import { Button, ConfirmDialog, EmptyState, Input, PageHeader, Select, Spinner } from '@/components/ui';
import { DataTable, SearchBox, useServerList, type Column } from '@/components/ui/data-table';
import { PaymentStatusBadge } from '@/components/status';

export default function PaymentsPage() {
  return (
    <Suspense fallback={<Spinner />}>
      <PaymentsList />
    </Suspense>
  );
}

function PaymentsList() {
  const { t, locale } = useI18n();
  const params = useSearchParams();
  const list = useServerList<Payment>('/admin/payments', { sortBy: 'paidAt', filters: { status: params.get('status') ?? undefined } });
  const [refunding, setRefunding] = useState<Payment | null>(null);
  const invalidate = [['/admin/payments'], ['/admin/invoices'], ['overview']];
  const confirm = useAction((id: string) => api(`/admin/payments/${id}/confirm`, { method: 'POST' }), { success: t('pay.recorded'), invalidate });
  const reject = useAction((id: string) => api(`/admin/payments/${id}/reject`, { method: 'POST' }), { success: t('common.saved'), invalidate });
  const refund = useAction((id: string) => api(`/admin/payments/${id}/refund`, { method: 'POST' }), {
    success: t('common.saved'),
    invalidate,
    onSuccess: () => setRefunding(null),
  });

  const columns: Column<Payment>[] = [
    { key: 'date', header: t('common.date'), sort: 'paidAt', render: (p) => dateTime(p.paidAt, locale) },
    {
      key: 'inv',
      header: t('inv.number'),
      render: (p) => (
        <Link href={`/invoices/${p.invoiceId}`} className="num font-medium hover:text-brand-600" onClick={(e) => e.stopPropagation()}>
          {p.invoice?.number}
        </Link>
      ),
    },
    { key: 'cust', header: t('bk.customer'), hideOnMobile: true, render: (p) => p.invoice?.customer.fullName },
    {
      key: 'method',
      header: t('pay.method'),
      render: (p) => (
        <div>
          {t(`method.${p.method}`)}
          {p.reference && <div className="num text-[13px] text-navy-500">{p.reference}</div>}
        </div>
      ),
    },
    { key: 'status', header: t('common.status'), render: (p) => <PaymentStatusBadge status={p.status} /> },
    { key: 'amt', header: t('common.amount'), sort: 'amount', className: 'text-end', render: (p) => <span className="num font-medium">{money(p.amount, p.currency, locale)}</span> },
    {
      key: 'act',
      header: '',
      className: 'text-end',
      render: (p) =>
        p.status === 'PENDING' ? (
          <div className="flex justify-end gap-1">
            <Button size="sm" onClick={() => confirm.mutate(p.id)} loading={confirm.isPending && confirm.variables === p.id}>
              {t('pay.confirm')}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => reject.mutate(p.id)}>
              {t('pay.reject')}
            </Button>
          </div>
        ) : p.status === 'COMPLETED' ? (
          <Button size="sm" variant="ghost" onClick={() => setRefunding(p)}>
            {t('pay.refund')}
          </Button>
        ) : null,
    },
  ];

  const total = (list.query.data as { totalCollected?: string } | undefined)?.totalCollected;

  return (
    <>
      <PageHeader
        title={t('pay.title')}
        subtitle={total !== undefined && `${t('pay.collected')}: ${money(total, 'USD', locale)}`}
      />
      {list.state.filters.status === 'PENDING' && <p className="mb-4 rounded-lg bg-warn-50 px-4 py-3 text-sm text-warn-700">{t('pay.verifyHint')}</p>}
      <DataTable
        list={list}
        columns={columns}
        empty={<EmptyState icon={<CreditCard className="size-5" />} title={t('pay.empty')} />}
        toolbar={
          <>
            <SearchBox value={list.state.search} onChange={list.setSearch} placeholder={t('common.search')} />
            <Select className="w-full sm:w-40" value={list.state.filters.status ?? ''} onChange={(e) => list.setFilter('status', e.target.value)} aria-label={t('common.status')}>
              <option value="">{t('common.all')}</option>
              {(['PENDING', 'COMPLETED', 'FAILED', 'REFUNDED'] as const).map((s) => (
                <option key={s} value={s}>
                  {t(`payment.${s}`)}
                </option>
              ))}
            </Select>
            <Select className="w-full sm:w-40" value={list.state.filters.method ?? ''} onChange={(e) => list.setFilter('method', e.target.value)} aria-label={t('pay.method')}>
              <option value="">{t('common.all')}</option>
              {PAYMENT_METHODS.map((m) => (
                <option key={m} value={m}>
                  {t(`method.${m}`)}
                </option>
              ))}
            </Select>
            <Input type="date" className="w-full sm:w-40" value={list.state.filters.from ?? ''} onChange={(e) => list.setFilter('from', e.target.value)} aria-label={t('common.from')} />
            <Input type="date" className="w-full sm:w-40" value={list.state.filters.to ?? ''} onChange={(e) => list.setFilter('to', e.target.value)} aria-label={t('common.to')} />
          </>
        }
      />
      <ConfirmDialog
        open={!!refunding}
        title={t('pay.refund')}
        message={t('pay.refundConfirm', { amount: refunding ? money(refunding.amount, refunding.currency, locale) : '' })}
        confirmLabel={t('pay.refund')}
        cancelLabel={t('common.cancel')}
        loading={refund.isPending}
        onClose={() => setRefunding(null)}
        onConfirm={() => refunding && refund.mutate(refunding.id)}
      />
    </>
  );
}
