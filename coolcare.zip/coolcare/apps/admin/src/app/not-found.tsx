import Link from 'next/link';
import { LogoMark } from '@/components/layout/logo';

export default function NotFound() {
  return (
    <div className="grid min-h-dvh place-items-center px-6 text-center">
      <div>
        <LogoMark className="mx-auto size-12" />
        <h1 className="mt-6 text-2xl font-semibold">This page does not exist.</h1>
        <Link href="/" className="mt-4 inline-block text-brand-600 hover:underline">
          Go to dashboard
        </Link>
      </div>
    </div>
  );
}
