'use client';

import { useState } from 'react';
import { api } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { money, PAYMENT_METHODS } from '@/lib/format';
import { useAction } from '@/lib/hooks';
import type { Invoice } from '@/lib/types';
import { Button, Field, Input, Modal, Select, Textarea } from './ui';

export function RecordPaymentModal({ invoice, onClose, invalidate }: { invoice: Invoice; onClose: () => void; invalidate: unknown[][] }) {
  const { t, locale } = useI18n();
  const balance = Number(invoice.total) - Number(invoice.amountPaid);
  const [form, setForm] = useState({ amount: balance.toFixed(2), method: 'EVC_PLUS', reference: '', payerPhone: '', notes: '' });

  const record = useAction(
    () =>
      api(`/admin/invoices/${invoice.id}/payments`, {
        body: {
          amount: Number(form.amount),
          method: form.method,
          reference: form.reference || undefined,
          payerPhone: form.payerPhone || undefined,
          notes: form.notes || undefined,
        },
      }),
    { success: t('pay.recorded'), invalidate: [...invalidate, ['/admin/invoices'], ['/admin/payments']], onSuccess: onClose },
  );

  const amount = Number(form.amount);
  const tooMuch = amount - balance > 0.005;
  const mobile = !['CASH', 'CARD'].includes(form.method);

  return (
    <Modal
      open
      onClose={onClose}
      title={`${t('inv.recordPayment')} · ${invoice.number}`}
      size="sm"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => record.mutate(undefined)} loading={record.isPending} disabled={!(amount > 0) || tooMuch || (mobile && !form.reference)}>
            {t('inv.recordPayment')}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <p className="text-sm text-navy-500">
          {t('inv.balance')}: <span className="num font-medium text-navy-900">{money(balance, invoice.currency, locale)}</span>
        </p>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t('common.amount')} htmlFor="amt" error={tooMuch ? `${t('inv.balance')}: ${money(balance, invoice.currency, locale)}` : undefined}>
            <Input id="amt" type="number" min={0.01} step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
          </Field>
          <Field label={t('pay.method')} htmlFor="mth">
            <Select id="mth" value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })}>
              {PAYMENT_METHODS.map((m) => (
                <option key={m} value={m}>
                  {t(`method.${m}`)}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label={t('pay.reference')} htmlFor="ref" optional={!mobile}>
          <Input id="ref" value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} />
        </Field>
        {mobile && (
          <Field label={t('pay.payerPhone')} htmlFor="pp" optional>
            <Input id="pp" value={form.payerPhone} onChange={(e) => setForm({ ...form, payerPhone: e.target.value })} />
          </Field>
        )}
        <Field label={t('common.notes')} htmlFor="pn" optional>
          <Textarea id="pn" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        </Field>
      </div>
    </Modal>
  );
}
