'use client';

import { useState } from 'react';
import { api } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { EQUIPMENT_TYPES } from '@/lib/format';
import { useAction } from '@/lib/hooks';
import type { Technician } from '@/lib/types';
import { Button, Checkbox, Field, Input, Modal, Select, Textarea } from './ui';

export function TechnicianForm({ tech, onClose }: { tech: Technician | null; onClose: () => void }) {
  const { t } = useI18n();
  const [form, setForm] = useState({
    fullName: tech?.fullName ?? '',
    phone: tech?.phone ?? '',
    email: tech?.email ?? '',
    specialties: tech?.specialties ?? [],
    status: tech?.status ?? 'ACTIVE',
    isAvailable: tech?.isAvailable ?? true,
    notes: tech?.notes ?? '',
  });

  const save = useAction(
    () => {
      const body = { ...form, email: form.email || undefined, notes: form.notes || undefined };
      return tech ? api(`/admin/technicians/${tech.id}`, { method: 'PATCH', body }) : api('/admin/technicians', { body });
    },
    { success: t('common.saved'), invalidate: [['/admin/technicians'], ['technicians-pick'], ['technician', tech?.id]], onSuccess: onClose },
  );

  const toggle = (s: string) =>
    setForm((f) => ({ ...f, specialties: f.specialties.includes(s) ? f.specialties.filter((x) => x !== s) : [...f.specialties, s] }));

  return (
    <Modal
      open
      onClose={onClose}
      title={tech ? tech.fullName : t('te.new')}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => save.mutate(undefined)} loading={save.isPending} disabled={!form.fullName.trim() || !form.phone.trim()}>
            {tech ? t('common.save') : t('te.new')}
          </Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Field label={t('common.name')} htmlFor="tn">
            <Input id="tn" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </Field>
        </div>
        <Field label={t('common.phone')} htmlFor="tp">
          <Input id="tp" type="tel" placeholder="+252 61 …" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        </Field>
        <Field label={t('common.email')} htmlFor="te" optional>
          <Input id="te" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        </Field>
        <Field label={t('common.status')} htmlFor="ts">
          <Select id="ts" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as Technician['status'] })}>
            {(['ACTIVE', 'ON_LEAVE', 'INACTIVE'] as const).map((s) => (
              <option key={s} value={s}>
                {t(`tech.${s}`)}
              </option>
            ))}
          </Select>
        </Field>
        <div className="flex items-end pb-2">
          <Checkbox label={t('te.available')} checked={form.isAvailable} onChange={(v) => setForm({ ...form, isAvailable: v })} />
        </div>
        <fieldset className="sm:col-span-2">
          <legend className="mb-2 text-[13px] font-medium text-navy-800">{t('te.specialties')}</legend>
          <div className="flex flex-wrap gap-2">
            {EQUIPMENT_TYPES.map((s) => (
              <button
                key={s}
                type="button"
                aria-pressed={form.specialties.includes(s)}
                onClick={() => toggle(s)}
                className={`rounded-full border px-3 py-1 text-[13px] ${form.specialties.includes(s) ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-line text-navy-700 hover:bg-surface'}`}
              >
                {t(`equip.${s}`)}
              </button>
            ))}
          </div>
        </fieldset>
        <div className="sm:col-span-2">
          <Field label={t('common.notes')} htmlFor="tno" optional>
            <Textarea id="tno" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </Field>
        </div>
      </div>
    </Modal>
  );
}
