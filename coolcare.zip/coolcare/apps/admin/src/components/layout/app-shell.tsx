'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState, type ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Bell,
  CalendarClock,
  ClipboardList,
  CreditCard,
  FileText,
  Gauge,
  History,
  LogOut,
  Menu,
  Receipt,
  Settings,
  ShieldCheck,
  Users,
  Wrench,
  X,
  Snowflake,
} from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { LOCALE_NAMES, useI18n, type Locale } from '@/lib/i18n';
import { initials } from '@/lib/format';
import { cx, Select } from '@/components/ui';
import { Logo } from './logo';

type Role = 'ADMIN' | 'DISPATCHER' | 'ACCOUNTANT';
interface NavItem {
  href: string;
  key: string;
  icon: typeof Gauge;
  roles: Role[];
  badge?: 'pending' | 'payments';
}

const GROUPS: { key: string; items: NavItem[] }[] = [
  {
    key: 'nav.groupOperations',
    items: [
      { href: '/', key: 'nav.dashboard', icon: Gauge, roles: ['ADMIN', 'DISPATCHER', 'ACCOUNTANT'] },
      { href: '/bookings', key: 'nav.bookings', icon: ClipboardList, roles: ['ADMIN', 'DISPATCHER', 'ACCOUNTANT'], badge: 'pending' },
      { href: '/customers', key: 'nav.customers', icon: Users, roles: ['ADMIN', 'DISPATCHER', 'ACCOUNTANT'] },
      { href: '/technicians', key: 'nav.technicians', icon: Wrench, roles: ['ADMIN', 'DISPATCHER'] },
      { href: '/maintenance', key: 'nav.maintenance', icon: CalendarClock, roles: ['ADMIN', 'DISPATCHER'] },
    ],
  },
  {
    key: 'nav.groupFinance',
    items: [
      { href: '/quotes', key: 'nav.quotes', icon: FileText, roles: ['ADMIN', 'DISPATCHER', 'ACCOUNTANT'] },
      { href: '/invoices', key: 'nav.invoices', icon: Receipt, roles: ['ADMIN', 'DISPATCHER', 'ACCOUNTANT'] },
      { href: '/payments', key: 'nav.payments', icon: CreditCard, roles: ['ADMIN', 'ACCOUNTANT'], badge: 'payments' },
    ],
  },
  {
    key: 'nav.groupAdmin',
    items: [
      { href: '/services', key: 'nav.services', icon: Snowflake, roles: ['ADMIN'] },
      { href: '/staff', key: 'nav.staff', icon: ShieldCheck, roles: ['ADMIN'] },
      { href: '/settings', key: 'nav.settings', icon: Settings, roles: ['ADMIN'] },
      { href: '/audit', key: 'nav.audit', icon: History, roles: ['ADMIN'] },
    ],
  },
];

function useCounts() {
  return useQuery({
    queryKey: ['shell-counts'],
    queryFn: async () => {
      const [notifications, pending, payments] = await Promise.all([
        api<{ unread: number }>('/notifications', { query: { pageSize: 1 } }),
        api<{ meta: { total: number } }>('/admin/bookings', { query: { status: 'PENDING', pageSize: 1 } }).catch(() => ({ meta: { total: 0 } })),
        api<{ meta: { total: number } }>('/admin/payments', { query: { status: 'PENDING', pageSize: 1 } }).catch(() => ({ meta: { total: 0 } })),
      ]);
      return { unread: notifications.unread, pending: pending.meta.total, payments: payments.meta.total };
    },
    refetchInterval: 30_000,
  });
}

export function AppShell({ children }: { children: ReactNode }) {
  const { user, can, signOut } = useAuth();
  const { t, locale, setLocale } = useI18n();
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const counts = useCounts();

  useEffect(() => setOpen(false), [pathname]);

  const isActive = (href: string) => (href === '/' ? pathname === '/' : pathname.startsWith(href));

  const nav = (
    <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-4" aria-label="Main">
      {GROUPS.map((group) => {
        const items = group.items.filter((i) => can(...i.roles));
        if (!items.length) return null;
        return (
          <div key={group.key}>
            <p className="mb-1.5 px-3 text-xs font-medium text-navy-300">{t(group.key)}</p>
            <ul className="space-y-0.5">
              {items.map((item) => {
                const count = item.badge === 'pending' ? counts.data?.pending : item.badge === 'payments' ? counts.data?.payments : 0;
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      aria-current={isActive(item.href) ? 'page' : undefined}
                      className={cx(
                        'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                        isActive(item.href) ? 'bg-white/10 font-medium text-white' : 'text-navy-300 hover:bg-white/5 hover:text-white',
                      )}
                    >
                      <item.icon className="size-[18px] shrink-0" />
                      <span className="flex-1">{t(item.key)}</span>
                      {!!count && <span className="num rounded-full bg-warn-600 px-1.5 text-xs font-semibold text-white">{count}</span>}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[16rem_1fr]">
      {/* Sidebar (desktop) */}
      <aside className="no-print sticky top-0 hidden h-dvh flex-col bg-navy-900 lg:flex">
        <div className="px-6 py-5">
          <Logo inverted />
        </div>
        {nav}
      </aside>

      {/* Drawer (mobile/tablet) */}
      {open && (
        <div className="no-print fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-navy-900/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 start-0 flex w-72 flex-col bg-navy-900">
            <div className="flex items-center justify-between px-5 py-5">
              <Logo inverted />
              <button onClick={() => setOpen(false)} aria-label="Close menu" className="text-navy-300">
                <X className="size-5" />
              </button>
            </div>
            {nav}
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-col">
        <header className="no-print sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-white/90 px-4 backdrop-blur sm:px-6">
          <button className="lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu className="size-5 text-navy-700" />
          </button>
          <div className="lg:hidden">
            <Logo />
          </div>
          <div className="flex-1" />
          <Select
            value={locale}
            onChange={(e) => setLocale(e.target.value as Locale)}
            className="h-8 w-auto text-[13px]"
            aria-label={t('common.language')}
          >
            {(Object.keys(LOCALE_NAMES) as Locale[]).map((l) => (
              <option key={l} value={l}>
                {LOCALE_NAMES[l]}
              </option>
            ))}
          </Select>
          <Link href="/notifications" className="relative rounded-lg p-2 text-navy-700 hover:bg-surface" aria-label={t('nav.notifications')}>
            <Bell className="size-5" />
            {!!counts.data?.unread && (
              <span className="num absolute -end-0.5 -top-0.5 grid min-w-4 place-items-center rounded-full bg-bad-600 px-1 text-[10px] font-semibold text-white">
                {counts.data.unread > 99 ? '99+' : counts.data.unread}
              </span>
            )}
          </Link>
          <div className="flex items-center gap-2 border-s border-line ps-3">
            <div className="grid size-8 place-items-center rounded-full bg-brand-50 text-xs font-semibold text-brand-700" aria-hidden>
              {initials(user?.fullName ?? '')}
            </div>
            <div className="hidden leading-tight sm:block">
              <div className="text-[13px] font-medium">{user?.fullName}</div>
              <div className="text-xs text-navy-500">{user && t(`role.${user.role}`)}</div>
            </div>
            <button
              onClick={async () => {
                await signOut();
                router.replace('/login');
              }}
              className="ms-1 rounded-lg p-2 text-navy-500 hover:bg-surface hover:text-navy-900"
              aria-label={t('common.signOut')}
              title={t('common.signOut')}
            >
              <LogOut className="size-4" />
            </button>
          </div>
        </header>
        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 lg:py-8">{children}</main>
      </div>
    </div>
  );
}
