/** CoolCare snowflake mark. */
export function LogoMark({ className = 'size-8' }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      <rect width="64" height="64" rx="16" fill="#1677C8" />
      <g stroke="#fff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none">
        <path d="M32 12v40M14.7 22l34.6 20M14.7 42l34.6-20" />
        <path d="M26 15l6 5 6-5M26 49l6-5 6 5M13 29l7-1-3-7M51 35l-7 1 3 7M13 35l7 1-3 7M51 29l-7-1 3-7" />
      </g>
    </svg>
  );
}

export function Logo({ inverted = false, tagline = false }: { inverted?: boolean; tagline?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <LogoMark className="size-8 shrink-0" />
      <div className="leading-tight">
        <div className={`text-[17px] font-bold tracking-tight ${inverted ? 'text-white' : 'text-navy-900'}`}>CoolCare</div>
        {tagline && <div className={`text-xs ${inverted ? 'text-navy-300' : 'text-navy-500'}`}>Comfort You Can Count On</div>}
      </div>
    </div>
  );
}
