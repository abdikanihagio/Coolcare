'use client';

import { useI18n } from '@/lib/i18n';
import { BOOKING_TONE, INVOICE_TONE, PAYMENT_TONE, PRIORITY_TONE, QUOTE_TONE, SUB_TONE } from '@/lib/format';
import { Badge } from './ui';

export function BookingStatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  return <Badge tone={BOOKING_TONE[status] ?? 'neutral'}>{t(`status.${status}`)}</Badge>;
}

export function QuoteStatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  return <Badge tone={QUOTE_TONE[status] ?? 'neutral'}>{t(`quote.${status}`)}</Badge>;
}

export function InvoiceStatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  return <Badge tone={INVOICE_TONE[status] ?? 'neutral'}>{t(`invoice.${status}`)}</Badge>;
}

export function PaymentStatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  return <Badge tone={PAYMENT_TONE[status] ?? 'neutral'}>{t(`payment.${status}`)}</Badge>;
}

export function SubscriptionStatusBadge({ status }: { status: string }) {
  const { t } = useI18n();
  return <Badge tone={SUB_TONE[status] ?? 'neutral'}>{t(`sub.${status}`)}</Badge>;
}

export function PriorityBadge({ priority }: { priority: string }) {
  const { t } = useI18n();
  if (priority === 'NORMAL') return null;
  return <Badge tone={PRIORITY_TONE[priority] ?? 'neutral'}>{t(`priority.${priority}`)}</Badge>;
}
