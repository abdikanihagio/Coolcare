'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { useQuery, keepPreviousData } from '@tanstack/react-query';
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Search } from 'lucide-react';
import { api, type Paginated } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { Button, cx, EmptyState, ErrorState, Input, Skeleton } from './index';

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  /** Server-side sort field name, if sortable */
  sort?: string;
  className?: string;
  /** Hide on small screens */
  hideOnMobile?: boolean;
}

export interface ListState {
  page: number;
  pageSize: number;
  search: string;
  sortBy?: string;
  sortOrder: 'asc' | 'desc';
  filters: Record<string, string | undefined>;
}

/** Server-paginated list state with a debounced search box. */
export function useServerList<T>(path: string, initial: Partial<ListState> = {}) {
  const [state, setState] = useState<ListState>({ page: 1, pageSize: 20, search: '', sortOrder: 'desc', filters: {}, ...initial });
  const [debounced, setDebounced] = useState(state.search);

  useEffect(() => {
    const id = setTimeout(() => setDebounced(state.search), 300);
    return () => clearTimeout(id);
  }, [state.search]);

  const query = useQuery({
    queryKey: [path, state.page, state.pageSize, debounced, state.sortBy, state.sortOrder, state.filters],
    queryFn: () =>
      api<Paginated<T> & Record<string, unknown>>(path, {
        query: {
          page: state.page,
          pageSize: state.pageSize,
          search: debounced || undefined,
          sortBy: state.sortBy,
          sortOrder: state.sortOrder,
          ...state.filters,
        },
      }),
    placeholderData: keepPreviousData,
  });

  return {
    state,
    query,
    setSearch: (search: string) => setState((s) => ({ ...s, search, page: 1 })),
    setPage: (page: number) => setState((s) => ({ ...s, page })),
    setFilter: (key: string, value: string | undefined) => setState((s) => ({ ...s, page: 1, filters: { ...s.filters, [key]: value || undefined } })),
    clearFilters: () => setState((s) => ({ ...s, page: 1, search: '', filters: {} })),
    toggleSort: (field: string) =>
      setState((s) => ({ ...s, sortBy: field, sortOrder: s.sortBy === field && s.sortOrder === 'desc' ? 'asc' : 'desc' })),
  };
}

export function SearchBox({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <div className="relative w-full sm:w-80">
      <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-navy-300" />
      <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="ps-9" aria-label={placeholder} type="search" />
    </div>
  );
}

export function DataTable<T extends { id: string }>({
  list,
  columns,
  onRowClick,
  empty,
  toolbar,
}: {
  list: ReturnType<typeof useServerList<T>>;
  columns: Column<T>[];
  onRowClick?: (row: T) => void;
  empty: ReactNode;
  toolbar?: ReactNode;
}) {
  const { t } = useI18n();
  const { query, state } = list;
  const rows = query.data?.data ?? [];
  const meta = query.data?.meta;
  const filtered = !!state.search || Object.values(state.filters).some(Boolean);

  return (
    <div className="rounded-panel border border-line bg-white">
      {toolbar && <div className="flex flex-wrap items-center gap-3 border-b border-line p-3">{toolbar}</div>}

      {query.isError ? (
        <ErrorState message={(query.error as Error).message} onRetry={() => query.refetch()} retryLabel={t('common.retry')} />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-start text-[13px] text-navy-500">
                {columns.map((c) => (
                  <th key={c.key} scope="col" className={cx('px-4 py-2.5 text-start font-medium', c.hideOnMobile && 'hidden md:table-cell', c.className)}>
                    {c.sort ? (
                      <button className="inline-flex items-center gap-1 hover:text-navy-900" onClick={() => list.toggleSort(c.sort!)}>
                        {c.header}
                        {state.sortBy === c.sort && (state.sortOrder === 'asc' ? <ArrowUp className="size-3" /> : <ArrowDown className="size-3" />)}
                      </button>
                    ) : (
                      c.header
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className={cx(query.isFetching && !query.isLoading && 'opacity-60 transition-opacity')}>
              {query.isLoading
                ? Array.from({ length: 6 }).map((_, i) => (
                    <tr key={i} className="border-b border-line last:border-0">
                      {columns.map((c) => (
                        <td key={c.key} className={cx('px-4 py-3.5', c.hideOnMobile && 'hidden md:table-cell')}>
                          <Skeleton className="w-3/4" />
                        </td>
                      ))}
                    </tr>
                  ))
                : rows.map((row) => (
                    <tr
                      key={row.id}
                      onClick={onRowClick ? () => onRowClick(row) : undefined}
                      onKeyDown={onRowClick ? (e) => e.key === 'Enter' && onRowClick(row) : undefined}
                      tabIndex={onRowClick ? 0 : undefined}
                      className={cx('border-b border-line last:border-0', onRowClick && 'cursor-pointer hover:bg-brand-50/50 focus:bg-brand-50/50 focus:outline-none')}
                    >
                      {columns.map((c) => (
                        <td key={c.key} className={cx('px-4 py-3 align-middle', c.hideOnMobile && 'hidden md:table-cell', c.className)}>
                          {c.render(row)}
                        </td>
                      ))}
                    </tr>
                  ))}
            </tbody>
          </table>
          {!query.isLoading && rows.length === 0 &&
            (filtered ? (
              <EmptyState
                title={t('common.noResults')}
                action={
                  <Button variant="secondary" size="sm" onClick={list.clearFilters}>
                    {t('common.clearFilters')}
                  </Button>
                }
              />
            ) : (
              empty
            ))}
        </div>
      )}

      {meta && meta.total > 0 && (
        <div className="flex items-center justify-between gap-3 border-t border-line px-4 py-2.5 text-[13px] text-navy-500">
          <span className="num">{t('common.results', { count: meta.total })}</span>
          <div className="flex items-center gap-2">
            <span className="num hidden sm:inline">{t('common.page', { page: meta.page, pages: meta.totalPages })}</span>
            <Button variant="secondary" size="sm" disabled={meta.page <= 1} onClick={() => list.setPage(meta.page - 1)} aria-label={t('common.prev')}>
              <ChevronLeft className="size-4 rtl:rotate-180" />
            </Button>
            <Button variant="secondary" size="sm" disabled={meta.page >= meta.totalPages} onClick={() => list.setPage(meta.page + 1)} aria-label={t('common.next')}>
              <ChevronRight className="size-4 rtl:rotate-180" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
