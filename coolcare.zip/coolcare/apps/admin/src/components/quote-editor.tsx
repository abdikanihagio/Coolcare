'use client';

import { useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { api } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { money } from '@/lib/format';
import { useAction, useSettings } from '@/lib/hooks';
import type { Quote, QuoteItem } from '@/lib/types';
import { Button, Field, Input, Modal, Select, Textarea } from './ui';

type Line = { kind: QuoteItem['kind']; description: string; quantity: string; unitPrice: string };

const toCents = (v: string | number) => Math.round(Number(v || 0) * 100);

/** Mirrors the API's integer-cent arithmetic so the preview matches the saved quote. */
export function previewTotals(lines: Line[], discount: string, taxRate: string) {
  const sub = lines.reduce((s, l) => s + Math.round(toCents(l.unitPrice) * Number(l.quantity || 0)), 0);
  const disc = Math.min(toCents(discount), sub);
  const tax = Math.round(((sub - disc) * Number(taxRate || 0)) / 100);
  return { subtotal: sub / 100, discount: disc / 100, tax: tax / 100, total: (sub - disc + tax) / 100 };
}

export function QuoteEditor({
  bookingId,
  quote,
  onClose,
  invalidate,
}: {
  bookingId: string;
  quote: Quote | null;
  onClose: () => void;
  invalidate: unknown[][];
}) {
  const { t, locale } = useI18n();
  const settings = useSettings();
  const [lines, setLines] = useState<Line[]>(
    quote?.items.map((i) => ({ kind: i.kind, description: i.description, quantity: String(Number(i.quantity)), unitPrice: String(Number(i.unitPrice)) })) ?? [
      { kind: 'LABOR', description: '', quantity: '1', unitPrice: '' },
    ],
  );
  const [discount, setDiscount] = useState(quote ? String(Number(quote.discount)) : '0');
  const [taxRate, setTaxRate] = useState(quote ? String(Number(quote.taxRate)) : String(settings.data?.taxRate ?? 0));
  const [notes, setNotes] = useState(quote?.notes ?? '');
  const currency = settings.data?.currency ?? 'USD';
  const totals = previewTotals(lines, discount, taxRate);

  const save = useAction(
    (send: boolean) => {
      const body = {
        items: lines.map((l) => ({ kind: l.kind, description: l.description.trim(), quantity: Number(l.quantity), unitPrice: Number(l.unitPrice) })),
        discount: Number(discount || 0),
        taxRate: Number(taxRate || 0),
        notes: notes || undefined,
        send,
      };
      return quote ? api(`/admin/quotes/${quote.id}`, { method: 'PATCH', body }) : api(`/admin/bookings/${bookingId}/quotes`, { body });
    },
    { success: t('common.saved'), invalidate, onSuccess: onClose },
  );

  const update = (i: number, patch: Partial<Line>) => setLines((ls) => ls.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  const valid = lines.length > 0 && lines.every((l) => l.description.trim() && Number(l.quantity) > 0 && l.unitPrice !== '' && Number(l.unitPrice) >= 0);

  return (
    <Modal
      open
      onClose={onClose}
      title={quote ? `${t('common.edit')} ${quote.number}` : t('q.new')}
      size="lg"
      footer={
        <>
          <Button variant="secondary" onClick={() => save.mutate(false)} loading={save.isPending && save.variables === false} disabled={!valid}>
            {t('q.saveDraft')}
          </Button>
          <Button onClick={() => save.mutate(true)} loading={save.isPending && save.variables === true} disabled={!valid}>
            {t('q.saveSend')}
          </Button>
        </>
      }
    >
      <fieldset>
        <legend className="mb-2 text-[13px] font-medium text-navy-800">{t('q.items')}</legend>
        <div className="space-y-2">
          {lines.map((l, i) => (
            <div key={i} className="grid grid-cols-[1fr_auto] gap-2 rounded-lg border border-line p-2 sm:grid-cols-[7rem_1fr_4.5rem_6.5rem_auto] sm:border-0 sm:p-0">
              <Select value={l.kind} onChange={(e) => update(i, { kind: e.target.value as Line['kind'] })} aria-label="Type" className="col-span-2 sm:col-span-1">
                {(['LABOR', 'PART', 'OTHER'] as const).map((k) => (
                  <option key={k} value={k}>
                    {t(`q.kind.${k}`)}
                  </option>
                ))}
              </Select>
              <Input
                value={l.description}
                onChange={(e) => update(i, { description: e.target.value })}
                placeholder={t('common.description')}
                aria-label={t('common.description')}
                className="col-span-2 sm:col-span-1"
              />
              <Input type="number" min={0.01} step="0.01" value={l.quantity} onChange={(e) => update(i, { quantity: e.target.value })} aria-label={t('q.qty')} placeholder={t('q.qty')} />
              <Input type="number" min={0} step="0.01" value={l.unitPrice} onChange={(e) => update(i, { unitPrice: e.target.value })} aria-label={t('q.unitPrice')} placeholder={t('q.unitPrice')} />
              <Button variant="ghost" onClick={() => setLines((ls) => ls.filter((_, idx) => idx !== i))} disabled={lines.length === 1} aria-label={t('common.delete')}>
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))}
        </div>
        <Button variant="ghost" size="sm" className="mt-2" icon={<Plus className="size-4" />} onClick={() => setLines((ls) => [...ls, { kind: 'PART', description: '', quantity: '1', unitPrice: '' }])}>
          {t('q.addItem')}
        </Button>
      </fieldset>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <div className="grid grid-cols-2 gap-3">
          <Field label={t('q.discount')} htmlFor="disc">
            <Input id="disc" type="number" min={0} step="0.01" value={discount} onChange={(e) => setDiscount(e.target.value)} />
          </Field>
          <Field label={t('q.tax')} htmlFor="tax">
            <Input id="tax" type="number" min={0} max={100} step="0.01" value={taxRate} onChange={(e) => setTaxRate(e.target.value)} />
          </Field>
        </div>
        <dl className="num space-y-1 rounded-lg bg-surface p-4 text-sm">
          <div className="flex justify-between">
            <dt className="text-navy-500">{t('q.subtotal')}</dt>
            <dd>{money(totals.subtotal, currency, locale)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-navy-500">{t('q.discount')}</dt>
            <dd>−{money(totals.discount, currency, locale)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-navy-500">{t('q.tax')}</dt>
            <dd>{money(totals.tax, currency, locale)}</dd>
          </div>
          <div className="flex justify-between border-t border-line pt-1 text-base font-semibold">
            <dt>{t('common.total')}</dt>
            <dd>{money(totals.total, currency, locale)}</dd>
          </div>
        </dl>
      </div>
      <div className="mt-4">
        <Field label={t('common.notes')} htmlFor="qnotes" optional>
          <Textarea id="qnotes" value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>
      </div>
    </Modal>
  );
}
