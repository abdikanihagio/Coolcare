/**
 * End-to-end booking flow against a real database.
 *
 *   DATABASE_URL=postgresql://.../coolcare_test npx prisma migrate reset --force --skip-seed
 *   SMS_PROVIDER=none npm run test:e2e
 *
 * Covers: register → address → book → admin assign → in progress → quote →
 * customer accepts → complete → invoice → payment → rating.
 */
import { INestApplication, ValidationPipe, VersioningType } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import * as bcrypt from 'bcryptjs';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PrismaService } from '../src/prisma/prisma.service';
import { PrismaExceptionFilter } from '../src/common/filters/prisma-exception.filter';

process.env.SMS_PROVIDER = 'none';
process.env.JWT_ACCESS_SECRET ??= 'e2e-access-secret-e2e-access-secret';
process.env.JWT_REFRESH_SECRET ??= 'e2e-refresh-secret-e2e-refresh-secret';

describe('CoolCare booking flow (e2e)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let customerToken: string;
  let adminToken: string;
  let bookingId: string;
  const stamp = Date.now().toString().slice(-7);
  const customerPhone = `+25261${stamp}`;

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api');
    app.enableVersioning({ type: VersioningType.URI, defaultVersion: '1' });
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
    app.useGlobalFilters(new PrismaExceptionFilter());
    await app.init();
    prisma = app.get(PrismaService);

    // Fixtures: staff user, technician, service
    const adminEmail = `admin-${stamp}@test.local`;
    await prisma.user.create({
      data: {
        fullName: 'E2E Admin',
        email: adminEmail,
        phone: `+25262${stamp}`,
        role: 'ADMIN',
        passwordHash: await bcrypt.hash('Admin1234', 10),
        phoneVerifiedAt: new Date(),
      },
    });
    const login = await request(app.getHttpServer()).post('/api/v1/auth/admin/login').send({ identifier: adminEmail, password: 'Admin1234' });
    adminToken = login.body.tokens.accessToken;
  });

  afterAll(async () => {
    await app.close();
  });

  const http = () => request(app.getHttpServer());

  it('registers a customer and returns tokens when OTP is disabled', async () => {
    const res = await http().post('/api/v1/auth/register').send({ fullName: 'E2E Customer', phone: customerPhone, password: 'Secret123' });
    expect(res.status).toBe(201);
    expect(res.body.requiresOtp).toBe(false);
    customerToken = res.body.tokens.accessToken;
  });

  it('rejects weak passwords', async () => {
    const res = await http().post('/api/v1/auth/register').send({ fullName: 'X', phone: '+252619999998', password: 'short' });
    expect(res.status).toBe(400);
  });

  it('creates a booking for tomorrow', async () => {
    const category = await prisma.serviceCategory.upsert({
      where: { slug: 'e2e' },
      create: { slug: 'e2e', nameEn: 'E2E', nameSo: 'E2E' },
      update: {},
    });
    const service = await prisma.service.upsert({
      where: { slug: 'e2e-ac-repair' },
      create: { slug: 'e2e-ac-repair', nameEn: 'AC Repair', nameSo: 'Dayactirka AC', basePrice: '25.00', categoryId: category.id },
      update: {},
    });
    const address = await http()
      .post('/api/v1/me/addresses')
      .set('Authorization', `Bearer ${customerToken}`)
      .send({ label: 'Home', district: 'Hodan' });
    expect(address.status).toBe(201);

    const tomorrow = new Date(Date.now() + 86_400_000 + 3 * 3_600_000).toISOString().slice(0, 10);
    const res = await http()
      .post('/api/v1/bookings')
      .set('Authorization', `Bearer ${customerToken}`)
      .send({ serviceId: service.id, addressId: address.body.id, scheduledDate: tomorrow, timeSlot: 'AFTERNOON', unitCount: 2 });
    expect(res.status).toBe(201);
    expect(res.body.reference).toMatch(/^CC-\d{4}-\d{6}$/);
    expect(res.body.estimatedPrice).toBe('50');
    bookingId = res.body.id;
  });

  it('prevents customers from using admin endpoints', async () => {
    const res = await http().get('/api/v1/admin/bookings').set('Authorization', `Bearer ${customerToken}`);
    expect(res.status).toBe(403);
  });

  it('lets staff assign, start, quote, and complete the job', async () => {
    const tech = await prisma.technician.create({ data: { fullName: 'E2E Tech', phone: `+25263${stamp}`, specialties: [] } });
    const auth = { Authorization: `Bearer ${adminToken}` };

    expect((await http().post(`/api/v1/admin/bookings/${bookingId}/assign`).set(auth).send({ technicianId: tech.id })).status).toBe(201);
    expect((await http().post(`/api/v1/admin/bookings/${bookingId}/status`).set(auth).send({ status: 'ON_THE_WAY' })).status).toBe(201);
    expect((await http().post(`/api/v1/admin/bookings/${bookingId}/status`).set(auth).send({ status: 'IN_PROGRESS' })).status).toBe(201);

    const quote = await http()
      .post(`/api/v1/admin/bookings/${bookingId}/quotes`)
      .set(auth)
      .send({ items: [{ description: 'Gas refill', quantity: 1, unitPrice: 35, kind: 'LABOR' }, { description: 'Capacitor', quantity: 1, unitPrice: 15, kind: 'PART' }], send: true });
    expect(quote.status).toBe(201);
    expect(quote.body.total).toBe('50');

    const booking = await prisma.booking.findUniqueOrThrow({ where: { id: bookingId } });
    expect(booking.status).toBe('AWAITING_APPROVAL');

    const accepted = await http().post(`/api/v1/quotes/${quote.body.id}/accept`).set('Authorization', `Bearer ${customerToken}`);
    expect(accepted.status).toBe(201);
    expect(accepted.body.status).toBe('IN_PROGRESS');

    const done = await http().post(`/api/v1/admin/bookings/${bookingId}/status`).set(auth).send({ status: 'COMPLETED' });
    expect(done.status).toBe(201);
    expect(done.body.invoice.total).toBe('50');
  });

  it('records a payment and marks the invoice paid', async () => {
    const invoice = await prisma.invoice.findUniqueOrThrow({ where: { bookingId } });
    const res = await http()
      .post(`/api/v1/admin/invoices/${invoice.id}/payments`)
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ amount: 50, method: 'EVC_PLUS', reference: `TX${stamp}` });
    expect(res.status).toBe(201);
    expect(res.body.status).toBe('PAID');
  });

  it('lets the customer rate the completed job once', async () => {
    const auth = { Authorization: `Bearer ${customerToken}` };
    expect((await http().post(`/api/v1/bookings/${bookingId}/rate`).set(auth).send({ rating: 5 })).status).toBe(201);
    expect((await http().post(`/api/v1/bookings/${bookingId}/rate`).set(auth).send({ rating: 4 })).status).toBe(400);
  });
});
