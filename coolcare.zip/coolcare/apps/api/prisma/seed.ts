/**
 * Seeds reference data: Mogadishu branch, super admin, service catalog,
 * maintenance plans and default settings. Idempotent — safe to re-run.
 *
 * Set SEED_DEMO=true to also create demo technicians, a demo customer and sample bookings.
 */
import { PrismaClient, PriceType } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const categories = [
  {
    slug: 'air-conditioning',
    nameEn: 'Air Conditioning',
    nameSo: 'Qaboojiyaha Hawada (AC)',
    descriptionEn: 'Repair, gas refill, cleaning and servicing for all AC types.',
    descriptionSo: 'Dayactir, buuxin gaas, nadiifin iyo adeeg dhammaan noocyada AC.',
    icon: 'snowflake',
    sortOrder: 1,
  },
  {
    slug: 'refrigeration',
    nameEn: 'Refrigeration',
    nameSo: 'Firiij iyo Barafeeye',
    descriptionEn: 'Refrigerators, freezers, water coolers and display chillers.',
    descriptionSo: 'Firiijyada, barafeeyayaasha, qaboojiyayaasha biyaha iyo kuwa ganacsiga.',
    icon: 'fridge',
    sortOrder: 2,
  },
  {
    slug: 'installation',
    nameEn: 'Installation',
    nameSo: 'Rakibid',
    descriptionEn: 'Professional installation and relocation of cooling units.',
    descriptionSo: 'Rakibid xirfadeed iyo guurinta qalabka qaboojinta.',
    icon: 'tools',
    sortOrder: 3,
  },
  {
    slug: 'maintenance',
    nameEn: 'Maintenance',
    nameSo: 'Dayactir Joogto ah',
    descriptionEn: 'Inspections and preventive maintenance to keep units efficient.',
    descriptionSo: 'Baaritaan iyo dayactir ka-hortag ah si qalabku si fiican ugu shaqeeyo.',
    icon: 'calendar-check',
    sortOrder: 4,
  },
  {
    slug: 'commercial',
    nameEn: 'Commercial Cooling',
    nameSo: 'Qaboojinta Ganacsiga',
    descriptionEn: 'Cold rooms, central AC and systems for shops, hotels and offices.',
    descriptionSo: 'Qolalka qabow, AC dhexe iyo nidaamyada dukaamada, hoteelada iyo xafiisyada.',
    icon: 'building',
    sortOrder: 5,
  },
];

type ServiceSeed = {
  category: string;
  slug: string;
  nameEn: string;
  nameSo: string;
  descriptionEn: string;
  descriptionSo: string;
  basePrice: number;
  priceType: PriceType;
  durationMinutes: number;
};

const services: ServiceSeed[] = [
  {
    category: 'air-conditioning', slug: 'ac-repair', nameEn: 'AC Repair', nameSo: 'Dayactirka AC',
    descriptionEn: 'Diagnosis and repair of AC units that are not cooling, leaking, noisy or not turning on.',
    descriptionSo: 'Ogaansho iyo dayactir AC aan qaboojinayn, daadanaya, buuq samaynaya ama aan shidmayn.',
    basePrice: 25, priceType: 'STARTING_FROM', durationMinutes: 90,
  },
  {
    category: 'air-conditioning', slug: 'ac-gas-refill', nameEn: 'AC Gas Refill', nameSo: 'Buuxinta Gaaska AC',
    descriptionEn: 'Leak check and refrigerant top-up (R22, R410A, R32).',
    descriptionSo: 'Hubinta daadashada iyo buuxinta gaaska (R22, R410A, R32).',
    basePrice: 35, priceType: 'STARTING_FROM', durationMinutes: 60,
  },
  {
    category: 'air-conditioning', slug: 'ac-cleaning', nameEn: 'AC Deep Cleaning', nameSo: 'Nadiifinta AC',
    descriptionEn: 'Indoor and outdoor unit cleaning, filter wash and drain flush — price per unit.',
    descriptionSo: 'Nadiifinta qaybta gudaha iyo dibadda, dhaqidda filtarka iyo furfurista biyo-mareenka — qiimaha halkii qalab.',
    basePrice: 15, priceType: 'FIXED', durationMinutes: 60,
  },
  {
    category: 'installation', slug: 'ac-installation', nameEn: 'AC Installation', nameSo: 'Rakibidda AC',
    descriptionEn: 'Installation of split or window AC including brackets and up to 3m of piping.',
    descriptionSo: 'Rakibidda AC split ama daaqad, oo ay ku jiraan biraha iyo ilaa 3m tuubo.',
    basePrice: 40, priceType: 'STARTING_FROM', durationMinutes: 180,
  },
  {
    category: 'installation', slug: 'ac-relocation', nameEn: 'AC Removal & Reinstallation', nameSo: 'Ka-qaadista iyo Dib-u-rakibidda AC',
    descriptionEn: 'Safely remove an AC and reinstall it at a new location.',
    descriptionSo: 'Si badbaado leh uga qaad AC oo dib ugu rakib meel cusub.',
    basePrice: 50, priceType: 'STARTING_FROM', durationMinutes: 240,
  },
  {
    category: 'refrigeration', slug: 'fridge-repair', nameEn: 'Refrigerator Repair', nameSo: 'Dayactirka Firiijka',
    descriptionEn: 'Repair of fridges that are not cooling, frosting up, leaking or noisy.',
    descriptionSo: 'Dayactirka firiijyada aan qaboojinayn, baraf badan yeesha, daadanaya ama buuq leh.',
    basePrice: 20, priceType: 'STARTING_FROM', durationMinutes: 90,
  },
  {
    category: 'refrigeration', slug: 'freezer-repair', nameEn: 'Freezer Repair', nameSo: 'Dayactirka Barafeeyaha',
    descriptionEn: 'Chest and upright freezer diagnosis, gas refill and component replacement.',
    descriptionSo: 'Ogaanshaha barafeeyaha, buuxinta gaaska iyo beddelidda qaybaha.',
    basePrice: 25, priceType: 'STARTING_FROM', durationMinutes: 90,
  },
  {
    category: 'refrigeration', slug: 'water-cooler-repair', nameEn: 'Water Cooler Repair', nameSo: 'Dayactirka Qaboojiyaha Biyaha',
    descriptionEn: 'Repair and sanitising of water dispensers and coolers.',
    descriptionSo: 'Dayactirka iyo nadiifinta qaboojiyayaasha biyaha.',
    basePrice: 15, priceType: 'STARTING_FROM', durationMinutes: 60,
  },
  {
    category: 'maintenance', slug: 'inspection', nameEn: 'Inspection & Diagnosis', nameSo: 'Baaritaan iyo Ogaansho',
    descriptionEn: 'A technician inspects the unit and gives you a written quotation before any work.',
    descriptionSo: 'Farsamayaqaan ayaa baaraya qalabka oo ku siinaya qiimayn qoran ka hor shaqo kasta.',
    basePrice: 10, priceType: 'FIXED', durationMinutes: 45,
  },
  {
    category: 'maintenance', slug: 'preventive-maintenance', nameEn: 'Preventive Maintenance Visit', nameSo: 'Booqasho Dayactir Ka-hortag ah',
    descriptionEn: 'Seasonal check-up: cleaning, gas pressure, electrical and performance checks.',
    descriptionSo: 'Hubin xilliyeed: nadiifin, cadaadiska gaaska, korontada iyo waxqabadka.',
    basePrice: 20, priceType: 'STARTING_FROM', durationMinutes: 90,
  },
  {
    category: 'commercial', slug: 'cold-room-service', nameEn: 'Cold Room Service', nameSo: 'Adeegga Qolka Qabow',
    descriptionEn: 'Service and repair for cold rooms and walk-in freezers. Price after inspection.',
    descriptionSo: 'Adeeg iyo dayactir qolalka qabow. Qiimaha waxaa la go’aaminayaa baaritaanka kadib.',
    basePrice: 0, priceType: 'INSPECTION_REQUIRED', durationMinutes: 180,
  },
  {
    category: 'commercial', slug: 'central-ac-service', nameEn: 'Central AC Service', nameSo: 'Adeegga AC-da Dhexe',
    descriptionEn: 'Ducted and central AC systems for offices, hotels and hospitals. Price after inspection.',
    descriptionSo: 'Nidaamyada AC-da dhexe ee xafiisyada, hoteelada iyo isbitaalada. Qiimaha baaritaanka kadib.',
    basePrice: 0, priceType: 'INSPECTION_REQUIRED', durationMinutes: 240,
  },
];

const plans = [
  {
    nameEn: 'Home Basic', nameSo: 'Qorshaha Guriga – Aasaasi',
    descriptionEn: '2 preventive visits per year for up to 2 units, priority booking.',
    descriptionSo: '2 booqasho sanadkii ilaa 2 qalab, mudnaan ballan.',
    price: 60, durationMonths: 12, visitsPerYear: 2, maxUnits: 2,
  },
  {
    nameEn: 'Home Plus', nameSo: 'Qorshaha Guriga – Plus',
    descriptionEn: 'Quarterly visits for up to 4 units, 10% off parts, priority booking.',
    descriptionSo: 'Booqasho saddexdii biloodba mar ilaa 4 qalab, 10% qiimo dhimis qaybaha.',
    price: 110, durationMonths: 12, visitsPerYear: 4, maxUnits: 4,
  },
  {
    nameEn: 'Business Care', nameSo: 'Daryeelka Ganacsiga',
    descriptionEn: 'Monthly visits for up to 15 units, same-day emergency response.',
    descriptionSo: 'Booqasho bil kasta ilaa 15 qalab, jawaab degdeg ah isla maalinta.',
    price: 300, durationMonths: 12, visitsPerYear: 12, maxUnits: 15,
  },
];

async function main() {
  // Branch
  let branch = await prisma.branch.findFirst({ where: { city: 'Mogadishu' } });
  if (!branch) {
    branch = await prisma.branch.create({
      data: { name: 'CoolCare Mogadishu', city: 'Mogadishu', country: 'Somalia', timezone: 'Africa/Mogadishu', currency: 'USD' },
    });
  }

  // Super admin
  const email = (process.env.SEED_ADMIN_EMAIL ?? 'admin@coolcare.so').toLowerCase();
  const password = process.env.SEED_ADMIN_PASSWORD;
  const phone = process.env.SEED_ADMIN_PHONE ?? '+252610000000';
  const existingAdmin = await prisma.user.findFirst({ where: { OR: [{ email }, { phone }] } });
  if (!existingAdmin) {
    if (!password || password.length < 8) throw new Error('Set SEED_ADMIN_PASSWORD (min 8 chars) to create the first admin');
    await prisma.user.create({
      data: {
        fullName: 'CoolCare Admin',
        email,
        phone,
        role: 'SUPER_ADMIN',
        passwordHash: await bcrypt.hash(password, 12),
        phoneVerifiedAt: new Date(),
        branchId: branch.id,
      },
    });
    console.log(`✔ Super admin created: ${email}`);
  }

  // Catalog
  for (const c of categories) {
    await prisma.serviceCategory.upsert({ where: { slug: c.slug }, create: c, update: {} });
  }
  const catIds = new Map<string, string>((await prisma.serviceCategory.findMany()).map((c) => [c.slug, c.id]));
  for (const [i, s] of services.entries()) {
    const { category, ...data } = s;
    await prisma.service.upsert({
      where: { slug: s.slug },
      create: { ...data, basePrice: data.basePrice.toFixed(2), categoryId: catIds.get(category)!, sortOrder: i },
      update: {},
    });
  }

  // Maintenance plans
  if ((await prisma.maintenancePlan.count()) === 0) {
    for (const p of plans) await prisma.maintenancePlan.create({ data: { ...p, price: p.price.toFixed(2) } });
  }

  if (process.env.SEED_DEMO === 'true') await seedDemo(branch.id);
  console.log('✔ Seed complete');
}

async function seedDemo(branchId: string) {
  const techs = [
    { fullName: 'Abdirahman Farah', phone: '+252615550101', specialties: ['SPLIT_AC', 'WINDOW_AC', 'CENTRAL_AC'] },
    { fullName: 'Mohamed Ali Warsame', phone: '+252615550102', specialties: ['REFRIGERATOR', 'FREEZER', 'WATER_COOLER'] },
    { fullName: 'Hassan Abdi Nur', phone: '+252615550103', specialties: ['SPLIT_AC', 'COLD_ROOM'] },
    { fullName: 'Yusuf Omar Hirsi', phone: '+252615550104', specialties: ['SPLIT_AC', 'REFRIGERATOR'] },
  ];
  for (const t of techs) {
    await prisma.technician.upsert({ where: { phone: t.phone }, create: { ...t, branchId }, update: {} });
  }

  const customerPhone = '+252615559999';
  let customer = await prisma.user.findUnique({ where: { phone: customerPhone } });
  if (!customer) {
    customer = await prisma.user.create({
      data: {
        fullName: 'Demo Customer',
        phone: customerPhone,
        passwordHash: await bcrypt.hash('Demo1234', 12),
        phoneVerifiedAt: new Date(),
        addresses: {
          create: { label: 'Home', district: 'Hodan', neighborhood: 'Taleex', landmark: 'Near Taleex junction', isDefault: true, latitude: 2.0371, longitude: 45.3082 },
        },
        equipment: { create: { type: 'SPLIT_AC', brand: 'Gree', capacity: '1.5 ton', location: 'Living room' } },
      },
    });
    console.log('✔ Demo customer: +252 61 555 9999 / Demo1234');
  }
  console.log('✔ Demo technicians created');
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
