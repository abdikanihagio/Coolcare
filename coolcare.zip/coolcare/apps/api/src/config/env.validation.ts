/**
 * Validates required environment variables at startup so misconfiguration
 * fails fast instead of surfacing as runtime errors.
 */
const REQUIRED = ['DATABASE_URL', 'JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET'] as const;

const INSECURE_DEFAULTS = ['replace-with-long-random-string', 'replace-with-another-long-random-string', 'changeme', 'secret'];

export function validateEnv(config: Record<string, unknown>): Record<string, unknown> {
  const missing = REQUIRED.filter((key) => !config[key] || String(config[key]).trim() === '');
  if (missing.length) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }

  if (config.NODE_ENV === 'production') {
    for (const key of ['JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET']) {
      const value = String(config[key]);
      if (value.length < 32 || INSECURE_DEFAULTS.includes(value)) {
        throw new Error(`${key} must be a random string of at least 32 characters in production`);
      }
    }
    if (config.SMS_PROVIDER === 'console') {
      // eslint-disable-next-line no-console
      console.warn('[env] SMS_PROVIDER=console in production: OTP codes will only be logged, not sent.');
    }
  }
  return config;
}
