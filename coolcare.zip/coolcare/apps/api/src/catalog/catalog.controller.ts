import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiQuery, ApiTags } from '@nestjs/swagger';
import { CurrentUser, Public, Roles } from '../common/decorators';
import type { AuthUser } from '../common/types';
import { CatalogService } from './catalog.service';
import { CategoryDto, ServiceDto, UpdateCategoryDto, UpdateServiceDto } from './dto';

@ApiTags('Catalog')
@Controller('catalog')
export class CatalogController {
  constructor(private readonly catalog: CatalogService) {}

  @Public()
  @Get('categories')
  categories() {
    return this.catalog.categories();
  }

  @Public()
  @Get('services')
  @ApiQuery({ name: 'categoryId', required: false })
  @ApiQuery({ name: 'search', required: false })
  services(@Query('categoryId') categoryId?: string, @Query('search') search?: string) {
    return this.catalog.services({ categoryId, search });
  }

  @Public()
  @Get('services/:idOrSlug')
  service(@Param('idOrSlug') idOrSlug: string) {
    return this.catalog.service(idOrSlug);
  }
}

@ApiTags('Admin · Catalog')
@ApiBearerAuth()
@Roles('ADMIN')
@Controller('admin/catalog')
export class AdminCatalogController {
  constructor(private readonly catalog: CatalogService) {}

  @Get('categories')
  @Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
  categories() {
    return this.catalog.categories(true);
  }

  @Post('categories')
  createCategory(@CurrentUser() u: AuthUser, @Body() dto: CategoryDto) {
    return this.catalog.createCategory(u.id, dto);
  }

  @Patch('categories/:id')
  updateCategory(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateCategoryDto) {
    return this.catalog.updateCategory(u.id, id, dto);
  }

  @Delete('categories/:id')
  deleteCategory(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.catalog.deleteCategory(u.id, id);
  }

  @Get('services')
  @Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
  services(@Query('categoryId') categoryId?: string, @Query('search') search?: string) {
    return this.catalog.services({ categoryId, search, includeInactive: true });
  }

  @Post('services')
  createService(@CurrentUser() u: AuthUser, @Body() dto: ServiceDto) {
    return this.catalog.createService(u.id, dto);
  }

  @Patch('services/:id')
  updateService(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateServiceDto) {
    return this.catalog.updateService(u.id, id, dto);
  }

  @Delete('services/:id')
  deleteService(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.catalog.deleteService(u.id, id);
  }
}
