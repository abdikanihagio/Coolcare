import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsBoolean, IsEnum, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, IsUrl, IsUUID, Matches, MaxLength, Min } from 'class-validator';
import { PriceType } from '@prisma/client';

const SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export class CategoryDto {
  @ApiProperty({ example: 'ac-services' }) @Matches(SLUG, { message: 'Slug must be lowercase letters, numbers and dashes' }) slug: string;
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(80) nameEn: string;
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(80) nameSo: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) descriptionEn?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) descriptionSo?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(40) icon?: string;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() sortOrder?: number;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() isActive?: boolean;
}
export class UpdateCategoryDto extends PartialType(CategoryDto) {}

export class ServiceDto {
  @ApiProperty() @IsUUID() categoryId: string;
  @ApiProperty({ example: 'ac-gas-refill' }) @Matches(SLUG, { message: 'Slug must be lowercase letters, numbers and dashes' }) slug: string;
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(100) nameEn: string;
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(100) nameSo: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(1000) descriptionEn?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(1000) descriptionSo?: string;
  @ApiProperty({ example: 25 }) @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) basePrice: number;
  @ApiPropertyOptional({ enum: PriceType }) @IsOptional() @IsEnum(PriceType) priceType?: PriceType;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(15) durationMinutes?: number;
  @ApiPropertyOptional() @IsOptional() @IsUrl({ require_tld: false }) imageUrl?: string;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() sortOrder?: number;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() isActive?: boolean;
}
export class UpdateServiceDto extends PartialType(ServiceDto) {}
