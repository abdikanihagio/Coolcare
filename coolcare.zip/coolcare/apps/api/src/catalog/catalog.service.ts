import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { CategoryDto, ServiceDto, UpdateCategoryDto, UpdateServiceDto } from './dto';

@Injectable()
export class CatalogService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  /** Public catalog: active categories with their active services. */
  categories(includeInactive = false) {
    return this.prisma.serviceCategory.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: [{ sortOrder: 'asc' }, { nameEn: 'asc' }],
      include: {
        services: {
          where: includeInactive ? {} : { isActive: true },
          orderBy: [{ sortOrder: 'asc' }, { nameEn: 'asc' }],
        },
      },
    });
  }

  services(opts: { categoryId?: string; search?: string; includeInactive?: boolean }) {
    return this.prisma.service.findMany({
      where: {
        ...(opts.includeInactive ? {} : { isActive: true, category: { isActive: true } }),
        categoryId: opts.categoryId,
        ...(opts.search
          ? {
              OR: [
                { nameEn: { contains: opts.search, mode: 'insensitive' } },
                { nameSo: { contains: opts.search, mode: 'insensitive' } },
              ],
            }
          : {}),
      },
      orderBy: [{ sortOrder: 'asc' }, { nameEn: 'asc' }],
      include: { category: { select: { id: true, nameEn: true, nameSo: true, slug: true } } },
    });
  }

  async service(idOrSlug: string) {
    const isUuid = /^[0-9a-f-]{36}$/i.test(idOrSlug);
    const service = await this.prisma.service.findFirst({
      where: isUuid ? { id: idOrSlug } : { slug: idOrSlug },
      include: { category: true },
    });
    if (!service) throw new NotFoundException('Service not found');
    return service;
  }

  async createCategory(actorId: string, dto: CategoryDto) {
    const c = await this.prisma.serviceCategory.create({ data: dto });
    await this.audit.log(actorId, 'category.create', 'ServiceCategory', c.id);
    return c;
  }

  async updateCategory(actorId: string, id: string, dto: UpdateCategoryDto) {
    const c = await this.prisma.serviceCategory.update({ where: { id }, data: dto });
    await this.audit.log(actorId, 'category.update', 'ServiceCategory', id, dto as Record<string, unknown>);
    return c;
  }

  async deleteCategory(actorId: string, id: string) {
    const inUse = await this.prisma.service.count({ where: { categoryId: id } });
    if (inUse) {
      // Keep history intact: deactivate instead of deleting
      await this.prisma.serviceCategory.update({ where: { id }, data: { isActive: false } });
      await this.audit.log(actorId, 'category.deactivate', 'ServiceCategory', id);
      return { ok: true, deactivated: true };
    }
    await this.prisma.serviceCategory.delete({ where: { id } });
    await this.audit.log(actorId, 'category.delete', 'ServiceCategory', id);
    return { ok: true, deactivated: false };
  }

  async createService(actorId: string, dto: ServiceDto) {
    const s = await this.prisma.service.create({ data: dto });
    await this.audit.log(actorId, 'service.create', 'Service', s.id);
    return s;
  }

  async updateService(actorId: string, id: string, dto: UpdateServiceDto) {
    const s = await this.prisma.service.update({ where: { id }, data: dto });
    await this.audit.log(actorId, 'service.update', 'Service', id, dto as Record<string, unknown>);
    return s;
  }

  async deleteService(actorId: string, id: string) {
    const used = await this.prisma.booking.count({ where: { serviceId: id } });
    if (used) {
      await this.prisma.service.update({ where: { id }, data: { isActive: false } });
      await this.audit.log(actorId, 'service.deactivate', 'Service', id);
      return { ok: true, deactivated: true };
    }
    await this.prisma.service.delete({ where: { id } });
    await this.audit.log(actorId, 'service.delete', 'Service', id);
    return { ok: true, deactivated: false };
  }
}
