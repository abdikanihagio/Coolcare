import { Body, Controller, Get, Injectable, Module, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiProperty, ApiPropertyOptional, ApiTags, PartialType } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty, IsOptional, IsString, Matches, MaxLength } from 'class-validator';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { CurrentUser, Public, Roles } from '../common/decorators';
import type { AuthUser } from '../common/types';

export class BranchDto {
  @ApiProperty({ example: 'CoolCare Mogadishu' }) @IsString() @IsNotEmpty() @MaxLength(80) name: string;
  @ApiProperty({ example: 'Mogadishu' }) @IsString() @IsNotEmpty() @MaxLength(60) city: string;
  @ApiPropertyOptional({ example: 'Somalia' }) @IsOptional() @IsString() @MaxLength(60) country?: string;
  @ApiPropertyOptional({ example: 'Africa/Mogadishu' }) @IsOptional() @IsString() timezone?: string;
  @ApiPropertyOptional({ example: 'USD' }) @IsOptional() @Matches(/^[A-Z]{3}$/) currency?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(20) phone?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(200) address?: string;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() isActive?: boolean;
}
export class UpdateBranchDto extends PartialType(BranchDto) {}

@Injectable()
export class BranchesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  list(activeOnly = false) {
    return this.prisma.branch.findMany({
      where: activeOnly ? { isActive: true } : {},
      orderBy: { name: 'asc' },
      include: activeOnly ? undefined : { _count: { select: { technicians: true, bookings: true } } },
    });
  }

  async create(actorId: string, dto: BranchDto) {
    const b = await this.prisma.branch.create({ data: dto });
    await this.audit.log(actorId, 'branch.create', 'Branch', b.id);
    return b;
  }

  async update(actorId: string, id: string, dto: UpdateBranchDto) {
    const b = await this.prisma.branch.update({ where: { id }, data: dto });
    await this.audit.log(actorId, 'branch.update', 'Branch', id);
    return b;
  }
}

@ApiTags('Branches')
@Controller('branches')
export class BranchesController {
  constructor(private readonly branches: BranchesService) {}

  @Public()
  @Get()
  list() {
    return this.branches.list(true);
  }
}

@ApiTags('Admin · Branches')
@ApiBearerAuth()
@Roles('ADMIN')
@Controller('admin/branches')
export class AdminBranchesController {
  constructor(private readonly branches: BranchesService) {}

  @Get()
  @Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
  list() {
    return this.branches.list();
  }

  @Post()
  create(@CurrentUser() u: AuthUser, @Body() dto: BranchDto) {
    return this.branches.create(u.id, dto);
  }

  @Patch(':id')
  update(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateBranchDto) {
    return this.branches.update(u.id, id, dto);
  }
}

@Module({ controllers: [BranchesController, AdminBranchesController], providers: [BranchesService] })
export class BranchesModule {}
