import { BadRequestException, Body, Controller, Get, Global, Injectable, Module, Patch } from '@nestjs/common';
import { ApiBearerAuth, ApiPropertyOptional, ApiTags } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsEmail,
  IsIn,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  Length,
  Matches,
  Max,
  MaxLength,
  Min,
} from 'class-validator';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { CurrentUser, Public, Roles } from '../common/decorators';
import type { AuthUser } from '../common/types';

/** Company-wide configuration editable from the admin dashboard. */
export interface CompanySettings {
  companyName: string;
  supportPhone: string;
  supportWhatsapp: string;
  supportEmail: string;
  currency: string;
  supportedCurrencies: string[];
  taxRate: number;
  timezone: string;
  defaultLocale: 'en' | 'so';
  bookingLeadHours: number;
  maxBookingsPerSlot: number;
  quoteValidityDays: number;
  invoiceDueDays: number;
  emergencySurcharge: number;
  paymentMethods: string[];
  mobileMoneyInstructionsEn: string;
  mobileMoneyInstructionsSo: string;
  serviceDistricts: string[];
  maintenanceReminderDays: number;
  allowCustomerCancellation: boolean;
}

export const DEFAULT_SETTINGS: CompanySettings = {
  companyName: 'CoolCare',
  supportPhone: '+252610000000',
  supportWhatsapp: '+252610000000',
  supportEmail: 'support@coolcare.so',
  currency: process.env.DEFAULT_CURRENCY ?? 'USD',
  supportedCurrencies: ['USD', 'SOS'],
  taxRate: 0,
  timezone: process.env.DEFAULT_TIMEZONE ?? 'Africa/Mogadishu',
  defaultLocale: 'en',
  bookingLeadHours: 2,
  maxBookingsPerSlot: 10,
  quoteValidityDays: 7,
  invoiceDueDays: 7,
  emergencySurcharge: 10,
  paymentMethods: ['CASH', 'EVC_PLUS', 'ZAAD', 'SAHAL', 'EDAHAB', 'BANK_TRANSFER'],
  mobileMoneyInstructionsEn: 'Send payment via EVC Plus to the CoolCare merchant number and share the transaction ID with our team.',
  mobileMoneyInstructionsSo: 'Lacagta ku dir EVC Plus lambarka ganacsiga CoolCare, kadibna la wadaag lambarka macaamilka kooxdeena.',
  serviceDistricts: [
    'Abdiaziz', 'Bondhere', 'Daynile', 'Dharkenley', 'Hamar Jajab', 'Hamar Weyne', 'Hodan', 'Howlwadaag',
    'Kaaraan', 'Kahda', 'Shangani', 'Shibis', 'Waberi', 'Wadajir', 'Wardhigley', 'Yaqshid', 'Garasbaley', 'Heliwaa',
  ],
  maintenanceReminderDays: 3,
  allowCustomerCancellation: true,
};

const SETTINGS_KEY = 'company';

export class UpdateSettingsDto {
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(80) companyName?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(20) supportPhone?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(20) supportWhatsapp?: string;
  @ApiPropertyOptional() @IsOptional() @IsEmail() supportEmail?: string;
  @ApiPropertyOptional() @IsOptional() @Matches(/^[A-Z]{3}$/) currency?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() @Length(3, 3, { each: true }) supportedCurrencies?: string[];
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsNumber() @Min(0) @Max(100) taxRate?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() timezone?: string;
  @ApiPropertyOptional() @IsOptional() @IsIn(['en', 'so']) defaultLocale?: 'en' | 'so';
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(168) bookingLeadHours?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(500) maxBookingsPerSlot?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(90) quoteValidityDays?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(0) @Max(90) invoiceDueDays?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsNumber() @Min(0) emergencySurcharge?: number;
  @ApiPropertyOptional() @IsOptional() @IsArray() @IsString({ each: true }) paymentMethods?: string[];
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) mobileMoneyInstructionsEn?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) mobileMoneyInstructionsSo?: string;
  @ApiPropertyOptional() @IsOptional() @IsArray() @IsString({ each: true }) serviceDistricts?: string[];
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(30) maintenanceReminderDays?: number;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() allowCustomerCancellation?: boolean;
}

@Injectable()
export class SettingsService {
  private cache: { value: CompanySettings; at: number } | null = null;

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  async get(): Promise<CompanySettings> {
    if (this.cache && Date.now() - this.cache.at < 30_000) return this.cache.value;
    const row = await this.prisma.setting.findUnique({ where: { key: SETTINGS_KEY } });
    const value = { ...DEFAULT_SETTINGS, ...((row?.value as Partial<CompanySettings>) ?? {}) };
    this.cache = { value, at: Date.now() };
    return value;
  }

  async update(actorId: string, patch: UpdateSettingsDto): Promise<CompanySettings> {
    if (patch.timezone) {
      try {
        new Intl.DateTimeFormat('en', { timeZone: patch.timezone });
      } catch {
        throw new BadRequestException('Invalid timezone');
      }
    }
    const next = { ...(await this.get()), ...patch };
    await this.prisma.setting.upsert({
      where: { key: SETTINGS_KEY },
      create: { key: SETTINGS_KEY, value: next as unknown as Prisma.InputJsonValue },
      update: { value: next as unknown as Prisma.InputJsonValue },
    });
    this.cache = null;
    await this.audit.log(actorId, 'settings.update', 'Setting', SETTINGS_KEY, patch as Record<string, unknown>);
    return next;
  }

  /** Subset safe to expose to the public mobile app. */
  async publicSettings() {
    const s = await this.get();
    return {
      companyName: s.companyName,
      supportPhone: s.supportPhone,
      supportWhatsapp: s.supportWhatsapp,
      supportEmail: s.supportEmail,
      currency: s.currency,
      timezone: s.timezone,
      bookingLeadHours: s.bookingLeadHours,
      emergencySurcharge: s.emergencySurcharge,
      paymentMethods: s.paymentMethods,
      mobileMoneyInstructionsEn: s.mobileMoneyInstructionsEn,
      mobileMoneyInstructionsSo: s.mobileMoneyInstructionsSo,
      serviceDistricts: s.serviceDistricts,
      allowCustomerCancellation: s.allowCustomerCancellation,
    };
  }
}

@ApiTags('Settings')
@Controller('settings')
export class SettingsController {
  constructor(private readonly settings: SettingsService) {}

  @Public()
  @Get('public')
  publicSettings() {
    return this.settings.publicSettings();
  }

  @ApiBearerAuth()
  @Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
  @Get()
  all() {
    return this.settings.get();
  }

  @ApiBearerAuth()
  @Roles('ADMIN')
  @Patch()
  update(@CurrentUser() u: AuthUser, @Body() dto: UpdateSettingsDto) {
    return this.settings.update(u.id, dto);
  }
}

@Global()
@Module({ controllers: [SettingsController], providers: [SettingsService], exports: [SettingsService] })
export class SettingsModule {}
