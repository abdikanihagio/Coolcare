import type { Role } from '@prisma/client';

export interface AuthUser {
  id: string;
  role: Role;
  phone: string;
  locale: 'en' | 'so';
}

export interface JwtPayload {
  sub: string;
  role: Role;
  phone: string;
  locale: 'en' | 'so';
}

export const STAFF_ROLES: Role[] = ['SUPER_ADMIN', 'ADMIN', 'DISPATCHER', 'ACCOUNTANT'];

export interface Paginated<T> {
  data: T[];
  meta: { page: number; pageSize: number; total: number; totalPages: number };
}
