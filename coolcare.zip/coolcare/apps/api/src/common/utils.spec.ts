import { isValidPhone, normalizePhone } from './phone';
import { addMonths, dateOnly, hoursUntilSlot, isValidIsoDate, zonedParts } from './time';
import { interpolate, render, TEMPLATES } from '../notifications/templates';

describe('normalizePhone', () => {
  it.each([
    ['+252 61 234 5678', '+252612345678'],
    ['00252612345678', '+252612345678'],
    ['252612345678', '+252612345678'],
    ['0612345678', '+252612345678'],
    ['612345678', '+252612345678'],
    ['+1 (415) 555-0100', '+14155550100'],
  ])('%s → %s', (input, expected) => {
    expect(normalizePhone(input)).toBe(expected);
    expect(isValidPhone(normalizePhone(input))).toBe(true);
  });

  it('rejects junk', () => {
    expect(isValidPhone(normalizePhone('abc'))).toBe(false);
    expect(isValidPhone('+2526')).toBe(false);
  });
});

describe('time helpers', () => {
  const tz = 'Africa/Mogadishu';

  it('computes local date and minutes in Mogadishu (UTC+3)', () => {
    const parts = zonedParts(tz, new Date('2026-10-22T22:30:00Z'));
    expect(parts).toEqual({ date: '2026-10-23', minutes: 90 });
  });

  it('measures hours until a slot in local time', () => {
    // 10:00 local on 22 Oct → afternoon slot (12:00) is 2h away
    const now = new Date('2026-10-22T07:00:00Z');
    expect(hoursUntilSlot('2026-10-22', 'AFTERNOON', tz, now)).toBe(2);
    expect(hoursUntilSlot('2026-10-22', 'MORNING', tz, now)).toBe(-2);
    expect(hoursUntilSlot('2026-10-23', 'MORNING', tz, now)).toBe(22);
  });

  it('validates ISO dates strictly', () => {
    expect(isValidIsoDate('2026-02-28')).toBe(true);
    expect(isValidIsoDate('2026-02-30')).toBe(false);
    expect(isValidIsoDate('26-2-1')).toBe(false);
  });

  it('adds months on date-only values', () => {
    expect(addMonths(dateOnly('2026-01-15'), 12).toISOString().slice(0, 10)).toBe('2027-01-15');
  });
});

describe('notification templates', () => {
  it('has English and Somali copy for every type', () => {
    for (const [type, copy] of Object.entries(TEMPLATES)) {
      expect(copy.en.title).toBeTruthy();
      expect(copy.so.title).toBeTruthy();
      expect(copy.en.body).toBeTruthy();
      expect(copy.so.body).toBeTruthy();
      // Somali copy must use the same placeholders as English
      const placeholders = (s: string) => (s.match(/\{\w+\}/g) ?? []).sort().join();
      expect(`${type}:${placeholders(copy.so.title + copy.so.body)}`).toBe(`${type}:${placeholders(copy.en.title + copy.en.body)}`);
    }
  });

  it('renders in the requested language', () => {
    expect(render('BOOKING_CREATED', 'so', { ref: 'CC-2026-000001' }).body).toContain('CC-2026-000001');
    expect(render('TECHNICIAN_ASSIGNED', 'en', { ref: 'X', tech: 'Ali' }).body).toBe('Ali has been assigned to your booking X.');
  });

  it('leaves unknown placeholders intact', () => {
    expect(interpolate('Hi {name} {missing}', { name: 'Amina' })).toBe('Hi Amina {missing}');
  });
});
