/**
 * Timezone helpers. Bookings are scheduled by local calendar date + time slot
 * in the branch timezone (default Africa/Mogadishu, UTC+3, no DST).
 */
export const SLOT_START_MINUTES = { MORNING: 8 * 60, AFTERNOON: 12 * 60, EVENING: 16 * 60 } as const;
export const SLOT_LABELS = {
  MORNING: { en: 'Morning (8:00–12:00)', so: 'Subax (8:00–12:00)' },
  AFTERNOON: { en: 'Afternoon (12:00–16:00)', so: 'Galab (12:00–16:00)' },
  EVENING: { en: 'Evening (16:00–19:00)', so: 'Fiid (16:00–19:00)' },
} as const;
export type Slot = keyof typeof SLOT_START_MINUTES;

/** Returns the local date (YYYY-MM-DD) and minutes since local midnight for an instant. */
export function zonedParts(timeZone: string, at: Date = new Date()): { date: string; minutes: number } {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(at);
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? '00';
  return { date: `${get('year')}-${get('month')}-${get('day')}`, minutes: Number(get('hour')) * 60 + Number(get('minute')) };
}

function dayDiff(a: string, b: string): number {
  return Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86_400_000);
}

/** Hours between `at` and the start of the given local date+slot (negative if already passed). */
export function hoursUntilSlot(date: string, slot: Slot, timeZone: string, at: Date = new Date()): number {
  const now = zonedParts(timeZone, at);
  const minutes = dayDiff(now.date, date) * 1440 + SLOT_START_MINUTES[slot] - now.minutes;
  return minutes / 60;
}

export function isValidIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().startsWith(value);
}

/** Converts YYYY-MM-DD to a Date at UTC midnight, the representation Prisma uses for @db.Date. */
export function dateOnly(value: string): Date {
  return new Date(`${value}T00:00:00Z`);
}

export function addDays(date: Date, days: number): Date {
  return new Date(date.getTime() + days * 86_400_000);
}

export function addMonths(date: Date, months: number): Date {
  const d = new Date(date);
  d.setUTCMonth(d.getUTCMonth() + months);
  return d;
}
