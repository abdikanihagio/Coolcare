import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
import { Prisma } from '@prisma/client';

/**
 * Converts Prisma errors into clean HTTP responses and normalises the error
 * envelope for every exception: { statusCode, message, error }.
 */
@Catch()
export class PrismaExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger('Exceptions');

  catch(exception: unknown, host: ArgumentsHost) {
    const response = host.switchToHttp().getResponse();

    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const body = exception.getResponse();
      const message = typeof body === 'string' ? body : (body as { message?: unknown }).message ?? exception.message;
      return response.status(status).json({ statusCode: status, message, error: HttpStatus[status] });
    }

    if (exception instanceof Prisma.PrismaClientKnownRequestError) {
      switch (exception.code) {
        case 'P2002': {
          const target = (exception.meta?.target as string[] | undefined)?.join(', ') ?? 'field';
          return response
            .status(HttpStatus.CONFLICT)
            .json({ statusCode: 409, message: `A record with this ${target} already exists`, error: 'CONFLICT' });
        }
        case 'P2025':
          return response.status(HttpStatus.NOT_FOUND).json({ statusCode: 404, message: 'Record not found', error: 'NOT_FOUND' });
        case 'P2003':
          return response
            .status(HttpStatus.CONFLICT)
            .json({ statusCode: 409, message: 'This record is referenced by other data', error: 'CONFLICT' });
      }
    }

    this.logger.error(exception instanceof Error ? exception.stack : String(exception));
    return response
      .status(HttpStatus.INTERNAL_SERVER_ERROR)
      .json({ statusCode: 500, message: 'Something went wrong. Please try again.', error: 'INTERNAL_SERVER_ERROR' });
  }
}
