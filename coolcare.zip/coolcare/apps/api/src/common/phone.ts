/**
 * Normalises Somali phone numbers to E.164 (+252XXXXXXXXX).
 * Accepts: +252 61 234 5678, 00252612345678, 252612345678, 0612345678, 612345678.
 * Non-Somali numbers already in E.164 form are returned unchanged.
 */
export function normalizePhone(input: string, defaultCountryCode = '252'): string {
  const trimmed = input.trim();
  const digits = trimmed.replace(/[^\d]/g, '');
  if (!digits) return trimmed;

  if (trimmed.startsWith('+')) return `+${digits}`;
  if (digits.startsWith('00')) return `+${digits.slice(2)}`;
  if (digits.startsWith(defaultCountryCode) && digits.length >= 11) return `+${digits}`;
  if (digits.startsWith('0')) return `+${defaultCountryCode}${digits.slice(1)}`;
  return `+${defaultCountryCode}${digits}`;
}

export function isValidPhone(e164: string): boolean {
  return /^\+\d{9,15}$/.test(e164);
}
