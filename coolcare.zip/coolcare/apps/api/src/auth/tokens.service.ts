import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { createHash, randomBytes } from 'crypto';
import type { User } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import type { JwtPayload } from '../common/types';

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  /** Access token lifetime in seconds */
  expiresIn: number;
}

function parseTtlSeconds(ttl: string): number {
  const match = /^(\d+)([smhd])$/.exec(ttl);
  if (!match) return 900;
  const n = Number(match[1]);
  return n * { s: 1, m: 60, h: 3600, d: 86400 }[match[2] as 's' | 'm' | 'h' | 'd'];
}

const sha256 = (value: string) => createHash('sha256').update(value).digest('hex');

@Injectable()
export class TokensService {
  constructor(
    private readonly jwt: JwtService,
    private readonly prisma: PrismaService,
  ) {}

  async issue(user: Pick<User, 'id' | 'role' | 'phone' | 'locale'>, meta: { userAgent?: string; ip?: string } = {}): Promise<TokenPair> {
    const expiresIn = parseTtlSeconds(process.env.JWT_ACCESS_TTL ?? '15m');
    const payload: JwtPayload = { sub: user.id, role: user.role, phone: user.phone, locale: user.locale };
    const accessToken = await this.jwt.signAsync(payload, { secret: process.env.JWT_ACCESS_SECRET, expiresIn });

    const refreshToken = randomBytes(48).toString('base64url');
    const days = Number(process.env.JWT_REFRESH_TTL_DAYS ?? 30);
    await this.prisma.refreshToken.create({
      data: {
        userId: user.id,
        tokenHash: sha256(refreshToken),
        userAgent: meta.userAgent?.slice(0, 255),
        ip: meta.ip,
        expiresAt: new Date(Date.now() + days * 86_400_000),
      },
    });
    return { accessToken, refreshToken, expiresIn };
  }

  /**
   * Rotates a refresh token. Presenting an already-revoked token is treated as
   * theft: every session for that user is revoked.
   */
  async rotate(refreshToken: string, meta: { userAgent?: string; ip?: string } = {}): Promise<{ tokens: TokenPair; user: User }> {
    const record = await this.prisma.refreshToken.findUnique({
      where: { tokenHash: sha256(refreshToken) },
      include: { user: true },
    });
    if (!record) throw new UnauthorizedException('Invalid session');

    if (record.revokedAt) {
      await this.revokeAll(record.userId);
      throw new UnauthorizedException('Session was revoked. Please sign in again.');
    }
    if (record.expiresAt < new Date()) throw new UnauthorizedException('Session expired. Please sign in again.');
    if (record.user.status !== 'ACTIVE' || record.user.deletedAt) throw new UnauthorizedException('Account is not active');

    await this.prisma.refreshToken.update({ where: { id: record.id }, data: { revokedAt: new Date() } });
    const tokens = await this.issue(record.user, meta);
    return { tokens, user: record.user };
  }

  async revoke(refreshToken: string) {
    await this.prisma.refreshToken.updateMany({
      where: { tokenHash: sha256(refreshToken), revokedAt: null },
      data: { revokedAt: new Date() },
    });
  }

  async revokeAll(userId: string) {
    await this.prisma.refreshToken.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } });
  }
}
