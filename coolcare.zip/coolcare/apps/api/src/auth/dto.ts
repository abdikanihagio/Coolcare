import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsEmail, IsIn, IsNotEmpty, IsOptional, IsString, Length, Matches, MaxLength, MinLength } from 'class-validator';

const PASSWORD_RULE = /^(?=.*[A-Za-z])(?=.*\d).{8,72}$/;
const PASSWORD_MESSAGE = 'Password must be 8–72 characters and include at least one letter and one number';

export class RegisterDto {
  @ApiProperty({ example: 'Amina Hassan' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  fullName: string;

  @ApiProperty({ example: '+252612345678' })
  @IsString()
  @IsNotEmpty()
  phone: string;

  @ApiPropertyOptional({ example: 'amina@example.com' })
  @IsOptional()
  @IsEmail()
  email?: string;

  @ApiProperty({ example: 'Secret123' })
  @Matches(PASSWORD_RULE, { message: PASSWORD_MESSAGE })
  password: string;

  @ApiPropertyOptional({ enum: ['en', 'so'] })
  @IsOptional()
  @IsIn(['en', 'so'])
  locale?: 'en' | 'so';
}

export class LoginDto {
  @ApiProperty({ description: 'Phone number or email', example: '+252612345678' })
  @IsString()
  @IsNotEmpty()
  identifier: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(72)
  password: string;
}

export class OtpRequestDto {
  @ApiProperty({ example: '+252612345678' })
  @IsString()
  @IsNotEmpty()
  phone: string;

  @ApiProperty({ enum: ['VERIFY_PHONE', 'RESET_PASSWORD'] })
  @IsIn(['VERIFY_PHONE', 'RESET_PASSWORD'])
  purpose: 'VERIFY_PHONE' | 'RESET_PASSWORD';
}

export class OtpVerifyDto {
  @ApiProperty({ example: '+252612345678' })
  @IsString()
  @IsNotEmpty()
  phone: string;

  @ApiProperty({ example: '123456' })
  @IsString()
  @Length(6, 6)
  code: string;
}

export class RefreshDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  refreshToken: string;
}

export class ForgotPasswordDto {
  @ApiProperty({ example: '+252612345678' })
  @IsString()
  @IsNotEmpty()
  phone: string;
}

export class ResetPasswordDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  phone: string;

  @ApiProperty()
  @IsString()
  @Length(6, 6)
  code: string;

  @ApiProperty()
  @Matches(PASSWORD_RULE, { message: PASSWORD_MESSAGE })
  newPassword: string;
}

export class ChangePasswordDto {
  @ApiProperty()
  @IsString()
  @MinLength(1)
  currentPassword: string;

  @ApiProperty()
  @Matches(PASSWORD_RULE, { message: PASSWORD_MESSAGE })
  newPassword: string;
}

export { PASSWORD_RULE, PASSWORD_MESSAGE };
