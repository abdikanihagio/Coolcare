import { BadRequestException, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { createHmac, randomInt, timingSafeEqual } from 'crypto';
import type { OtpPurpose } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { SmsProvider } from '../notifications/sms.provider';
import { interpolate, OTP_SMS } from '../notifications/templates';

const RESEND_COOLDOWN_SECONDS = 60;

@Injectable()
export class OtpService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly sms: SmsProvider,
  ) {}

  /** OTP is enforced whenever an SMS channel exists (SMS_PROVIDER != none). */
  get enabled(): boolean {
    return (process.env.SMS_PROVIDER ?? 'console') !== 'none' && this.sms.isConfigured;
  }

  private hash(phone: string, code: string): string {
    return createHmac('sha256', process.env.JWT_ACCESS_SECRET ?? '').update(`${phone}:${code}`).digest('hex');
  }

  async issue(phone: string, purpose: OtpPurpose, locale: 'en' | 'so' = 'en'): Promise<{ expiresInSeconds: number }> {
    const recent = await this.prisma.otpCode.findFirst({
      where: { phone, purpose, createdAt: { gt: new Date(Date.now() - RESEND_COOLDOWN_SECONDS * 1000) } },
    });
    if (recent) {
      throw new HttpException(`Please wait ${RESEND_COOLDOWN_SECONDS} seconds before requesting another code`, HttpStatus.TOO_MANY_REQUESTS);
    }

    const ttlMinutes = Number(process.env.OTP_TTL_MINUTES ?? 5);
    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');

    await this.prisma.$transaction([
      // Invalidate older unconsumed codes for the same purpose
      this.prisma.otpCode.updateMany({ where: { phone, purpose, consumedAt: null }, data: { consumedAt: new Date() } }),
      this.prisma.otpCode.create({
        data: { phone, purpose, codeHash: this.hash(phone, code), expiresAt: new Date(Date.now() + ttlMinutes * 60_000) },
      }),
    ]);

    await this.sms.send(phone, interpolate(OTP_SMS[locale], { code, minutes: ttlMinutes }));
    return { expiresInSeconds: ttlMinutes * 60 };
  }

  /** Verifies and consumes a code. Throws a 400 on any failure. */
  async verify(phone: string, purpose: OtpPurpose, code: string): Promise<void> {
    const maxAttempts = Number(process.env.OTP_MAX_ATTEMPTS ?? 5);
    const otp = await this.prisma.otpCode.findFirst({
      where: { phone, purpose, consumedAt: null },
      orderBy: { createdAt: 'desc' },
    });

    if (!otp || otp.expiresAt < new Date()) throw new BadRequestException('This code has expired. Request a new one.');
    if (otp.attempts >= maxAttempts) throw new BadRequestException('Too many attempts. Request a new code.');

    const expected = Buffer.from(otp.codeHash, 'hex');
    const actual = Buffer.from(this.hash(phone, code), 'hex');
    const match = expected.length === actual.length && timingSafeEqual(expected, actual);

    if (!match) {
      await this.prisma.otpCode.update({ where: { id: otp.id }, data: { attempts: { increment: 1 } } });
      throw new BadRequestException('Incorrect code. Please try again.');
    }
    await this.prisma.otpCode.update({ where: { id: otp.id }, data: { consumedAt: new Date() } });
  }
}
