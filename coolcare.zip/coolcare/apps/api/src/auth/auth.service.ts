import { BadRequestException, ConflictException, ForbiddenException, Injectable, UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import type { User } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { isValidPhone, normalizePhone } from '../common/phone';
import { STAFF_ROLES } from '../common/types';
import { toPublicUser } from '../users/user.mapper';
import { ChangePasswordDto, LoginDto, RegisterDto, ResetPasswordDto } from './dto';
import { OtpService } from './otp.service';
import { TokensService } from './tokens.service';

type Meta = { userAgent?: string; ip?: string };
const BCRYPT_ROUNDS = 12;

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly otp: OtpService,
    private readonly tokens: TokensService,
  ) {}

  private phoneOrThrow(raw: string): string {
    const phone = normalizePhone(raw);
    if (!isValidPhone(phone)) throw new BadRequestException('Enter a valid phone number, e.g. +252 61 234 5678');
    return phone;
  }

  private async session(user: User, meta: Meta) {
    await this.prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    return { user: toPublicUser(user), tokens: await this.tokens.issue(user, meta) };
  }

  async register(dto: RegisterDto, meta: Meta) {
    const phone = this.phoneOrThrow(dto.phone);
    const email = dto.email?.trim().toLowerCase() || null;

    const existing = await this.prisma.user.findFirst({
      where: { OR: [{ phone }, ...(email ? [{ email }] : [])] },
    });
    if (existing) {
      // Allow an unverified registration to be retried with fresh details
      if (existing.phone === phone && !existing.phoneVerifiedAt && existing.role === 'CUSTOMER' && this.otp.enabled) {
        await this.prisma.user.update({
          where: { id: existing.id },
          data: { fullName: dto.fullName.trim(), email, passwordHash: await bcrypt.hash(dto.password, BCRYPT_ROUNDS), locale: dto.locale ?? existing.locale },
        });
        await this.otp.issue(phone, 'VERIFY_PHONE', dto.locale ?? existing.locale).catch(() => undefined);
        return { requiresOtp: true as const, phone };
      }
      throw new ConflictException(existing.phone === phone ? 'This phone number is already registered' : 'This email is already registered');
    }

    const user = await this.prisma.user.create({
      data: {
        fullName: dto.fullName.trim(),
        phone,
        email,
        passwordHash: await bcrypt.hash(dto.password, BCRYPT_ROUNDS),
        locale: dto.locale ?? 'en',
        role: 'CUSTOMER',
        phoneVerifiedAt: this.otp.enabled ? null : new Date(),
      },
    });

    if (this.otp.enabled) {
      await this.otp.issue(phone, 'VERIFY_PHONE', user.locale);
      return { requiresOtp: true as const, phone };
    }
    return { requiresOtp: false as const, ...(await this.session(user, meta)) };
  }

  async verifyPhone(rawPhone: string, code: string, meta: Meta) {
    const phone = this.phoneOrThrow(rawPhone);
    const user = await this.prisma.user.findUnique({ where: { phone } });
    if (!user) throw new BadRequestException('No account found for this phone number');
    await this.otp.verify(phone, 'VERIFY_PHONE', code);
    const verified = await this.prisma.user.update({ where: { id: user.id }, data: { phoneVerifiedAt: new Date() } });
    return this.session(verified, meta);
  }

  async requestOtp(rawPhone: string, purpose: 'VERIFY_PHONE' | 'RESET_PASSWORD') {
    const phone = this.phoneOrThrow(rawPhone);
    if (!this.otp.enabled) throw new BadRequestException('SMS verification is not available');
    const user = await this.prisma.user.findUnique({ where: { phone } });
    // Do not reveal whether the account exists for password resets
    if (!user) return { sent: true };
    if (purpose === 'VERIFY_PHONE' && user.phoneVerifiedAt) return { sent: false, alreadyVerified: true };
    const result = await this.otp.issue(phone, purpose, user.locale);
    return { sent: true, ...result };
  }

  private async checkCredentials(dto: LoginDto): Promise<User> {
    const identifier = dto.identifier.trim();
    const where = identifier.includes('@') ? { email: identifier.toLowerCase() } : { phone: normalizePhone(identifier) };
    const user = await this.prisma.user.findUnique({ where });
    const ok = user?.passwordHash ? await bcrypt.compare(dto.password, user.passwordHash) : false;
    if (!user || !ok || user.deletedAt) throw new UnauthorizedException('Incorrect phone/email or password');
    if (user.status !== 'ACTIVE') throw new ForbiddenException('Your account has been suspended. Please contact support.');
    return user;
  }

  async login(dto: LoginDto, meta: Meta) {
    const user = await this.checkCredentials(dto);
    if (user.role === 'CUSTOMER' && !user.phoneVerifiedAt && this.otp.enabled) {
      await this.otp.issue(user.phone, 'VERIFY_PHONE', user.locale).catch(() => undefined);
      return { requiresOtp: true as const, phone: user.phone };
    }
    return { requiresOtp: false as const, ...(await this.session(user, meta)) };
  }

  async adminLogin(dto: LoginDto, meta: Meta) {
    const user = await this.checkCredentials(dto);
    if (!STAFF_ROLES.includes(user.role)) throw new ForbiddenException('This account does not have dashboard access');
    return this.session(user, meta);
  }

  async refresh(refreshToken: string, meta: Meta) {
    const { tokens, user } = await this.tokens.rotate(refreshToken, meta);
    return { user: toPublicUser(user), tokens };
  }

  async logout(refreshToken: string) {
    await this.tokens.revoke(refreshToken);
    return { ok: true };
  }

  async forgotPassword(rawPhone: string) {
    return this.requestOtp(rawPhone, 'RESET_PASSWORD').catch((err) => {
      if (err instanceof BadRequestException) throw err;
      return { sent: true };
    });
  }

  async resetPassword(dto: ResetPasswordDto) {
    const phone = this.phoneOrThrow(dto.phone);
    const user = await this.prisma.user.findUnique({ where: { phone } });
    if (!user) throw new BadRequestException('Incorrect code. Please try again.');
    await this.otp.verify(phone, 'RESET_PASSWORD', dto.code);
    await this.prisma.user.update({
      where: { id: user.id },
      data: { passwordHash: await bcrypt.hash(dto.newPassword, BCRYPT_ROUNDS), phoneVerifiedAt: user.phoneVerifiedAt ?? new Date() },
    });
    await this.tokens.revokeAll(user.id);
    return { ok: true };
  }

  async changePassword(userId: string, dto: ChangePasswordDto) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    const ok = user.passwordHash ? await bcrypt.compare(dto.currentPassword, user.passwordHash) : false;
    if (!ok) throw new BadRequestException('Current password is incorrect');
    await this.prisma.user.update({ where: { id: userId }, data: { passwordHash: await bcrypt.hash(dto.newPassword, BCRYPT_ROUNDS) } });
    await this.tokens.revokeAll(userId);
    return { ok: true };
  }

  config() {
    return { otpEnabled: this.otp.enabled };
  }
}
