import { Global, Injectable, Logger, Module } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AuditService {
  private readonly logger = new Logger('Audit');
  constructor(private readonly prisma: PrismaService) {}

  /** Records an administrative action. Failures are logged, never thrown. */
  async log(actorId: string | null, action: string, entity: string, entityId?: string, meta?: Record<string, unknown>) {
    try {
      await this.prisma.auditLog.create({
        data: { actorId, action, entity, entityId, meta: meta as Prisma.InputJsonValue | undefined },
      });
    } catch (err) {
      this.logger.error(`audit log failed: ${(err as Error).message}`);
    }
  }
}

@Global()
@Module({ providers: [AuditService], exports: [AuditService] })
export class AuditModule {}
