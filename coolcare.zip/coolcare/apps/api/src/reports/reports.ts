import { Controller, Get, Injectable, Module, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiPropertyOptional, ApiTags } from '@nestjs/swagger';
import { IsDateString, IsOptional } from 'class-validator';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { SettingsService } from '../settings/settings';
import { Roles } from '../common/decorators';
import { paginate, PaginationQueryDto, skipTake } from '../common/pagination';
import { addDays, dateOnly, zonedParts } from '../common/time';
import { ACTIVE_STATUSES } from '../bookings/booking-status';

export class RangeQueryDto {
  @ApiPropertyOptional({ example: '2026-10-01' }) @IsOptional() @IsDateString() from?: string;
  @ApiPropertyOptional({ example: '2026-10-31' }) @IsOptional() @IsDateString() to?: string;
}

@Injectable()
export class ReportsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly settings: SettingsService,
  ) {}

  async overview(q: RangeQueryDto) {
    const s = await this.settings.get();
    const todayStr = zonedParts(s.timezone).date;
    const today = dateOnly(todayStr);
    const toStr = q.to?.slice(0, 10) ?? todayStr;
    const fromStr = q.from?.slice(0, 10) ?? addDays(dateOnly(toStr), -29).toISOString().slice(0, 10);
    // Range boundaries as instants in the company timezone
    const fromInstant = new Date(`${fromStr}T00:00:00${offsetFor(s.timezone)}`);
    const toInstant = new Date(`${toStr}T23:59:59.999${offsetFor(s.timezone)}`);
    const period = { gte: fromInstant, lte: toInstant };

    const [
      bookingsToday,
      pending,
      active,
      unassigned,
      completed,
      createdInPeriod,
      revenue,
      outstanding,
      rating,
      customers,
      newCustomers,
      techniciansAvailable,
      pendingPayments,
      quotesAwaiting,
    ] = await this.prisma.$transaction([
      this.prisma.booking.count({ where: { scheduledDate: today, status: { not: 'CANCELLED' } } }),
      this.prisma.booking.count({ where: { status: 'PENDING' } }),
      this.prisma.booking.count({ where: { status: { in: ACTIVE_STATUSES } } }),
      this.prisma.booking.count({ where: { technicianId: null, status: { in: ['PENDING', 'CONFIRMED'] } } }),
      this.prisma.booking.count({ where: { status: 'COMPLETED', completedAt: period } }),
      this.prisma.booking.count({ where: { createdAt: period } }),
      this.prisma.payment.aggregate({ where: { status: 'COMPLETED', paidAt: period }, _sum: { amount: true } }),
      this.prisma.invoice.aggregate({ where: { status: { in: ['UNPAID', 'PARTIALLY_PAID'] } }, _sum: { total: true, amountPaid: true } }),
      this.prisma.booking.aggregate({ where: { rating: { not: null }, ratedAt: period }, _avg: { rating: true }, _count: { rating: true } }),
      this.prisma.user.count({ where: { role: 'CUSTOMER', deletedAt: null } }),
      this.prisma.user.count({ where: { role: 'CUSTOMER', deletedAt: null, createdAt: period } }),
      this.prisma.technician.count({ where: { status: 'ACTIVE', isAvailable: true, deletedAt: null } }),
      this.prisma.payment.count({ where: { status: 'PENDING' } }),
      this.prisma.quote.count({ where: { status: 'SENT' } }),
    ]);

    const [byStatus, topServicesRaw] = await Promise.all([
      this.prisma.booking.groupBy({ by: ['status'], where: { createdAt: period }, _count: { _all: true } }),
      this.prisma.booking.groupBy({
        by: ['serviceId'],
        where: { createdAt: period, status: { not: 'CANCELLED' } },
        _count: { serviceId: true },
        orderBy: { _count: { serviceId: 'desc' } },
        take: 5,
      }),
    ]);

    const services = await this.prisma.service.findMany({
      where: { id: { in: topServicesRaw.map((t) => t.serviceId) } },
      select: { id: true, nameEn: true, nameSo: true },
    });
    const serviceMap = new Map<string, { id: string; nameEn: string; nameSo: string }>(services.map((sv) => [sv.id, sv]));

    const tz = s.timezone;
    const revenueByDay = await this.prisma.$queryRaw<{ day: Date; total: Prisma.Decimal }[]>`
      SELECT date_trunc('day', "paidAt" AT TIME ZONE 'UTC' AT TIME ZONE ${tz}) AS day, SUM(amount) AS total
      FROM "Payment"
      WHERE status = 'COMPLETED' AND "paidAt" BETWEEN ${fromInstant} AND ${toInstant}
      GROUP BY 1 ORDER BY 1`;
    const bookingsByDay = await this.prisma.$queryRaw<{ day: Date; count: bigint }[]>`
      SELECT date_trunc('day', "createdAt" AT TIME ZONE 'UTC' AT TIME ZONE ${tz}) AS day, COUNT(*) AS count
      FROM "Booking"
      WHERE "createdAt" BETWEEN ${fromInstant} AND ${toInstant}
      GROUP BY 1 ORDER BY 1`;

    // Fill every day in range so charts have no gaps
    const days: { date: string; revenue: number; bookings: number }[] = [];
    const revMap = new Map<string, number>(revenueByDay.map((r) => [toDay(r.day), Number(r.total)]));
    const bkMap = new Map<string, number>(bookingsByDay.map((r) => [toDay(r.day), Number(r.count)]));
    for (let d = dateOnly(fromStr); d <= dateOnly(toStr); d = addDays(d, 1)) {
      const key = d.toISOString().slice(0, 10);
      days.push({ date: key, revenue: revMap.get(key) ?? 0, bookings: bkMap.get(key) ?? 0 });
    }

    const todaysSchedule = await this.prisma.booking.findMany({
      where: { scheduledDate: today, status: { not: 'CANCELLED' } },
      orderBy: [{ timeSlot: 'asc' }, { priority: 'desc' }],
      include: {
        service: { select: { nameEn: true, nameSo: true } },
        technician: { select: { id: true, fullName: true } },
        customer: { select: { fullName: true, phone: true } },
      },
      take: 50,
    });

    const technicianPerformance = await this.prisma.$queryRaw<
      { id: string; fullName: string; completed: bigint; avgRating: number | null }[]
    >`
      SELECT t.id, t."fullName", COUNT(b.id) AS completed, AVG(b.rating)::float AS "avgRating"
      FROM "Technician" t
      LEFT JOIN "Booking" b ON b."technicianId" = t.id AND b.status = 'COMPLETED' AND b."completedAt" BETWEEN ${fromInstant} AND ${toInstant}
      WHERE t."deletedAt" IS NULL
      GROUP BY t.id, t."fullName"
      ORDER BY completed DESC
      LIMIT 10`;

    return {
      range: { from: fromStr, to: toStr, timezone: tz, currency: s.currency },
      kpis: {
        bookingsToday,
        pending,
        active,
        unassigned,
        completed,
        createdInPeriod,
        revenue: Number(revenue._sum.amount ?? 0),
        outstanding: Number(outstanding._sum.total ?? 0) - Number(outstanding._sum.amountPaid ?? 0),
        averageRating: rating._avg.rating ? Number(rating._avg.rating.toFixed(2)) : null,
        ratingsCount: rating._count.rating,
        customers,
        newCustomers,
        techniciansAvailable,
        pendingPayments,
        quotesAwaiting,
      },
      byStatus: byStatus.map((b) => ({ status: b.status, count: b._count._all })),
      topServices: topServicesRaw.map((t) => ({
        serviceId: t.serviceId,
        nameEn: serviceMap.get(t.serviceId)?.nameEn ?? '—',
        nameSo: serviceMap.get(t.serviceId)?.nameSo ?? '—',
        count: t._count.serviceId,
      })),
      daily: days,
      todaysSchedule,
      technicianPerformance: technicianPerformance.map((t) => ({
        id: t.id,
        fullName: t.fullName,
        completed: Number(t.completed),
        avgRating: t.avgRating ? Number(t.avgRating.toFixed(2)) : null,
      })),
    };
  }

  async auditLogs(q: PaginationQueryDto) {
    const where: Prisma.AuditLogWhereInput = q.search
      ? { OR: [{ action: { contains: q.search, mode: 'insensitive' } }, { entity: { contains: q.search, mode: 'insensitive' } }, { entityId: q.search }] }
      : {};
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        ...skipTake(q),
        include: { actor: { select: { fullName: true, role: true } } },
      }),
      this.prisma.auditLog.count({ where }),
    ]);
    return paginate(rows, total, q);
  }
}

function toDay(d: Date): string {
  // date_trunc on a timestamp without time zone returns a wall-clock date; Prisma reads it as UTC
  return new Date(d).toISOString().slice(0, 10);
}

/** Returns the current UTC offset (e.g. "+03:00") for a timezone. */
export function offsetFor(timeZone: string, at = new Date()): string {
  const name = new Intl.DateTimeFormat('en-US', { timeZone, timeZoneName: 'longOffset' })
    .formatToParts(at)
    .find((p) => p.type === 'timeZoneName')?.value;
  const match = name?.match(/GMT([+-]\d{2}):?(\d{2})?/);
  if (!match) return 'Z';
  return `${match[1]}:${match[2] ?? '00'}`;
}

@ApiTags('Admin · Reports')
@ApiBearerAuth()
@Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
@Controller('admin/reports')
export class ReportsController {
  constructor(private readonly reports: ReportsService) {}

  @Get('overview')
  overview(@Query() q: RangeQueryDto) {
    return this.reports.overview(q);
  }

  @Get('audit-logs')
  @Roles('ADMIN')
  audit(@Query() q: PaginationQueryDto) {
    return this.reports.auditLogs(q);
  }
}

@Module({ controllers: [ReportsController], providers: [ReportsService] })
export class ReportsModule {}
