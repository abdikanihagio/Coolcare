import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  IsArray,
  IsDateString,
  IsEnum,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  IsUrl,
  IsUUID,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { BookingPriority, BookingStatus, PhotoKind, TimeSlot } from '@prisma/client';
import { PaginationQueryDto } from '../common/pagination';

export class PhotoRefDto {
  @ApiProperty() @IsUrl({ require_tld: false }) url: string;
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(300) key: string;
}

export class CreateBookingDto {
  @ApiProperty() @IsUUID() serviceId: string;
  @ApiProperty() @IsUUID() addressId: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() equipmentId?: string;
  @ApiProperty({ example: '2026-10-25', description: 'Local date (YYYY-MM-DD)' }) @IsDateString({ strict: true }) scheduledDate: string;
  @ApiProperty({ enum: TimeSlot }) @IsEnum(TimeSlot) timeSlot: TimeSlot;
  @ApiPropertyOptional({ enum: BookingPriority }) @IsOptional() @IsEnum(BookingPriority) priority?: BookingPriority;
  @ApiPropertyOptional({ default: 1 }) @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) unitCount?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(2000) problemDescription?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(1000) customerNotes?: string;
  @ApiPropertyOptional({ type: [PhotoRefDto] })
  @IsOptional() @IsArray() @ArrayMaxSize(6) @ValidateNested({ each: true }) @Type(() => PhotoRefDto)
  photos?: PhotoRefDto[];
}

export class AdminCreateBookingDto {
  @ApiProperty() @IsUUID() customerId: string;
  @ApiProperty() @IsUUID() serviceId: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() addressId?: string;
  @ApiPropertyOptional({ description: 'Required when addressId is not provided' }) @IsOptional() @IsString() @MaxLength(300) addressText?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() equipmentId?: string;
  @ApiProperty() @IsDateString({ strict: true }) scheduledDate: string;
  @ApiProperty({ enum: TimeSlot }) @IsEnum(TimeSlot) timeSlot: TimeSlot;
  @ApiPropertyOptional({ enum: BookingPriority }) @IsOptional() @IsEnum(BookingPriority) priority?: BookingPriority;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) unitCount?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(2000) problemDescription?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(2000) internalNotes?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() technicianId?: string;
}

export class RescheduleDto {
  @ApiProperty() @IsDateString({ strict: true }) scheduledDate: string;
  @ApiProperty({ enum: TimeSlot }) @IsEnum(TimeSlot) timeSlot: TimeSlot;
}

export class CancelBookingDto {
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) reason?: string;
}

export class RateBookingDto {
  @ApiProperty({ minimum: 1, maximum: 5 }) @Type(() => Number) @IsInt() @Min(1) @Max(5) rating: number;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(1000) review?: string;
}

export class AddPhotoDto extends PhotoRefDto {
  @ApiPropertyOptional({ enum: PhotoKind }) @IsOptional() @IsEnum(PhotoKind) kind?: PhotoKind;
}

export class BookingQueryDto extends PaginationQueryDto {
  @ApiPropertyOptional({ enum: BookingStatus, isArray: true, description: 'Comma-separated list allowed' })
  @IsOptional()
  @Type(() => String)
  status?: string;
  @ApiPropertyOptional({ enum: ['active', 'past'] }) @IsOptional() @IsIn(['active', 'past']) scope?: 'active' | 'past';
  @ApiPropertyOptional() @IsOptional() @IsUUID() technicianId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() serviceId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() customerId?: string;
  @ApiPropertyOptional({ enum: BookingPriority }) @IsOptional() @IsEnum(BookingPriority) priority?: BookingPriority;
  @ApiPropertyOptional() @IsOptional() @IsDateString() dateFrom?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() dateTo?: string;
  @ApiPropertyOptional({ description: 'Only bookings without a technician' }) @IsOptional() @IsIn(['true', 'false']) unassigned?: string;
}

export class AssignTechnicianDto {
  @ApiProperty() @IsUUID() technicianId: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) note?: string;
}

export class UpdateStatusDto {
  @ApiProperty({ enum: BookingStatus }) @IsEnum(BookingStatus) status: BookingStatus;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) note?: string;
}

export class AdminUpdateBookingDto {
  @ApiPropertyOptional() @IsOptional() @IsDateString({ strict: true }) scheduledDate?: string;
  @ApiPropertyOptional({ enum: TimeSlot }) @IsOptional() @IsEnum(TimeSlot) timeSlot?: TimeSlot;
  @ApiPropertyOptional({ enum: BookingPriority }) @IsOptional() @IsEnum(BookingPriority) priority?: BookingPriority;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(2000) internalNotes?: string;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) estimatedPrice?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) unitCount?: number;
}
