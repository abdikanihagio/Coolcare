/**
 * Booking lifecycle — single source of truth for allowed status transitions.
 *
 *   PENDING ─► CONFIRMED ─► ASSIGNED ─► ON_THE_WAY ─► IN_PROGRESS ─► COMPLETED
 *                                                     │      ▲
 *                                                     ▼      │ (quote accepted)
 *                                               AWAITING_APPROVAL
 *   Any non-terminal state before IN_PROGRESS can move to CANCELLED.
 */
export type BookingStatusValue =
  | 'PENDING'
  | 'CONFIRMED'
  | 'ASSIGNED'
  | 'ON_THE_WAY'
  | 'IN_PROGRESS'
  | 'AWAITING_APPROVAL'
  | 'COMPLETED'
  | 'CANCELLED';

export const BOOKING_TRANSITIONS: Record<BookingStatusValue, BookingStatusValue[]> = {
  PENDING: ['CONFIRMED', 'ASSIGNED', 'CANCELLED'],
  CONFIRMED: ['ASSIGNED', 'CANCELLED'],
  ASSIGNED: ['ON_THE_WAY', 'IN_PROGRESS', 'CONFIRMED', 'CANCELLED'],
  ON_THE_WAY: ['IN_PROGRESS', 'ASSIGNED', 'CANCELLED'],
  IN_PROGRESS: ['AWAITING_APPROVAL', 'COMPLETED'],
  AWAITING_APPROVAL: ['IN_PROGRESS', 'COMPLETED', 'CANCELLED'],
  COMPLETED: [],
  CANCELLED: [],
};

export const TERMINAL_STATUSES: BookingStatusValue[] = ['COMPLETED', 'CANCELLED'];

/** States in which the customer may still cancel from the app. */
export const CUSTOMER_CANCELLABLE: BookingStatusValue[] = ['PENDING', 'CONFIRMED', 'ASSIGNED'];

/** States in which a technician can be (re)assigned. */
export const ASSIGNABLE: BookingStatusValue[] = ['PENDING', 'CONFIRMED', 'ASSIGNED', 'ON_THE_WAY'];

/** States counted as "active" work for dashboards and technician workload. */
export const ACTIVE_STATUSES: BookingStatusValue[] = ['CONFIRMED', 'ASSIGNED', 'ON_THE_WAY', 'IN_PROGRESS', 'AWAITING_APPROVAL'];

export function canTransition(from: BookingStatusValue, to: BookingStatusValue): boolean {
  return BOOKING_TRANSITIONS[from]?.includes(to) ?? false;
}

export function assertTransition(from: BookingStatusValue, to: BookingStatusValue): void {
  if (!canTransition(from, to)) {
    throw new InvalidTransitionError(from, to);
  }
}

export class InvalidTransitionError extends Error {
  constructor(
    public readonly from: BookingStatusValue,
    public readonly to: BookingStatusValue,
  ) {
    super(`A booking cannot move from ${from} to ${to}`);
  }
}

/** Formats a human-readable booking reference, e.g. CC-2026-000123. */
export function formatReference(prefix: string, year: number, sequence: number, width = 6): string {
  return `${prefix}-${year}-${String(sequence).padStart(width, '0')}`;
}
