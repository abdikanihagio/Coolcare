import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiQuery, ApiTags } from '@nestjs/swagger';
import { CurrentUser, Roles } from '../common/decorators';
import type { AuthUser } from '../common/types';
import { StorageService } from '../storage/storage';
import { BookingsService } from './bookings.service';
import {
  AddPhotoDto,
  AdminCreateBookingDto,
  AdminUpdateBookingDto,
  AssignTechnicianDto,
  BookingQueryDto,
  CancelBookingDto,
  CreateBookingDto,
  RateBookingDto,
  RescheduleDto,
  UpdateStatusDto,
} from './dto';

@ApiTags('Bookings (customer)')
@ApiBearerAuth()
@Roles('CUSTOMER')
@Controller('bookings')
export class BookingsController {
  constructor(private readonly bookings: BookingsService) {}

  @Get('availability')
  @ApiQuery({ name: 'date', example: '2026-10-25' })
  availability(@Query('date') date: string) {
    return this.bookings.availability(date);
  }

  @Post()
  create(@CurrentUser() u: AuthUser, @Body() dto: CreateBookingDto) {
    return this.bookings.create(u.id, dto);
  }

  @Get()
  list(@CurrentUser() u: AuthUser, @Query() q: BookingQueryDto) {
    return this.bookings.listMine(u.id, q);
  }

  @Get(':id')
  detail(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.bookings.customerDetail(u.id, id);
  }

  @Post(':id/cancel')
  cancel(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: CancelBookingDto) {
    return this.bookings.cancelByCustomer(u.id, id, dto.reason);
  }

  @Post(':id/reschedule')
  reschedule(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: RescheduleDto) {
    return this.bookings.rescheduleByCustomer(u.id, id, dto);
  }

  @Post(':id/rate')
  rate(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: RateBookingDto) {
    return this.bookings.rate(u.id, id, dto);
  }

  @Post(':id/photos')
  addPhoto(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: AddPhotoDto) {
    return this.bookings.addCustomerPhoto(u.id, id, dto);
  }
}

@ApiTags('Admin · Bookings')
@ApiBearerAuth()
@Roles('ADMIN', 'DISPATCHER')
@Controller('admin/bookings')
export class AdminBookingsController {
  constructor(
    private readonly bookings: BookingsService,
    private readonly storage: StorageService,
  ) {}

  @Get()
  @Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
  list(@Query() q: BookingQueryDto) {
    return this.bookings.adminList(q);
  }

  @Get('availability')
  availability(@Query('date') date: string) {
    return this.bookings.availability(date);
  }

  @Get(':id')
  @Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
  detail(@Param('id', ParseUUIDPipe) id: string) {
    return this.bookings.adminDetail(id);
  }

  @Post()
  create(@CurrentUser() u: AuthUser, @Body() dto: AdminCreateBookingDto) {
    return this.bookings.adminCreate(u.id, dto);
  }

  @Patch(':id')
  update(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: AdminUpdateBookingDto) {
    return this.bookings.adminUpdate(u.id, id, dto);
  }

  @Post(':id/assign')
  assign(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: AssignTechnicianDto) {
    return this.bookings.assign(u.id, id, dto.technicianId, dto.note);
  }

  @Post(':id/status')
  status(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateStatusDto) {
    return this.bookings.adminSetStatus(u.id, id, dto.status, dto.note);
  }

  @Post(':id/photos')
  addPhoto(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: AddPhotoDto) {
    return this.bookings.addStaffPhoto(u.id, id, dto);
  }

  @Delete(':id/photos/:photoId')
  async removePhoto(
    @CurrentUser() u: AuthUser,
    @Param('id', ParseUUIDPipe) id: string,
    @Param('photoId', ParseUUIDPipe) photoId: string,
  ) {
    const result = await this.bookings.removePhoto(u.id, id, photoId);
    await this.storage.remove(result.storageKey);
    return { ok: true };
  }
}
