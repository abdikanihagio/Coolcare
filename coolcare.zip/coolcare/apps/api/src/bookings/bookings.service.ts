import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { BookingStatus, Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { NotificationsService } from '../notifications/notifications.service';
import { NotificationType } from '../notifications/templates';
import { SettingsService } from '../settings/settings';
import { BillingService } from '../billing/billing';
import { orderBy, paginate, skipTake } from '../common/pagination';
import { dateOnly, hoursUntilSlot, isValidIsoDate, Slot } from '../common/time';
import {
  ACTIVE_STATUSES,
  ASSIGNABLE,
  BookingStatusValue,
  canTransition,
  CUSTOMER_CANCELLABLE,
  formatReference,
  TERMINAL_STATUSES,
} from './booking-status';
import {
  AddPhotoDto,
  AdminCreateBookingDto,
  AdminUpdateBookingDto,
  BookingQueryDto,
  CreateBookingDto,
  RateBookingDto,
  RescheduleDto,
} from './dto';

const customerDetailInclude = {
  service: { include: { category: { select: { nameEn: true, nameSo: true, icon: true } } } },
  address: true,
  equipment: true,
  technician: { select: { id: true, fullName: true, phone: true, photoUrl: true, rating: true } },
  history: { orderBy: { createdAt: 'asc' }, select: { id: true, fromStatus: true, toStatus: true, note: true, createdAt: true } },
  photos: { orderBy: { createdAt: 'asc' } },
  quotes: { where: { status: { not: 'DRAFT' } }, orderBy: { createdAt: 'desc' }, include: { items: { orderBy: { sortOrder: 'asc' } } } },
  invoice: { include: { payments: { orderBy: { paidAt: 'desc' } } } },
} satisfies Prisma.BookingInclude;

const adminDetailInclude = {
  ...customerDetailInclude,
  customer: { select: { id: true, fullName: true, phone: true, email: true, locale: true } },
  technician: true,
  branch: true,
  history: { orderBy: { createdAt: 'asc' }, include: { changedBy: { select: { fullName: true, role: true } } } },
  quotes: { orderBy: { createdAt: 'desc' }, include: { items: { orderBy: { sortOrder: 'asc' } }, createdBy: { select: { fullName: true } } } },
} satisfies Prisma.BookingInclude;

const listInclude = {
  service: { select: { id: true, nameEn: true, nameSo: true } },
  technician: { select: { id: true, fullName: true, phone: true } },
  customer: { select: { id: true, fullName: true, phone: true } },
} satisfies Prisma.BookingInclude;

/** Customer notification sent when a booking enters a status. */
const STATUS_NOTIFICATION: Partial<Record<BookingStatusValue, NotificationType>> = {
  CONFIRMED: 'BOOKING_CONFIRMED',
  ASSIGNED: 'TECHNICIAN_ASSIGNED',
  ON_THE_WAY: 'TECHNICIAN_ON_THE_WAY',
  IN_PROGRESS: 'WORK_STARTED',
  COMPLETED: 'JOB_COMPLETED',
  CANCELLED: 'BOOKING_CANCELLED',
};

export function formatAddress(a: { label: string; district: string; neighborhood?: string | null; street?: string | null; landmark?: string | null }) {
  return [a.street, a.neighborhood, a.district, a.landmark ? `(${a.landmark})` : null].filter(Boolean).join(', ');
}

@Injectable()
export class BookingsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationsService,
    private readonly settings: SettingsService,
    private readonly billing: BillingService,
  ) {}

  // ───────────── Shared helpers ─────────────

  private async validateSchedule(date: string, slot: Slot, opts: { enforceLead: boolean; excludeId?: string }) {
    if (!isValidIsoDate(date)) throw new BadRequestException('Choose a valid date');
    const s = await this.settings.get();
    const hours = hoursUntilSlot(date, slot, s.timezone);
    if (hours < (opts.enforceLead ? s.bookingLeadHours : -4)) {
      throw new BadRequestException(
        opts.enforceLead
          ? `Please choose a time at least ${s.bookingLeadHours} hour(s) from now`
          : 'This time slot has already passed',
      );
    }
    if (hours > 24 * 90) throw new BadRequestException('Bookings can be made up to 90 days ahead');

    const taken = await this.prisma.booking.count({
      where: { scheduledDate: dateOnly(date), timeSlot: slot, status: { not: 'CANCELLED' }, id: opts.excludeId ? { not: opts.excludeId } : undefined },
    });
    if (taken >= s.maxBookingsPerSlot) throw new BadRequestException('This time slot is fully booked. Please choose another.');
  }

  private async nextReference() {
    const year = new Date().getFullYear();
    return formatReference('CC', year, await this.prisma.nextSequence(`booking-${year}`));
  }

  private async estimate(serviceBasePrice: number, units: number, priority: string) {
    const s = await this.settings.get();
    const surcharge = priority === 'EMERGENCY' ? s.emergencySurcharge : 0;
    return (serviceBasePrice * units + surcharge).toFixed(2);
  }

  /** Availability per slot for a date — used by the app to grey out full slots. */
  async availability(date: string) {
    if (!isValidIsoDate(date)) throw new BadRequestException('Invalid date');
    const s = await this.settings.get();
    const counts = await this.prisma.booking.groupBy({
      by: ['timeSlot'],
      where: { scheduledDate: dateOnly(date), status: { not: 'CANCELLED' } },
      _count: { _all: true },
    });
    const bySlot = new Map<string, number>(counts.map((c) => [c.timeSlot, c._count._all]));
    return (['MORNING', 'AFTERNOON', 'EVENING'] as Slot[]).map((slot) => ({
      slot,
      available: (bySlot.get(slot) ?? 0) < s.maxBookingsPerSlot && hoursUntilSlot(date, slot, s.timezone) >= s.bookingLeadHours,
    }));
  }

  // ───────────── Customer ─────────────

  async create(customerId: string, dto: CreateBookingDto) {
    const [service, address, equipment] = await Promise.all([
      this.prisma.service.findFirst({ where: { id: dto.serviceId, isActive: true } }),
      this.prisma.address.findFirst({ where: { id: dto.addressId, userId: customerId, deletedAt: null } }),
      dto.equipmentId ? this.prisma.equipment.findFirst({ where: { id: dto.equipmentId, userId: customerId, deletedAt: null } }) : null,
    ]);
    if (!service) throw new BadRequestException('This service is not available');
    if (!address) throw new BadRequestException('Choose a saved address');
    if (dto.equipmentId && !equipment) throw new BadRequestException('Equipment not found');

    await this.validateSchedule(dto.scheduledDate, dto.timeSlot, { enforceLead: true });
    const priority = dto.priority ?? 'NORMAL';
    const units = dto.unitCount ?? 1;

    const booking = await this.prisma.booking.create({
      data: {
        reference: await this.nextReference(),
        customerId,
        serviceId: service.id,
        addressId: address.id,
        equipmentId: equipment?.id,
        scheduledDate: dateOnly(dto.scheduledDate),
        timeSlot: dto.timeSlot,
        priority,
        unitCount: units,
        problemDescription: dto.problemDescription,
        customerNotes: dto.customerNotes,
        addressText: formatAddress(address),
        latitude: address.latitude,
        longitude: address.longitude,
        estimatedPrice: service.priceType === 'INSPECTION_REQUIRED' ? null : await this.estimate(Number(service.basePrice), units, priority),
        history: { create: { toStatus: 'PENDING', changedById: customerId, note: 'Booked via mobile app' } },
        photos: dto.photos?.length
          ? { create: dto.photos.map((p) => ({ url: p.url, storageKey: p.key, kind: 'PROBLEM' as const, uploadedById: customerId })) }
          : undefined,
      },
      include: { customer: { select: { fullName: true } } },
    });

    await this.notifications.notify(customerId, 'BOOKING_CREATED', { ref: booking.reference }, { bookingId: booking.id });
    await this.notifications.notifyStaff(
      'NEW_BOOKING',
      { ref: booking.reference, customer: booking.customer.fullName, service: service.nameEn, date: dto.scheduledDate },
      { bookingId: booking.id },
    );
    return this.customerDetail(customerId, booking.id);
  }

  async listMine(customerId: string, q: BookingQueryDto) {
    const where: Prisma.BookingWhereInput = {
      customerId,
      ...(q.scope === 'active' ? { status: { notIn: TERMINAL_STATUSES } } : {}),
      ...(q.scope === 'past' ? { status: { in: TERMINAL_STATUSES } } : {}),
    };
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.booking.findMany({
        where,
        orderBy: q.scope === 'active' ? [{ scheduledDate: 'asc' }, { createdAt: 'desc' }] : { createdAt: 'desc' },
        ...skipTake(q),
        include: {
          service: { select: { id: true, nameEn: true, nameSo: true, category: { select: { icon: true } } } },
          technician: { select: { fullName: true } },
          quotes: { where: { status: 'SENT' }, select: { id: true } },
        },
      }),
      this.prisma.booking.count({ where }),
    ]);
    return paginate(
      rows.map(({ quotes, internalNotes: _internal, ...b }) => ({ ...b, hasPendingQuote: quotes.length > 0 })),
      total,
      q,
    );
  }

  async customerDetail(customerId: string, id: string) {
    const booking = await this.prisma.booking.findFirst({ where: { id, customerId }, include: customerDetailInclude });
    if (!booking) throw new NotFoundException('Booking not found');
    const { internalNotes: _internal, ...rest } = booking;
    return rest;
  }

  async cancelByCustomer(customerId: string, id: string, reason?: string) {
    const s = await this.settings.get();
    if (!s.allowCustomerCancellation) throw new ForbiddenException('Please contact support to cancel this booking');
    const booking = await this.prisma.booking.findFirst({ where: { id, customerId }, include: { customer: { select: { fullName: true } } } });
    if (!booking) throw new NotFoundException('Booking not found');
    if (!CUSTOMER_CANCELLABLE.includes(booking.status)) {
      throw new BadRequestException('This booking can no longer be cancelled from the app. Please contact support.');
    }
    await this.applyStatus(booking.id, booking.status, 'CANCELLED', customerId, reason ?? 'Cancelled by customer', {
      cancelledReason: reason ?? 'Cancelled by customer',
    });
    await this.notifications.notifyStaff(
      'BOOKING_CANCELLED_BY_CUSTOMER',
      { ref: booking.reference, customer: booking.customer.fullName, reason: reason ?? '—' },
      { bookingId: booking.id },
    );
    return this.customerDetail(customerId, id);
  }

  async rescheduleByCustomer(customerId: string, id: string, dto: RescheduleDto) {
    const booking = await this.prisma.booking.findFirst({ where: { id, customerId } });
    if (!booking) throw new NotFoundException('Booking not found');
    if (!['PENDING', 'CONFIRMED'].includes(booking.status)) {
      throw new BadRequestException('This booking can no longer be rescheduled from the app. Please contact support.');
    }
    await this.validateSchedule(dto.scheduledDate, dto.timeSlot, { enforceLead: true, excludeId: id });
    await this.prisma.booking.update({
      where: { id },
      data: {
        scheduledDate: dateOnly(dto.scheduledDate),
        timeSlot: dto.timeSlot,
        history: {
          create: { fromStatus: booking.status, toStatus: booking.status, changedById: customerId, note: `Rescheduled to ${dto.scheduledDate} ${dto.timeSlot}` },
        },
      },
    });
    return this.customerDetail(customerId, id);
  }

  async rate(customerId: string, id: string, dto: RateBookingDto) {
    const booking = await this.prisma.booking.findFirst({ where: { id, customerId } });
    if (!booking) throw new NotFoundException('Booking not found');
    if (booking.status !== 'COMPLETED') throw new BadRequestException('You can rate a booking once it is completed');
    if (booking.rating) throw new BadRequestException('You have already rated this booking');

    await this.prisma.$transaction(async (tx) => {
      await tx.booking.update({ where: { id }, data: { rating: dto.rating, review: dto.review, ratedAt: new Date() } });
      if (booking.technicianId) {
        const agg = await tx.booking.aggregate({
          where: { technicianId: booking.technicianId, rating: { not: null } },
          _avg: { rating: true },
        });
        await tx.technician.update({
          where: { id: booking.technicianId },
          data: { rating: (agg._avg.rating ?? 0).toFixed(2) },
        });
      }
    });
    return this.customerDetail(customerId, id);
  }

  async addCustomerPhoto(customerId: string, id: string, dto: AddPhotoDto) {
    const booking = await this.prisma.booking.findFirst({ where: { id, customerId } });
    if (!booking) throw new NotFoundException('Booking not found');
    if (TERMINAL_STATUSES.includes(booking.status)) throw new BadRequestException('This booking is closed');
    const count = await this.prisma.bookingPhoto.count({ where: { bookingId: id } });
    if (count >= 12) throw new BadRequestException('Photo limit reached for this booking');
    return this.prisma.bookingPhoto.create({
      data: { bookingId: id, url: dto.url, storageKey: dto.key, kind: 'PROBLEM', uploadedById: customerId },
    });
  }

  // ───────────── Admin ─────────────

  async adminList(q: BookingQueryDto) {
    const statuses = q.status
      ?.split(',')
      .map((s) => s.trim())
      .filter((s): s is BookingStatus => Object.values(BookingStatus).includes(s as BookingStatus));
    const search = q.search?.trim();
    const where: Prisma.BookingWhereInput = {
      ...(statuses?.length ? { status: { in: statuses } } : {}),
      ...(q.scope === 'active' ? { status: { in: ['PENDING', ...ACTIVE_STATUSES] } } : {}),
      technicianId: q.unassigned === 'true' ? null : q.technicianId,
      serviceId: q.serviceId,
      customerId: q.customerId,
      priority: q.priority,
      scheduledDate:
        q.dateFrom || q.dateTo
          ? { gte: q.dateFrom ? dateOnly(q.dateFrom.slice(0, 10)) : undefined, lte: q.dateTo ? dateOnly(q.dateTo.slice(0, 10)) : undefined }
          : undefined,
      ...(search
        ? {
            OR: [
              { reference: { contains: search, mode: 'insensitive' } },
              { customer: { fullName: { contains: search, mode: 'insensitive' } } },
              { customer: { phone: { contains: search.replace(/\s/g, '') } } },
              { addressText: { contains: search, mode: 'insensitive' } },
            ],
          }
        : {}),
    };
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.booking.findMany({
        where,
        orderBy: orderBy(q.sortBy, q.sortOrder, ['createdAt', 'scheduledDate', 'status', 'priority', 'reference']),
        ...skipTake(q),
        include: listInclude,
      }),
      this.prisma.booking.count({ where }),
    ]);
    return paginate(rows, total, q);
  }

  async adminDetail(id: string) {
    const booking = await this.prisma.booking.findUnique({ where: { id }, include: adminDetailInclude });
    if (!booking) throw new NotFoundException('Booking not found');
    return { ...booking, allowedTransitions: (['PENDING', 'CONFIRMED', 'ASSIGNED', 'ON_THE_WAY', 'IN_PROGRESS', 'AWAITING_APPROVAL', 'COMPLETED', 'CANCELLED'] as BookingStatusValue[]).filter((s) => canTransition(booking.status, s)) };
  }

  async adminCreate(actorId: string, dto: AdminCreateBookingDto) {
    const customer = await this.prisma.user.findFirst({ where: { id: dto.customerId, role: 'CUSTOMER', deletedAt: null } });
    if (!customer) throw new BadRequestException('Customer not found');
    const service = await this.prisma.service.findUnique({ where: { id: dto.serviceId } });
    if (!service) throw new BadRequestException('Service not found');
    const address = dto.addressId
      ? await this.prisma.address.findFirst({ where: { id: dto.addressId, userId: customer.id, deletedAt: null } })
      : null;
    if (dto.addressId && !address) throw new BadRequestException('Address does not belong to this customer');
    if (!address && !dto.addressText?.trim()) throw new BadRequestException('Provide a saved address or an address description');

    await this.validateSchedule(dto.scheduledDate, dto.timeSlot, { enforceLead: false });
    const priority = dto.priority ?? 'NORMAL';
    const units = dto.unitCount ?? 1;

    const booking = await this.prisma.booking.create({
      data: {
        reference: await this.nextReference(),
        customerId: customer.id,
        serviceId: service.id,
        addressId: address?.id,
        equipmentId: dto.equipmentId,
        scheduledDate: dateOnly(dto.scheduledDate),
        timeSlot: dto.timeSlot,
        priority,
        unitCount: units,
        problemDescription: dto.problemDescription,
        internalNotes: dto.internalNotes,
        addressText: address ? formatAddress(address) : dto.addressText!.trim(),
        latitude: address?.latitude,
        longitude: address?.longitude,
        estimatedPrice: service.priceType === 'INSPECTION_REQUIRED' ? null : await this.estimate(Number(service.basePrice), units, priority),
        status: 'CONFIRMED',
        history: {
          create: [
            { toStatus: 'PENDING', changedById: actorId, note: 'Created by staff' },
            { fromStatus: 'PENDING', toStatus: 'CONFIRMED', changedById: actorId },
          ],
        },
      },
    });
    await this.audit.log(actorId, 'booking.create', 'Booking', booking.id);
    await this.notifications.notify(customer.id, 'BOOKING_CONFIRMED', { ref: booking.reference, date: dto.scheduledDate }, { bookingId: booking.id });
    if (dto.technicianId) await this.assign(actorId, booking.id, dto.technicianId);
    return this.adminDetail(booking.id);
  }

  async adminUpdate(actorId: string, id: string, dto: AdminUpdateBookingDto) {
    const booking = await this.prisma.booking.findUnique({ where: { id } });
    if (!booking) throw new NotFoundException('Booking not found');
    if (TERMINAL_STATUSES.includes(booking.status) && (dto.scheduledDate || dto.timeSlot)) {
      throw new BadRequestException('A closed booking cannot be rescheduled');
    }
    const date = dto.scheduledDate ?? booking.scheduledDate.toISOString().slice(0, 10);
    const slot = (dto.timeSlot ?? booking.timeSlot) as Slot;
    const rescheduled = !!dto.scheduledDate || !!dto.timeSlot;
    if (rescheduled) await this.validateSchedule(date, slot, { enforceLead: false, excludeId: id });

    await this.prisma.booking.update({
      where: { id },
      data: {
        scheduledDate: dto.scheduledDate ? dateOnly(dto.scheduledDate) : undefined,
        timeSlot: dto.timeSlot,
        priority: dto.priority,
        internalNotes: dto.internalNotes,
        estimatedPrice: dto.estimatedPrice?.toFixed(2),
        unitCount: dto.unitCount,
        ...(rescheduled
          ? { history: { create: { fromStatus: booking.status, toStatus: booking.status, changedById: actorId, note: `Rescheduled to ${date} ${slot}` } } }
          : {}),
      },
    });
    await this.audit.log(actorId, 'booking.update', 'Booking', id, dto as Record<string, unknown>);
    if (rescheduled) {
      await this.notifications.notify(booking.customerId, 'BOOKING_CONFIRMED', { ref: booking.reference, date }, { bookingId: id });
    }
    return this.adminDetail(id);
  }

  async assign(actorId: string, id: string, technicianId: string, note?: string) {
    const [booking, tech] = await Promise.all([
      this.prisma.booking.findUnique({ where: { id } }),
      this.prisma.technician.findFirst({ where: { id: technicianId, deletedAt: null } }),
    ]);
    if (!booking) throw new NotFoundException('Booking not found');
    if (!tech) throw new BadRequestException('Technician not found');
    if (tech.status !== 'ACTIVE') throw new BadRequestException(`${tech.fullName} is not active`);
    if (!ASSIGNABLE.includes(booking.status)) throw new BadRequestException(`A ${booking.status.toLowerCase()} booking cannot be reassigned`);

    const reassign = booking.technicianId && booking.technicianId !== technicianId;
    await this.prisma.booking.update({
      where: { id },
      data: {
        technicianId,
        status: 'ASSIGNED',
        history: {
          create: {
            fromStatus: booking.status,
            toStatus: 'ASSIGNED',
            changedById: actorId,
            note: note ?? (reassign ? `Reassigned to ${tech.fullName}` : `Assigned to ${tech.fullName}`),
          },
        },
      },
    });
    await this.audit.log(actorId, 'booking.assign', 'Booking', id, { technicianId });
    await this.notifications.notify(booking.customerId, 'TECHNICIAN_ASSIGNED', { ref: booking.reference, tech: tech.fullName }, { bookingId: id });
    return this.adminDetail(id);
  }

  async adminSetStatus(actorId: string, id: string, to: BookingStatus, note?: string) {
    const booking = await this.prisma.booking.findUnique({ where: { id } });
    if (!booking) throw new NotFoundException('Booking not found');
    if (to === 'ASSIGNED' && !booking.technicianId) throw new BadRequestException('Assign a technician first');
    if (['ON_THE_WAY', 'IN_PROGRESS'].includes(to) && !booking.technicianId) throw new BadRequestException('Assign a technician first');
    await this.applyStatus(id, booking.status, to, actorId, note, to === 'CANCELLED' ? { cancelledReason: note ?? 'Cancelled by staff' } : {});
    await this.audit.log(actorId, 'booking.status', 'Booking', id, { from: booking.status, to });

    if (to === 'COMPLETED') {
      // Issue the invoice automatically; staff can still edit/void it later
      await this.billing.ensureInvoiceForBooking(id, actorId).catch(() => undefined);
    }
    return this.adminDetail(id);
  }

  /**
   * Validates and applies a status change with history and notifications.
   * Used by admin actions, customer cancellation and quote responses.
   */
  async applyStatus(
    id: string,
    from: BookingStatus,
    to: BookingStatus,
    actorId: string | null,
    note?: string,
    extra: Prisma.BookingUpdateInput = {},
  ) {
    if (from === to) return;
    if (!canTransition(from, to)) throw new BadRequestException(`A booking cannot move from ${from} to ${to}`);

    const booking = await this.prisma.$transaction(async (tx) => {
      // Optimistic concurrency: only update if status has not changed meanwhile
      const result = await tx.booking.updateMany({ where: { id, status: from }, data: { status: to } });
      if (result.count === 0) throw new BadRequestException('This booking was just updated by someone else. Refresh and try again.');
      const updated = await tx.booking.update({
        where: { id },
        data: {
          ...extra,
          completedAt: to === 'COMPLETED' ? new Date() : undefined,
          history: { create: { fromStatus: from, toStatus: to, note, changedById: actorId } },
        },
        include: { technician: { select: { id: true, fullName: true } } },
      });
      if (to === 'COMPLETED' && updated.technicianId) {
        await tx.technician.update({ where: { id: updated.technicianId }, data: { jobsCompleted: { increment: 1 } } });
      }
      return updated;
    });

    const type = STATUS_NOTIFICATION[to];
    if (type && !(to === 'CANCELLED' && actorId === booking.customerId)) {
      await this.notifications.notify(
        booking.customerId,
        type,
        { ref: booking.reference, tech: booking.technician?.fullName ?? '', date: booking.scheduledDate.toISOString().slice(0, 10) },
        { bookingId: id },
      );
    }
  }

  async addStaffPhoto(actorId: string, id: string, dto: AddPhotoDto) {
    const booking = await this.prisma.booking.findUnique({ where: { id } });
    if (!booking) throw new NotFoundException('Booking not found');
    return this.prisma.bookingPhoto.create({
      data: { bookingId: id, url: dto.url, storageKey: dto.key, kind: dto.kind ?? 'BEFORE', uploadedById: actorId },
    });
  }

  async removePhoto(actorId: string, bookingId: string, photoId: string) {
    const photo = await this.prisma.bookingPhoto.findFirst({ where: { id: photoId, bookingId } });
    if (!photo) throw new NotFoundException('Photo not found');
    await this.prisma.bookingPhoto.delete({ where: { id: photoId } });
    await this.audit.log(actorId, 'booking.photo.delete', 'Booking', bookingId, { photoId });
    return { ok: true, storageKey: photo.storageKey };
  }
}
