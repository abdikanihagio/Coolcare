import {
  ASSIGNABLE,
  BOOKING_TRANSITIONS,
  BookingStatusValue,
  canTransition,
  assertTransition,
  CUSTOMER_CANCELLABLE,
  formatReference,
  InvalidTransitionError,
  TERMINAL_STATUSES,
} from './booking-status';

describe('booking status machine', () => {
  it('follows the happy path from PENDING to COMPLETED', () => {
    const path: BookingStatusValue[] = ['PENDING', 'CONFIRMED', 'ASSIGNED', 'ON_THE_WAY', 'IN_PROGRESS', 'COMPLETED'];
    for (let i = 0; i < path.length - 1; i++) {
      expect(canTransition(path[i], path[i + 1])).toBe(true);
    }
  });

  it('supports the quote approval loop', () => {
    expect(canTransition('IN_PROGRESS', 'AWAITING_APPROVAL')).toBe(true);
    expect(canTransition('AWAITING_APPROVAL', 'IN_PROGRESS')).toBe(true);
    expect(canTransition('AWAITING_APPROVAL', 'COMPLETED')).toBe(true);
  });

  it('never leaves a terminal state', () => {
    for (const terminal of TERMINAL_STATUSES) {
      expect(BOOKING_TRANSITIONS[terminal]).toEqual([]);
    }
  });

  it('does not allow cancelling work that is in progress', () => {
    expect(canTransition('IN_PROGRESS', 'CANCELLED')).toBe(false);
  });

  it('does not allow skipping straight to COMPLETED', () => {
    expect(canTransition('PENDING', 'COMPLETED')).toBe(false);
    expect(canTransition('CONFIRMED', 'COMPLETED')).toBe(false);
  });

  it('throws a descriptive error on invalid transitions', () => {
    expect(() => assertTransition('COMPLETED', 'PENDING')).toThrow(InvalidTransitionError);
    expect(() => assertTransition('COMPLETED', 'PENDING')).toThrow('cannot move from COMPLETED to PENDING');
  });

  it('only lets customers cancel before the technician leaves', () => {
    expect(CUSTOMER_CANCELLABLE).toEqual(['PENDING', 'CONFIRMED', 'ASSIGNED']);
    for (const s of CUSTOMER_CANCELLABLE) expect(canTransition(s, 'CANCELLED')).toBe(true);
  });

  it('allows (re)assignment only before work starts', () => {
    expect(ASSIGNABLE).not.toContain('IN_PROGRESS');
    for (const s of ASSIGNABLE) {
      expect(s === 'ASSIGNED' || canTransition(s, 'ASSIGNED')).toBe(true);
    }
  });

  it('formats references with zero padding', () => {
    expect(formatReference('CC', 2026, 42)).toBe('CC-2026-000042');
    expect(formatReference('INV', 2026, 7, 5)).toBe('INV-2026-00007');
  });
});
