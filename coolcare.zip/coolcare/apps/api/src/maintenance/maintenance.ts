import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Injectable,
  Logger,
  Module,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { ApiBearerAuth, ApiProperty, ApiPropertyOptional, ApiTags, PartialType } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsBoolean, IsDateString, IsEnum, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, IsUUID, Max, MaxLength, Min } from 'class-validator';
import { Prisma, SubscriptionStatus, TimeSlot } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { NotificationsService } from '../notifications/notifications.service';
import { SettingsService } from '../settings/settings';
import { BookingsModule } from '../bookings/bookings.module';
import { BookingsService } from '../bookings/bookings.service';
import { CurrentUser, Public, Roles } from '../common/decorators';
import { orderBy, paginate, PaginationQueryDto, skipTake } from '../common/pagination';
import { addDays, addMonths, dateOnly, zonedParts } from '../common/time';
import type { AuthUser } from '../common/types';

// ── DTOs ──

export class PlanDto {
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(80) nameEn: string;
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(80) nameSo: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(1000) descriptionEn?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(1000) descriptionSo?: string;
  @ApiProperty() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) price: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(36) durationMonths?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(24) visitsPerYear?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100) maxUnits?: number;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() isActive?: boolean;
}
export class UpdatePlanDto extends PartialType(PlanDto) {}

export class SubscribeDto {
  @ApiProperty() @IsUUID() planId: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() addressId?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) notes?: string;
}

export class SubscriptionQueryDto extends PaginationQueryDto {
  @ApiPropertyOptional({ enum: SubscriptionStatus }) @IsOptional() @IsEnum(SubscriptionStatus) status?: SubscriptionStatus;
}

export class UpdateSubscriptionDto {
  @ApiPropertyOptional({ enum: SubscriptionStatus }) @IsOptional() @IsEnum(SubscriptionStatus) status?: SubscriptionStatus;
  @ApiPropertyOptional() @IsOptional() @IsDateString() startDate?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() nextVisitDate?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) notes?: string;
}

export class ScheduleVisitDto {
  @ApiProperty() @IsUUID() serviceId: string;
  @ApiProperty() @IsDateString({ strict: true }) scheduledDate: string;
  @ApiProperty({ enum: TimeSlot }) @IsEnum(TimeSlot) timeSlot: TimeSlot;
  @ApiPropertyOptional() @IsOptional() @IsUUID() technicianId?: string;
}

// ── Service ──

@Injectable()
export class MaintenanceService {
  private readonly logger = new Logger('Maintenance');

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationsService,
    private readonly settings: SettingsService,
    private readonly bookings: BookingsService,
  ) {}

  plans(includeInactive = false) {
    return this.prisma.maintenancePlan.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: { price: 'asc' },
      include: includeInactive ? { _count: { select: { subscriptions: { where: { status: 'ACTIVE' } } } } } : undefined,
    });
  }

  async createPlan(actorId: string, dto: PlanDto) {
    const s = await this.settings.get();
    const plan = await this.prisma.maintenancePlan.create({ data: { ...dto, price: dto.price.toFixed(2), currency: s.currency } });
    await this.audit.log(actorId, 'plan.create', 'MaintenancePlan', plan.id);
    return plan;
  }

  async updatePlan(actorId: string, id: string, dto: UpdatePlanDto) {
    const plan = await this.prisma.maintenancePlan.update({
      where: { id },
      data: { ...dto, price: dto.price !== undefined ? dto.price.toFixed(2) : undefined },
    });
    await this.audit.log(actorId, 'plan.update', 'MaintenancePlan', id);
    return plan;
  }

  async deletePlan(actorId: string, id: string) {
    const used = await this.prisma.maintenanceSubscription.count({ where: { planId: id } });
    if (used) {
      await this.prisma.maintenancePlan.update({ where: { id }, data: { isActive: false } });
    } else {
      await this.prisma.maintenancePlan.delete({ where: { id } });
    }
    await this.audit.log(actorId, used ? 'plan.deactivate' : 'plan.delete', 'MaintenancePlan', id);
    return { ok: true, deactivated: used > 0 };
  }

  /** Customer requests a plan. Staff activate it once payment is collected. */
  async subscribe(customerId: string, dto: SubscribeDto) {
    const plan = await this.prisma.maintenancePlan.findFirst({ where: { id: dto.planId, isActive: true } });
    if (!plan) throw new BadRequestException('This plan is not available');
    if (dto.addressId) {
      const owned = await this.prisma.address.count({ where: { id: dto.addressId, userId: customerId, deletedAt: null } });
      if (!owned) throw new BadRequestException('Address not found');
    }
    const existing = await this.prisma.maintenanceSubscription.count({
      where: { customerId, planId: plan.id, status: { in: ['PENDING', 'ACTIVE'] } },
    });
    if (existing) throw new BadRequestException('You already have this plan');

    const start = dateOnly(zonedParts((await this.settings.get()).timezone).date);
    const sub = await this.prisma.maintenanceSubscription.create({
      data: {
        planId: plan.id,
        customerId,
        addressId: dto.addressId,
        notes: dto.notes,
        status: 'PENDING',
        startDate: start,
        endDate: addMonths(start, plan.durationMonths),
      },
      include: { plan: true },
    });
    const customer = await this.prisma.user.findUnique({ where: { id: customerId }, select: { fullName: true } });
    await this.notifications.notifyStaff(
      'GENERAL',
      { title: 'New maintenance plan request', body: `${customer?.fullName ?? 'A customer'} requested the ${plan.nameEn} plan.` },
      { subscriptionId: sub.id },
    );
    return sub;
  }

  mySubscriptions(customerId: string) {
    return this.prisma.maintenanceSubscription.findMany({
      where: { customerId },
      orderBy: { createdAt: 'desc' },
      include: { plan: true, address: true },
    });
  }

  async cancelMine(customerId: string, id: string) {
    const sub = await this.prisma.maintenanceSubscription.findFirst({ where: { id, customerId } });
    if (!sub) throw new NotFoundException('Subscription not found');
    if (sub.status !== 'PENDING') throw new BadRequestException('Please contact support to cancel an active plan');
    return this.prisma.maintenanceSubscription.update({ where: { id }, data: { status: 'CANCELLED' } });
  }

  async list(q: SubscriptionQueryDto) {
    const where: Prisma.MaintenanceSubscriptionWhereInput = {
      status: q.status,
      ...(q.search
        ? {
            OR: [
              { customer: { fullName: { contains: q.search, mode: 'insensitive' } } },
              { customer: { phone: { contains: q.search.replace(/\s/g, '') } } },
            ],
          }
        : {}),
    };
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.maintenanceSubscription.findMany({
        where,
        orderBy: orderBy(q.sortBy, q.sortOrder, ['createdAt', 'nextVisitDate', 'endDate']),
        ...skipTake(q),
        include: { plan: true, customer: { select: { id: true, fullName: true, phone: true } }, address: true },
      }),
      this.prisma.maintenanceSubscription.count({ where }),
    ]);
    return paginate(rows, total, q);
  }

  async update(actorId: string, id: string, dto: UpdateSubscriptionDto) {
    const sub = await this.prisma.maintenanceSubscription.findUnique({ where: { id }, include: { plan: true } });
    if (!sub) throw new NotFoundException('Subscription not found');

    const data: Prisma.MaintenanceSubscriptionUpdateInput = { status: dto.status, notes: dto.notes };
    if (dto.startDate) {
      const start = dateOnly(dto.startDate.slice(0, 10));
      data.startDate = start;
      data.endDate = addMonths(start, sub.plan.durationMonths);
    }
    if (dto.nextVisitDate) data.nextVisitDate = dateOnly(dto.nextVisitDate.slice(0, 10));
    if (dto.status === 'ACTIVE' && sub.status === 'PENDING' && !dto.nextVisitDate) {
      // First visit one week after activation by default
      data.nextVisitDate = addDays(dateOnly(zonedParts((await this.settings.get()).timezone).date), 7);
    }
    const updated = await this.prisma.maintenanceSubscription.update({ where: { id }, data, include: { plan: true } });
    await this.audit.log(actorId, 'subscription.update', 'MaintenanceSubscription', id, dto as Record<string, unknown>);
    return updated;
  }

  /** Creates a booking for the next maintenance visit and advances the schedule. */
  async scheduleVisit(actorId: string, id: string, dto: ScheduleVisitDto) {
    const sub = await this.prisma.maintenanceSubscription.findUnique({ where: { id }, include: { plan: true } });
    if (!sub) throw new NotFoundException('Subscription not found');
    if (sub.status !== 'ACTIVE') throw new BadRequestException('Only active plans can have visits scheduled');
    const maxVisits = Math.ceil((sub.plan.visitsPerYear * sub.plan.durationMonths) / 12);
    if (sub.visitsUsed >= maxVisits) throw new BadRequestException('All visits on this plan have been used');

    const booking = await this.bookings.adminCreate(actorId, {
      customerId: sub.customerId,
      serviceId: dto.serviceId,
      addressId: sub.addressId ?? undefined,
      addressText: sub.addressId ? undefined : 'See customer profile',
      scheduledDate: dto.scheduledDate,
      timeSlot: dto.timeSlot,
      technicianId: dto.technicianId,
      internalNotes: `Maintenance plan visit ${sub.visitsUsed + 1}/${maxVisits} — ${sub.plan.nameEn}`,
    });
    // Plan visits are prepaid: zero the estimate so the completion invoice is not double-billed
    await this.prisma.booking.update({ where: { id: booking.id }, data: { estimatedPrice: '0.00' } });

    const intervalMonths = Math.max(1, Math.round(12 / sub.plan.visitsPerYear));
    await this.prisma.maintenanceSubscription.update({
      where: { id },
      data: {
        visitsUsed: { increment: 1 },
        nextVisitDate: addMonths(dateOnly(dto.scheduledDate), intervalMonths),
        lastReminderAt: null,
      },
    });
    return booking;
  }

  /** Daily at 08:00 Mogadishu: remind customers of upcoming visits; expire finished plans. */
  @Cron('0 8 * * *', { timeZone: process.env.DEFAULT_TIMEZONE ?? 'Africa/Mogadishu' })
  async dailyMaintenanceJob() {
    const s = await this.settings.get();
    const today = dateOnly(zonedParts(s.timezone).date);

    const expired = await this.prisma.maintenanceSubscription.updateMany({
      where: { status: 'ACTIVE', endDate: { lt: today } },
      data: { status: 'EXPIRED' },
    });

    const due = await this.prisma.maintenanceSubscription.findMany({
      where: {
        status: 'ACTIVE',
        nextVisitDate: { gte: today, lte: addDays(today, s.maintenanceReminderDays) },
        lastReminderAt: null,
      },
      include: { plan: true, customer: { select: { locale: true } } },
    });
    for (const sub of due) {
      await this.notifications.notify(
        sub.customerId,
        'MAINTENANCE_DUE',
        { plan: sub.customer.locale === 'so' ? sub.plan.nameSo : sub.plan.nameEn, date: sub.nextVisitDate!.toISOString().slice(0, 10) },
        { subscriptionId: sub.id },
      );
      await this.prisma.maintenanceSubscription.update({ where: { id: sub.id }, data: { lastReminderAt: new Date() } });
    }
    this.logger.log(`Maintenance job: ${due.length} reminder(s), ${expired.count} plan(s) expired`);
    return { reminded: due.length, expired: expired.count };
  }
}

// ── Controllers ──

@ApiTags('Maintenance plans')
@Controller('maintenance')
export class MaintenanceController {
  constructor(private readonly maintenance: MaintenanceService) {}

  @Public()
  @Get('plans')
  plans() {
    return this.maintenance.plans();
  }

  @ApiBearerAuth()
  @Roles('CUSTOMER')
  @Get('subscriptions')
  mine(@CurrentUser() u: AuthUser) {
    return this.maintenance.mySubscriptions(u.id);
  }

  @ApiBearerAuth()
  @Roles('CUSTOMER')
  @Post('subscriptions')
  subscribe(@CurrentUser() u: AuthUser, @Body() dto: SubscribeDto) {
    return this.maintenance.subscribe(u.id, dto);
  }

  @ApiBearerAuth()
  @Roles('CUSTOMER')
  @Post('subscriptions/:id/cancel')
  cancel(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.maintenance.cancelMine(u.id, id);
  }
}

@ApiTags('Admin · Maintenance')
@ApiBearerAuth()
@Roles('ADMIN', 'DISPATCHER')
@Controller('admin/maintenance')
export class AdminMaintenanceController {
  constructor(private readonly maintenance: MaintenanceService) {}

  @Get('plans')
  plans() {
    return this.maintenance.plans(true);
  }

  @Post('plans')
  @Roles('ADMIN')
  createPlan(@CurrentUser() u: AuthUser, @Body() dto: PlanDto) {
    return this.maintenance.createPlan(u.id, dto);
  }

  @Patch('plans/:id')
  @Roles('ADMIN')
  updatePlan(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdatePlanDto) {
    return this.maintenance.updatePlan(u.id, id, dto);
  }

  @Delete('plans/:id')
  @Roles('ADMIN')
  deletePlan(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.maintenance.deletePlan(u.id, id);
  }

  @Get('subscriptions')
  subscriptions(@Query() q: SubscriptionQueryDto) {
    return this.maintenance.list(q);
  }

  @Patch('subscriptions/:id')
  updateSubscription(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateSubscriptionDto) {
    return this.maintenance.update(u.id, id, dto);
  }

  @Post('subscriptions/:id/visits')
  scheduleVisit(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: ScheduleVisitDto) {
    return this.maintenance.scheduleVisit(u.id, id, dto);
  }

  @Post('run-reminders')
  @Roles('ADMIN')
  runNow() {
    return this.maintenance.dailyMaintenanceJob();
  }
}

@Module({
  imports: [BookingsModule],
  controllers: [MaintenanceController, AdminMaintenanceController],
  providers: [MaintenanceService],
})
export class MaintenanceModule {}
