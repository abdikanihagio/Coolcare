import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Injectable,
  Module,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Post,
  Query,
} from '@nestjs/common';
import { ApiBearerAuth, ApiProperty, ApiPropertyOptional, ApiTags } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsDateString, IsEnum, IsIn, IsNumber, IsOptional, IsString, MaxLength, Min } from 'class-validator';
import { InvoiceStatus, PaymentMethod, PaymentStatus, Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { NotificationsService } from '../notifications/notifications.service';
import { SettingsService } from '../settings/settings';
import { CurrentUser, Roles } from '../common/decorators';
import { orderBy, paginate, PaginationQueryDto, skipTake } from '../common/pagination';
import type { AuthUser } from '../common/types';
import { formatReference } from '../bookings/booking-status';
import { computeQuoteTotals, formatMoney, invoiceStatusFor } from '../quotes/quote-math';
import { addDays } from '../common/time';

// ── DTOs ──

export class RecordPaymentDto {
  @ApiProperty({ example: 45 }) @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0.01) amount: number;
  @ApiProperty({ enum: PaymentMethod }) @IsEnum(PaymentMethod) method: PaymentMethod;
  @ApiPropertyOptional({ description: 'Mobile money / bank transaction ID' }) @IsOptional() @IsString() @MaxLength(100) reference?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(20) payerPhone?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) notes?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() paidAt?: string;
}

export class CustomerPaymentClaimDto {
  @ApiProperty() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0.01) amount: number;
  @ApiProperty({ enum: ['EVC_PLUS', 'ZAAD', 'SAHAL', 'EDAHAB', 'BANK_TRANSFER'] })
  @IsIn(['EVC_PLUS', 'ZAAD', 'SAHAL', 'EDAHAB', 'BANK_TRANSFER'])
  method: PaymentMethod;
  @ApiProperty({ description: 'Transaction ID from the mobile money SMS' }) @IsString() @MaxLength(100) reference: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(20) payerPhone?: string;
}

export class InvoiceQueryDto extends PaginationQueryDto {
  @ApiPropertyOptional({ enum: InvoiceStatus }) @IsOptional() @IsEnum(InvoiceStatus) status?: InvoiceStatus;
}

export class PaymentQueryDto extends PaginationQueryDto {
  @ApiPropertyOptional({ enum: PaymentMethod }) @IsOptional() @IsEnum(PaymentMethod) method?: PaymentMethod;
  @ApiPropertyOptional({ enum: PaymentStatus }) @IsOptional() @IsEnum(PaymentStatus) status?: PaymentStatus;
  @ApiPropertyOptional() @IsOptional() @IsDateString() from?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() to?: string;
}

const invoiceInclude = {
  payments: { orderBy: { paidAt: 'desc' } },
  booking: { select: { id: true, reference: true, service: { select: { nameEn: true, nameSo: true } }, unitCount: true } },
  customer: { select: { id: true, fullName: true, phone: true, email: true } },
  quote: { include: { items: { orderBy: { sortOrder: 'asc' } } } },
} satisfies Prisma.InvoiceInclude;

// ── Service ──

@Injectable()
export class BillingService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationsService,
    private readonly settings: SettingsService,
  ) {}

  /**
   * Creates (or refreshes a voided) invoice for a booking. Amount comes from the
   * accepted quote if one exists, otherwise from the booking estimate.
   */
  async ensureInvoiceForBooking(bookingId: string, actorId: string | null) {
    const booking = await this.prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        invoice: true,
        service: true,
        quotes: { where: { status: 'ACCEPTED' }, orderBy: { respondedAt: 'desc' }, take: 1 },
      },
    });
    if (!booking) throw new NotFoundException('Booking not found');
    if (booking.invoice && booking.invoice.status !== 'VOID') return booking.invoice;

    const settings = await this.settings.get();
    const quote = booking.quotes[0];
    let totals: { subtotal: string; discount: string; taxAmount: string; total: string };
    let currency = settings.currency;

    if (quote) {
      totals = {
        subtotal: quote.subtotal.toFixed(2),
        discount: quote.discount.toFixed(2),
        taxAmount: quote.taxAmount.toFixed(2),
        total: quote.total.toFixed(2),
      };
      currency = quote.currency;
    } else {
      const amount = Number(booking.estimatedPrice ?? Number(booking.service.basePrice) * booking.unitCount);
      if (amount <= 0) throw new BadRequestException('Set a price or send a quotation before invoicing this booking');
      totals = computeQuoteTotals([{ quantity: 1, unitPrice: amount }], 0, settings.taxRate);
    }

    const data = {
      customerId: booking.customerId,
      quoteId: quote?.id ?? null,
      currency,
      ...totals,
      amountPaid: '0.00',
      status: 'UNPAID' as const,
      issuedAt: new Date(),
      dueAt: addDays(new Date(), settings.invoiceDueDays),
    };

    const invoice = booking.invoice
      ? await this.prisma.invoice.update({ where: { id: booking.invoice.id }, data })
      : await this.prisma.invoice.create({
          data: {
            ...data,
            bookingId,
            number: formatReference('INV', new Date().getFullYear(), await this.prisma.nextSequence(`invoice-${new Date().getFullYear()}`), 5),
          },
        });

    await this.audit.log(actorId, 'invoice.issue', 'Invoice', invoice.id, { bookingId, total: totals.total });
    const user = await this.prisma.user.findUnique({ where: { id: booking.customerId }, select: { locale: true } });
    await this.notifications.notify(
      booking.customerId,
      'INVOICE_ISSUED',
      { number: invoice.number, amount: formatMoney(totals.total, currency, user?.locale), ref: booking.reference },
      { bookingId, invoiceId: invoice.id },
    );
    return invoice;
  }

  private async recalculate(tx: Prisma.TransactionClient, invoiceId: string) {
    const invoice = await tx.invoice.findUniqueOrThrow({ where: { id: invoiceId } });
    const sum = await tx.payment.aggregate({ where: { invoiceId, status: 'COMPLETED' }, _sum: { amount: true } });
    const paid = Number(sum._sum.amount ?? 0);
    return tx.invoice.update({
      where: { id: invoiceId },
      data: {
        amountPaid: paid.toFixed(2),
        status: invoice.status === 'VOID' ? 'VOID' : invoiceStatusFor(Number(invoice.total), paid),
      },
    });
  }

  async recordPayment(actorId: string, invoiceId: string, dto: RecordPaymentDto) {
    const invoice = await this.prisma.invoice.findUnique({ where: { id: invoiceId } });
    if (!invoice) throw new NotFoundException('Invoice not found');
    if (invoice.status === 'VOID') throw new BadRequestException('This invoice has been voided');
    const balance = Number(invoice.total) - Number(invoice.amountPaid);
    if (dto.amount - balance > 0.005) throw new BadRequestException(`Amount exceeds the outstanding balance of ${balance.toFixed(2)}`);

    const updated = await this.prisma.$transaction(async (tx) => {
      await tx.payment.create({
        data: {
          invoiceId,
          amount: dto.amount.toFixed(2),
          currency: invoice.currency,
          method: dto.method,
          reference: dto.reference,
          payerPhone: dto.payerPhone,
          notes: dto.notes,
          status: 'COMPLETED',
          receivedById: actorId,
          paidAt: dto.paidAt ? new Date(dto.paidAt) : new Date(),
        },
      });
      return this.recalculate(tx, invoiceId);
    });

    await this.audit.log(actorId, 'payment.record', 'Invoice', invoiceId, { amount: dto.amount, method: dto.method });
    const user = await this.prisma.user.findUnique({ where: { id: invoice.customerId }, select: { locale: true } });
    await this.notifications.notify(
      invoice.customerId,
      'PAYMENT_RECEIVED',
      { amount: formatMoney(dto.amount, invoice.currency, user?.locale) },
      { invoiceId, bookingId: invoice.bookingId },
    );
    return this.invoice(updated.id);
  }

  /** Customer reports a mobile-money payment; staff confirm it after checking the transaction. */
  async submitClaim(customerId: string, invoiceId: string, dto: CustomerPaymentClaimDto) {
    const invoice = await this.prisma.invoice.findFirst({ where: { id: invoiceId, customerId } });
    if (!invoice) throw new NotFoundException('Invoice not found');
    if (invoice.status === 'PAID' || invoice.status === 'VOID') throw new BadRequestException('This invoice does not need payment');
    const duplicate = await this.prisma.payment.count({ where: { reference: dto.reference, method: dto.method, status: { not: 'FAILED' } } });
    if (duplicate) throw new BadRequestException('This transaction ID has already been submitted');

    const payment = await this.prisma.payment.create({
      data: {
        invoiceId,
        amount: dto.amount.toFixed(2),
        currency: invoice.currency,
        method: dto.method,
        reference: dto.reference.trim(),
        payerPhone: dto.payerPhone,
        status: 'PENDING',
      },
    });
    return payment;
  }

  async confirmPayment(actorId: string, paymentId: string, approve: boolean) {
    const payment = await this.prisma.payment.findUnique({ where: { id: paymentId }, include: { invoice: true } });
    if (!payment) throw new NotFoundException('Payment not found');
    if (payment.status !== 'PENDING') throw new BadRequestException('Only pending payments can be confirmed or rejected');

    await this.prisma.$transaction(async (tx) => {
      await tx.payment.update({
        where: { id: paymentId },
        data: { status: approve ? 'COMPLETED' : 'FAILED', receivedById: actorId, paidAt: approve ? new Date() : payment.paidAt },
      });
      await this.recalculate(tx, payment.invoiceId);
    });
    await this.audit.log(actorId, approve ? 'payment.confirm' : 'payment.reject', 'Payment', paymentId);
    if (approve) {
      const user = await this.prisma.user.findUnique({ where: { id: payment.invoice.customerId }, select: { locale: true } });
      await this.notifications.notify(
        payment.invoice.customerId,
        'PAYMENT_RECEIVED',
        { amount: formatMoney(Number(payment.amount), payment.currency, user?.locale) },
        { invoiceId: payment.invoiceId, bookingId: payment.invoice.bookingId },
      );
    }
    return this.invoice(payment.invoiceId);
  }

  async refundPayment(actorId: string, paymentId: string) {
    const payment = await this.prisma.payment.findUnique({ where: { id: paymentId } });
    if (!payment) throw new NotFoundException('Payment not found');
    if (payment.status !== 'COMPLETED') throw new BadRequestException('Only completed payments can be refunded');
    await this.prisma.$transaction(async (tx) => {
      await tx.payment.update({ where: { id: paymentId }, data: { status: 'REFUNDED' } });
      await this.recalculate(tx, payment.invoiceId);
    });
    await this.audit.log(actorId, 'payment.refund', 'Payment', paymentId, { amount: Number(payment.amount) });
    return this.invoice(payment.invoiceId);
  }

  async voidInvoice(actorId: string, invoiceId: string) {
    const completed = await this.prisma.payment.count({ where: { invoiceId, status: 'COMPLETED' } });
    if (completed) throw new BadRequestException('Refund recorded payments before voiding this invoice');
    await this.prisma.invoice.update({ where: { id: invoiceId }, data: { status: 'VOID' } });
    await this.audit.log(actorId, 'invoice.void', 'Invoice', invoiceId);
    return this.invoice(invoiceId);
  }

  async invoice(id: string, customerId?: string) {
    const invoice = await this.prisma.invoice.findFirst({ where: { id, ...(customerId ? { customerId } : {}) }, include: invoiceInclude });
    if (!invoice) throw new NotFoundException('Invoice not found');
    return invoice;
  }

  async listInvoices(q: InvoiceQueryDto, customerId?: string) {
    const where: Prisma.InvoiceWhereInput = {
      customerId,
      status: q.status,
      ...(q.search
        ? {
            OR: [
              { number: { contains: q.search, mode: 'insensitive' } },
              { booking: { reference: { contains: q.search, mode: 'insensitive' } } },
              { customer: { fullName: { contains: q.search, mode: 'insensitive' } } },
              { customer: { phone: { contains: q.search.replace(/\s/g, '') } } },
            ],
          }
        : {}),
    };
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.invoice.findMany({
        where,
        orderBy: orderBy(q.sortBy, q.sortOrder, ['issuedAt', 'total', 'dueAt', 'number'], 'issuedAt'),
        ...skipTake(q),
        include: {
          customer: { select: { id: true, fullName: true, phone: true } },
          booking: { select: { id: true, reference: true } },
          _count: { select: { payments: { where: { status: 'PENDING' } } } },
        },
      }),
      this.prisma.invoice.count({ where }),
    ]);
    return paginate(rows, total, q);
  }

  async listPayments(q: PaymentQueryDto) {
    const where: Prisma.PaymentWhereInput = {
      method: q.method,
      status: q.status,
      paidAt: q.from || q.to ? { gte: q.from ? new Date(q.from) : undefined, lte: q.to ? new Date(`${q.to}T23:59:59.999Z`) : undefined } : undefined,
      ...(q.search
        ? {
            OR: [
              { reference: { contains: q.search, mode: 'insensitive' } },
              { invoice: { number: { contains: q.search, mode: 'insensitive' } } },
              { invoice: { customer: { fullName: { contains: q.search, mode: 'insensitive' } } } },
            ],
          }
        : {}),
    };
    const [rows, total, sum] = await this.prisma.$transaction([
      this.prisma.payment.findMany({
        where,
        orderBy: orderBy(q.sortBy, q.sortOrder, ['paidAt', 'amount', 'createdAt'], 'paidAt'),
        ...skipTake(q),
        include: {
          invoice: { select: { id: true, number: true, customer: { select: { fullName: true, phone: true } }, booking: { select: { reference: true } } } },
          receivedBy: { select: { fullName: true } },
        },
      }),
      this.prisma.payment.count({ where }),
      this.prisma.payment.aggregate({ where: { ...where, status: 'COMPLETED' }, _sum: { amount: true } }),
    ]);
    return { ...paginate(rows, total, q), totalCollected: sum._sum.amount ?? 0 };
  }
}

// ── Controllers ──

@ApiTags('Invoices (customer)')
@ApiBearerAuth()
@Controller('invoices')
export class InvoicesController {
  constructor(private readonly billing: BillingService) {}

  @Get()
  mine(@CurrentUser() u: AuthUser, @Query() q: InvoiceQueryDto) {
    return this.billing.listInvoices(q, u.id);
  }

  @Get(':id')
  one(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.billing.invoice(id, u.id);
  }

  @Post(':id/payments')
  claim(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: CustomerPaymentClaimDto) {
    return this.billing.submitClaim(u.id, id, dto);
  }
}

@ApiTags('Admin · Billing')
@ApiBearerAuth()
@Roles('ADMIN', 'ACCOUNTANT')
@Controller('admin')
export class AdminBillingController {
  constructor(private readonly billing: BillingService) {}

  @Get('invoices')
  @Roles('ADMIN', 'ACCOUNTANT', 'DISPATCHER')
  invoices(@Query() q: InvoiceQueryDto) {
    return this.billing.listInvoices(q);
  }

  @Get('invoices/:id')
  @Roles('ADMIN', 'ACCOUNTANT', 'DISPATCHER')
  invoice(@Param('id', ParseUUIDPipe) id: string) {
    return this.billing.invoice(id);
  }

  @Post('bookings/:bookingId/invoice')
  issue(@CurrentUser() u: AuthUser, @Param('bookingId', ParseUUIDPipe) bookingId: string) {
    return this.billing.ensureInvoiceForBooking(bookingId, u.id);
  }

  @Post('invoices/:id/payments')
  record(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: RecordPaymentDto) {
    return this.billing.recordPayment(u.id, id, dto);
  }

  @Post('invoices/:id/void')
  void(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.billing.voidInvoice(u.id, id);
  }

  @Get('payments')
  payments(@Query() q: PaymentQueryDto) {
    return this.billing.listPayments(q);
  }

  @Post('payments/:id/confirm')
  confirm(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.billing.confirmPayment(u.id, id, true);
  }

  @Post('payments/:id/reject')
  reject(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.billing.confirmPayment(u.id, id, false);
  }

  @Post('payments/:id/refund')
  refund(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.billing.refundPayment(u.id, id);
  }
}

@Module({
  controllers: [InvoicesController, AdminBillingController],
  providers: [BillingService],
  exports: [BillingService],
})
export class BillingModule {}
