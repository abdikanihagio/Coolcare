import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Injectable,
  Module,
  NotFoundException,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { ApiBearerAuth, ApiProperty, ApiPropertyOptional, ApiTags } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsBoolean,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { LineItemKind, Prisma, QuoteStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { NotificationsService } from '../notifications/notifications.service';
import { SettingsService } from '../settings/settings';
import { BookingsModule } from '../bookings/bookings.module';
import { BookingsService } from '../bookings/bookings.service';
import { formatReference, TERMINAL_STATUSES } from '../bookings/booking-status';
import { CurrentUser, Roles } from '../common/decorators';
import { orderBy, paginate, PaginationQueryDto, skipTake } from '../common/pagination';
import { addDays } from '../common/time';
import type { AuthUser } from '../common/types';
import { computeQuoteTotals, formatMoney } from './quote-math';

// ── DTOs ──

export class QuoteItemDto {
  @ApiPropertyOptional({ enum: LineItemKind }) @IsOptional() @IsEnum(LineItemKind) kind?: LineItemKind;
  @ApiProperty({ example: 'Compressor replacement' }) @IsString() @IsNotEmpty() @MaxLength(200) description: string;
  @ApiProperty({ example: 1 }) @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0.01) quantity: number;
  @ApiProperty({ example: 120 }) @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) unitPrice: number;
}

export class QuoteDto {
  @ApiProperty({ type: [QuoteItemDto] })
  @IsArray() @ArrayMinSize(1) @ArrayMaxSize(50) @ValidateNested({ each: true }) @Type(() => QuoteItemDto)
  items: QuoteItemDto[];
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) discount?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsNumber({ maxDecimalPlaces: 2 }) @Min(0) @Max(100) taxRate?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(2000) notes?: string;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(90) validDays?: number;
  @ApiPropertyOptional({ description: 'Send to the customer immediately' }) @IsOptional() @IsBoolean() send?: boolean;
}

export class RejectQuoteDto {
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) reason?: string;
}

export class QuoteQueryDto extends PaginationQueryDto {
  @ApiPropertyOptional({ enum: QuoteStatus }) @IsOptional() @IsEnum(QuoteStatus) status?: QuoteStatus;
}

// ── Service ──

@Injectable()
export class QuotesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationsService,
    private readonly settings: SettingsService,
    private readonly bookings: BookingsService,
  ) {}

  private async build(dto: QuoteDto) {
    const s = await this.settings.get();
    const taxRate = dto.taxRate ?? s.taxRate;
    let totals;
    try {
      totals = computeQuoteTotals(dto.items, dto.discount ?? 0, taxRate);
    } catch (err) {
      throw new BadRequestException((err as Error).message);
    }
    return {
      currency: s.currency,
      subtotal: totals.subtotal,
      discount: totals.discount,
      taxRate: taxRate.toFixed(2),
      taxAmount: totals.taxAmount,
      total: totals.total,
      notes: dto.notes,
      validUntil: addDays(new Date(), dto.validDays ?? s.quoteValidityDays),
      items: dto.items.map((item, i) => ({
        kind: item.kind ?? 'LABOR',
        description: item.description.trim(),
        quantity: item.quantity.toFixed(2),
        unitPrice: item.unitPrice.toFixed(2),
        total: totals.lines[i].total,
        sortOrder: i,
      })),
    };
  }

  async create(actorId: string, bookingId: string, dto: QuoteDto) {
    const booking = await this.prisma.booking.findUnique({ where: { id: bookingId } });
    if (!booking) throw new NotFoundException('Booking not found');
    if (TERMINAL_STATUSES.includes(booking.status)) throw new BadRequestException('Cannot quote a closed booking');

    const { items, ...data } = await this.build(dto);
    const year = new Date().getFullYear();
    const quote = await this.prisma.quote.create({
      data: {
        ...data,
        number: formatReference('Q', year, await this.prisma.nextSequence(`quote-${year}`), 5),
        bookingId,
        createdById: actorId,
        items: { create: items },
      },
    });
    await this.audit.log(actorId, 'quote.create', 'Quote', quote.id, { bookingId, total: data.total });
    if (dto.send) return this.send(actorId, quote.id);
    return this.detail(quote.id);
  }

  async update(actorId: string, id: string, dto: QuoteDto) {
    const quote = await this.prisma.quote.findUnique({ where: { id } });
    if (!quote) throw new NotFoundException('Quote not found');
    if (quote.status !== 'DRAFT') throw new BadRequestException('Only draft quotes can be edited. Create a new quote instead.');
    const { items, ...data } = await this.build(dto);
    await this.prisma.$transaction([
      this.prisma.quoteItem.deleteMany({ where: { quoteId: id } }),
      this.prisma.quote.update({ where: { id }, data: { ...data, items: { create: items } } }),
    ]);
    await this.audit.log(actorId, 'quote.update', 'Quote', id);
    if (dto.send) return this.send(actorId, id);
    return this.detail(id);
  }

  async send(actorId: string, id: string) {
    const quote = await this.prisma.quote.findUnique({ where: { id }, include: { booking: { include: { customer: { select: { locale: true } } } } } });
    if (!quote) throw new NotFoundException('Quote not found');
    if (quote.status !== 'DRAFT') throw new BadRequestException('This quote has already been sent');
    const { booking } = quote;
    if (TERMINAL_STATUSES.includes(booking.status)) throw new BadRequestException('Cannot send a quote for a closed booking');

    await this.prisma.$transaction([
      // A newly sent quote supersedes any outstanding one for the same booking
      this.prisma.quote.updateMany({ where: { bookingId: booking.id, status: 'SENT' }, data: { status: 'EXPIRED' } }),
      this.prisma.quote.update({ where: { id }, data: { status: 'SENT', sentAt: new Date() } }),
    ]);
    if (booking.status === 'IN_PROGRESS') {
      await this.bookings.applyStatus(booking.id, 'IN_PROGRESS', 'AWAITING_APPROVAL', actorId, `Quote ${quote.number} sent`);
    }
    await this.audit.log(actorId, 'quote.send', 'Quote', id);
    await this.notifications.notify(
      booking.customerId,
      'QUOTE_SENT',
      { ref: booking.reference, amount: formatMoney(Number(quote.total), quote.currency, booking.customer.locale) },
      { bookingId: booking.id, quoteId: id },
    );
    return this.detail(id);
  }

  async remove(actorId: string, id: string) {
    const quote = await this.prisma.quote.findUnique({ where: { id } });
    if (!quote) throw new NotFoundException('Quote not found');
    if (quote.status !== 'DRAFT') throw new BadRequestException('Only draft quotes can be deleted');
    await this.prisma.quote.delete({ where: { id } });
    await this.audit.log(actorId, 'quote.delete', 'Quote', id);
    return { ok: true };
  }

  async respond(customerId: string, id: string, accept: boolean, reason?: string) {
    const quote = await this.prisma.quote.findFirst({
      where: { id, booking: { customerId } },
      include: { booking: { include: { customer: { select: { fullName: true } } } } },
    });
    if (!quote) throw new NotFoundException('Quote not found');
    if (quote.status !== 'SENT') throw new BadRequestException('This quote is no longer awaiting a response');
    if (quote.validUntil && quote.validUntil < new Date()) {
      await this.prisma.quote.update({ where: { id }, data: { status: 'EXPIRED' } });
      throw new BadRequestException('This quote has expired. We will send you an updated one.');
    }

    await this.prisma.quote.update({
      where: { id },
      data: { status: accept ? 'ACCEPTED' : 'REJECTED', respondedAt: new Date(), rejectionReason: accept ? null : reason },
    });
    const { booking } = quote;
    if (accept) {
      await this.prisma.booking.update({ where: { id: booking.id }, data: { estimatedPrice: quote.total } });
      if (booking.status === 'AWAITING_APPROVAL') {
        await this.bookings.applyStatus(booking.id, 'AWAITING_APPROVAL', 'IN_PROGRESS', customerId, `Quote ${quote.number} accepted`);
      }
    }
    await this.notifications.notifyStaff(
      'QUOTE_RESPONDED',
      { number: quote.number, ref: booking.reference, customer: booking.customer.fullName, decision: accept ? 'accepted' : 'rejected' },
      { bookingId: booking.id, quoteId: id },
    );
    return this.bookings.customerDetail(customerId, booking.id);
  }

  async detail(id: string) {
    const quote = await this.prisma.quote.findUnique({
      where: { id },
      include: {
        items: { orderBy: { sortOrder: 'asc' } },
        booking: { select: { id: true, reference: true, status: true, customer: { select: { fullName: true, phone: true } } } },
        createdBy: { select: { fullName: true } },
      },
    });
    if (!quote) throw new NotFoundException('Quote not found');
    return quote;
  }

  async list(q: QuoteQueryDto) {
    const where: Prisma.QuoteWhereInput = {
      status: q.status,
      ...(q.search
        ? {
            OR: [
              { number: { contains: q.search, mode: 'insensitive' } },
              { booking: { reference: { contains: q.search, mode: 'insensitive' } } },
              { booking: { customer: { fullName: { contains: q.search, mode: 'insensitive' } } } },
            ],
          }
        : {}),
    };
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.quote.findMany({
        where,
        orderBy: orderBy(q.sortBy, q.sortOrder, ['createdAt', 'total', 'status', 'number']),
        ...skipTake(q),
        include: { booking: { select: { id: true, reference: true, customer: { select: { fullName: true, phone: true } } } } },
      }),
      this.prisma.quote.count({ where }),
    ]);
    return paginate(rows, total, q);
  }
}

// ── Controllers ──

@ApiTags('Quotes (customer)')
@ApiBearerAuth()
@Roles('CUSTOMER')
@Controller('quotes')
export class QuotesController {
  constructor(private readonly quotes: QuotesService) {}

  @Post(':id/accept')
  accept(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.quotes.respond(u.id, id, true);
  }

  @Post(':id/reject')
  reject(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: RejectQuoteDto) {
    return this.quotes.respond(u.id, id, false, dto.reason);
  }
}

@ApiTags('Admin · Quotes')
@ApiBearerAuth()
@Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
@Controller('admin')
export class AdminQuotesController {
  constructor(private readonly quotes: QuotesService) {}

  @Get('quotes')
  list(@Query() q: QuoteQueryDto) {
    return this.quotes.list(q);
  }

  @Get('quotes/:id')
  detail(@Param('id', ParseUUIDPipe) id: string) {
    return this.quotes.detail(id);
  }

  @Post('bookings/:bookingId/quotes')
  create(@CurrentUser() u: AuthUser, @Param('bookingId', ParseUUIDPipe) bookingId: string, @Body() dto: QuoteDto) {
    return this.quotes.create(u.id, bookingId, dto);
  }

  @Patch('quotes/:id')
  update(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: QuoteDto) {
    return this.quotes.update(u.id, id, dto);
  }

  @Post('quotes/:id/send')
  send(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.quotes.send(u.id, id);
  }

  @Delete('quotes/:id')
  remove(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.quotes.remove(u.id, id);
  }
}

@Module({
  imports: [BookingsModule],
  controllers: [QuotesController, AdminQuotesController],
  providers: [QuotesService],
})
export class QuotesModule {}
