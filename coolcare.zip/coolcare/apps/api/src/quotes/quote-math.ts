/**
 * Quote / invoice arithmetic using integer cents to avoid floating point drift.
 * All outputs are fixed 2-decimal strings suitable for Prisma Decimal columns.
 */
export interface LineInput {
  quantity: number;
  unitPrice: number;
}

export interface QuoteTotals {
  lines: { total: string }[];
  subtotal: string;
  discount: string;
  taxAmount: string;
  total: string;
}

const toCents = (value: number) => Math.round(value * 100);
const fromCents = (cents: number) => (cents / 100).toFixed(2);

export function computeQuoteTotals(items: LineInput[], discount = 0, taxRatePercent = 0): QuoteTotals {
  if (items.length === 0) throw new Error('A quote needs at least one line item');
  if (discount < 0) throw new Error('Discount cannot be negative');
  if (taxRatePercent < 0 || taxRatePercent > 100) throw new Error('Tax rate must be between 0 and 100');

  const lineCents = items.map((item) => {
    if (item.quantity <= 0) throw new Error('Quantity must be greater than zero');
    if (item.unitPrice < 0) throw new Error('Unit price cannot be negative');
    // quantity may have 2 decimals (e.g. 1.5 metres of pipe)
    return Math.round(toCents(item.unitPrice) * item.quantity);
  });

  const subtotalCents = lineCents.reduce((sum, c) => sum + c, 0);
  const discountCents = toCents(discount);
  if (discountCents > subtotalCents) throw new Error('Discount cannot exceed the subtotal');

  const taxableCents = subtotalCents - discountCents;
  const taxCents = Math.round((taxableCents * taxRatePercent) / 100);

  return {
    lines: lineCents.map((c) => ({ total: fromCents(c) })),
    subtotal: fromCents(subtotalCents),
    discount: fromCents(discountCents),
    taxAmount: fromCents(taxCents),
    total: fromCents(taxableCents + taxCents),
  };
}

/** Derives invoice status from total and amount paid. */
export function invoiceStatusFor(total: number, paid: number): 'UNPAID' | 'PARTIALLY_PAID' | 'PAID' {
  const totalCents = toCents(total);
  const paidCents = toCents(paid);
  if (paidCents <= 0) return 'UNPAID';
  if (paidCents >= totalCents) return 'PAID';
  return 'PARTIALLY_PAID';
}

export function formatMoney(amount: number | string, currency = 'USD', locale = 'en'): string {
  const value = typeof amount === 'string' ? Number(amount) : amount;
  try {
    return new Intl.NumberFormat(locale === 'so' ? 'so-SO' : 'en-US', { style: 'currency', currency }).format(value);
  } catch {
    return `${currency} ${value.toFixed(2)}`;
  }
}
