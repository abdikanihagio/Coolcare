import { computeQuoteTotals, formatMoney, invoiceStatusFor } from './quote-math';

describe('computeQuoteTotals', () => {
  it('sums line items without floating point drift', () => {
    const t = computeQuoteTotals([
      { quantity: 3, unitPrice: 0.1 },
      { quantity: 1, unitPrice: 0.2 },
    ]);
    expect(t.subtotal).toBe('0.50');
    expect(t.total).toBe('0.50');
    expect(t.lines.map((l) => l.total)).toEqual(['0.30', '0.20']);
  });

  it('applies discount before tax', () => {
    const t = computeQuoteTotals(
      [
        { quantity: 1, unitPrice: 120 },
        { quantity: 2, unitPrice: 15.5 },
      ],
      11,
      5,
    );
    expect(t.subtotal).toBe('151.00');
    expect(t.discount).toBe('11.00');
    expect(t.taxAmount).toBe('7.00');
    expect(t.total).toBe('147.00');
  });

  it('supports fractional quantities', () => {
    const t = computeQuoteTotals([{ quantity: 2.5, unitPrice: 4 }]);
    expect(t.total).toBe('10.00');
  });

  it('rejects invalid input', () => {
    expect(() => computeQuoteTotals([])).toThrow('at least one line item');
    expect(() => computeQuoteTotals([{ quantity: 0, unitPrice: 5 }])).toThrow('Quantity');
    expect(() => computeQuoteTotals([{ quantity: 1, unitPrice: -5 }])).toThrow('Unit price');
    expect(() => computeQuoteTotals([{ quantity: 1, unitPrice: 5 }], 6)).toThrow('Discount cannot exceed');
    expect(() => computeQuoteTotals([{ quantity: 1, unitPrice: 5 }], 0, 120)).toThrow('Tax rate');
  });
});

describe('invoiceStatusFor', () => {
  it('derives status from amounts', () => {
    expect(invoiceStatusFor(100, 0)).toBe('UNPAID');
    expect(invoiceStatusFor(100, 40)).toBe('PARTIALLY_PAID');
    expect(invoiceStatusFor(100, 100)).toBe('PAID');
    expect(invoiceStatusFor(100.1, 100.1)).toBe('PAID');
  });
});

describe('formatMoney', () => {
  it('formats USD', () => {
    expect(formatMoney(45, 'USD', 'en')).toBe('$45.00');
  });
});
