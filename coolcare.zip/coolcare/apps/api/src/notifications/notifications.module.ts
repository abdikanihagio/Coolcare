import { Global, Module } from '@nestjs/common';
import { NotificationsController } from './notifications.controller';
import { NotificationsService } from './notifications.service';
import { PushProvider } from './push.provider';
import { SmsProvider } from './sms.provider';

@Global()
@Module({
  controllers: [NotificationsController],
  providers: [NotificationsService, PushProvider, SmsProvider],
  exports: [NotificationsService, SmsProvider],
})
export class NotificationsModule {}
