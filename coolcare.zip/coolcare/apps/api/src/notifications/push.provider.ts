import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import type { App } from 'firebase-admin/app';

/**
 * Firebase Cloud Messaging sender. Disabled (no-op) when
 * FIREBASE_SERVICE_ACCOUNT_BASE64 is not set.
 */
@Injectable()
export class PushProvider implements OnModuleInit {
  private readonly logger = new Logger('Push');
  private app: App | null = null;

  async onModuleInit() {
    const encoded = process.env.FIREBASE_SERVICE_ACCOUNT_BASE64;
    if (!encoded) {
      this.logger.warn('FIREBASE_SERVICE_ACCOUNT_BASE64 not set — push notifications disabled');
      return;
    }
    try {
      const { initializeApp, cert, getApps } = await import('firebase-admin/app');
      const serviceAccount = JSON.parse(Buffer.from(encoded, 'base64').toString('utf8'));
      this.app = getApps()[0] ?? initializeApp({ credential: cert(serviceAccount) });
      this.logger.log('Firebase Cloud Messaging ready');
    } catch (err) {
      this.logger.error(`Failed to initialise Firebase: ${(err as Error).message}`);
    }
  }

  get enabled() {
    return this.app !== null;
  }

  /** Sends to the given device tokens; returns tokens FCM reports as invalid so callers can prune them. */
  async send(tokens: string[], title: string, body: string, data: Record<string, string> = {}): Promise<string[]> {
    if (!this.app || tokens.length === 0) return [];
    const { getMessaging } = await import('firebase-admin/messaging');
    const result = await getMessaging(this.app).sendEachForMulticast({
      tokens,
      notification: { title, body },
      data,
      android: { priority: 'high', notification: { channelId: 'default', color: '#1677C8' } },
      apns: { payload: { aps: { sound: 'default' } } },
    });
    const invalid: string[] = [];
    result.responses.forEach((r, i) => {
      const code = r.error?.code ?? '';
      if (code.includes('registration-token-not-registered') || code.includes('invalid-argument')) invalid.push(tokens[i]);
    });
    return invalid;
  }
}
