import { Injectable, Logger } from '@nestjs/common';

/**
 * Pluggable SMS delivery.
 *  - SMS_PROVIDER=console : logs messages (development only)
 *  - SMS_PROVIDER=http    : POST { to, message, sender } to SMS_HTTP_URL with Bearer SMS_HTTP_TOKEN
 *
 * To integrate a specific Somali gateway (Hormuud, Somtel, Telesom) or Twilio,
 * adapt `sendViaHttp` to that provider's request format.
 */
@Injectable()
export class SmsProvider {
  private readonly logger = new Logger('SMS');

  get isConfigured(): boolean {
    const provider = process.env.SMS_PROVIDER ?? 'console';
    return provider === 'console' || (provider === 'http' && !!process.env.SMS_HTTP_URL);
  }

  /** True only when a real gateway sends messages (used to decide whether OTP is enforced). */
  get deliversRealSms(): boolean {
    return process.env.SMS_PROVIDER === 'http' && !!process.env.SMS_HTTP_URL;
  }

  async send(to: string, message: string): Promise<void> {
    const provider = process.env.SMS_PROVIDER ?? 'console';
    if (provider === 'http') return this.sendViaHttp(to, message);
    this.logger.log(`[console SMS] to=${to} :: ${message}`);
  }

  private async sendViaHttp(to: string, message: string): Promise<void> {
    const url = process.env.SMS_HTTP_URL;
    if (!url) throw new Error('SMS_HTTP_URL is not configured');
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(process.env.SMS_HTTP_TOKEN ? { Authorization: `Bearer ${process.env.SMS_HTTP_TOKEN}` } : {}),
      },
      body: JSON.stringify({ to, message, sender: process.env.SMS_SENDER_ID ?? 'CoolCare' }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      this.logger.error(`SMS gateway error ${res.status}: ${text.slice(0, 300)}`);
      throw new Error('Could not send SMS');
    }
  }
}
