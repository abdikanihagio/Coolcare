import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { paginate, skipTake } from '../common/pagination';
import { PushProvider } from './push.provider';
import { NotificationType, render } from './templates';

@Injectable()
export class NotificationsService {
  private readonly logger = new Logger('Notifications');

  constructor(
    private readonly prisma: PrismaService,
    private readonly push: PushProvider,
  ) {}

  /**
   * Stores an in-app notification in the user's language and sends a push
   * notification to their registered devices. Never throws — notification
   * failures must not break the business operation that triggered them.
   */
  async notify(
    userId: string,
    type: NotificationType,
    vars: Record<string, string | number | undefined>,
    data: Record<string, string> = {},
  ): Promise<void> {
    try {
      const user = await this.prisma.user.findUnique({
        where: { id: userId },
        select: { locale: true, deviceTokens: { select: { token: true } } },
      });
      if (!user) return;

      const { title, body } = render(type, user.locale, vars);
      await this.prisma.notification.create({
        data: { userId, type, title, body, data: data as Prisma.InputJsonValue },
      });

      const tokens = user.deviceTokens.map((d) => d.token);
      const invalid = await this.push.send(tokens, title, body, { type, ...data });
      if (invalid.length) {
        await this.prisma.deviceToken.deleteMany({ where: { token: { in: invalid } } });
      }
    } catch (err) {
      this.logger.error(`notify(${type}) failed for ${userId}: ${(err as Error).message}`);
    }
  }

  /** Notifies operational staff (admins and dispatchers) in the dashboard notification centre. */
  async notifyStaff(type: NotificationType, vars: Record<string, string | number | undefined>, data: Record<string, string> = {}) {
    const staff = await this.prisma.user.findMany({
      where: { role: { in: ['SUPER_ADMIN', 'ADMIN', 'DISPATCHER'] }, status: 'ACTIVE', deletedAt: null },
      select: { id: true },
    });
    await Promise.all(staff.map((s) => this.notify(s.id, type, vars, data)));
  }

  async list(userId: string, q: { page: number; pageSize: number }) {
    const where = { userId };
    const [data, total, unread] = await this.prisma.$transaction([
      this.prisma.notification.findMany({ where, orderBy: { createdAt: 'desc' }, ...skipTake(q) }),
      this.prisma.notification.count({ where }),
      this.prisma.notification.count({ where: { userId, readAt: null } }),
    ]);
    return { ...paginate(data, total, q), unread };
  }

  async markRead(userId: string, id: string) {
    const result = await this.prisma.notification.updateMany({
      where: { id, userId, readAt: null },
      data: { readAt: new Date() },
    });
    if (result.count === 0) {
      const exists = await this.prisma.notification.count({ where: { id, userId } });
      if (!exists) throw new NotFoundException('Notification not found');
    }
    return { ok: true };
  }

  async markAllRead(userId: string) {
    await this.prisma.notification.updateMany({ where: { userId, readAt: null }, data: { readAt: new Date() } });
    return { ok: true };
  }

  /** Admin broadcast to all active customers (in-app + push). */
  async broadcast(input: { titleEn: string; bodyEn: string; titleSo?: string; bodySo?: string }) {
    const customers = await this.prisma.user.findMany({
      where: { role: 'CUSTOMER', status: 'ACTIVE', deletedAt: null },
      select: { id: true, locale: true, deviceTokens: { select: { token: true } } },
    });
    let sent = 0;
    for (const c of customers) {
      const title = c.locale === 'so' && input.titleSo ? input.titleSo : input.titleEn;
      const body = c.locale === 'so' && input.bodySo ? input.bodySo : input.bodyEn;
      await this.prisma.notification.create({ data: { userId: c.id, type: 'GENERAL', title, body } });
      await this.push.send(c.deviceTokens.map((d) => d.token), title, body, { type: 'GENERAL' }).catch(() => []);
      sent++;
    }
    return { recipients: sent };
  }
}
