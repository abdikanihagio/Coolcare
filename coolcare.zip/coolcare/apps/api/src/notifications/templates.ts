/**
 * Bilingual (English / Somali) notification copy.
 * Placeholders use {name} syntax. Somali copy should be reviewed by a native
 * speaker before launch — see docs/TRANSLATIONS.md.
 */
export type NotificationType =
  | 'BOOKING_CREATED'
  | 'BOOKING_CONFIRMED'
  | 'TECHNICIAN_ASSIGNED'
  | 'TECHNICIAN_ON_THE_WAY'
  | 'WORK_STARTED'
  | 'QUOTE_SENT'
  | 'JOB_COMPLETED'
  | 'BOOKING_CANCELLED'
  | 'PAYMENT_RECEIVED'
  | 'INVOICE_ISSUED'
  | 'MAINTENANCE_DUE'
  | 'NEW_BOOKING'
  | 'QUOTE_RESPONDED'
  | 'BOOKING_CANCELLED_BY_CUSTOMER'
  | 'GENERAL';

type Copy = { title: string; body: string };

export const TEMPLATES: Record<NotificationType, { en: Copy; so: Copy }> = {
  BOOKING_CREATED: {
    en: { title: 'Booking received', body: 'Your booking {ref} has been received. We will confirm it shortly.' },
    so: { title: 'Dalabkaaga waa la helay', body: 'Dalabkaaga {ref} waa la helay. Dhawaan ayaan xaqiijin doonnaa.' },
  },
  BOOKING_CONFIRMED: {
    en: { title: 'Booking confirmed', body: 'Your booking {ref} is confirmed for {date}.' },
    so: { title: 'Dalabka waa la xaqiijiyay', body: 'Dalabkaaga {ref} waa la xaqiijiyay, taariikhda {date}.' },
  },
  TECHNICIAN_ASSIGNED: {
    en: { title: 'Technician assigned', body: '{tech} has been assigned to your booking {ref}.' },
    so: { title: 'Farsamayaqaan ayaa loo qoondeeyay', body: '{tech} ayaa loo qoondeeyay dalabkaaga {ref}.' },
  },
  TECHNICIAN_ON_THE_WAY: {
    en: { title: 'Technician on the way', body: '{tech} is on the way to you for booking {ref}.' },
    so: { title: 'Farsamayaqaanku wuu soo socdaa', body: '{tech} ayaa kuu soo socda dalabka {ref} awgiis.' },
  },
  WORK_STARTED: {
    en: { title: 'Work started', body: 'Work on your booking {ref} has started.' },
    so: { title: 'Shaqadii waa la bilaabay', body: 'Shaqada dalabkaaga {ref} waa la bilaabay.' },
  },
  QUOTE_SENT: {
    en: { title: 'Quotation ready', body: 'A quotation of {amount} is ready for booking {ref}. Please review and respond.' },
    so: { title: 'Qiimayn ayaa diyaar ah', body: 'Qiimayn dhan {amount} ayaa diyaar u ah dalabka {ref}. Fadlan dib u eeg oo ka jawaab.' },
  },
  JOB_COMPLETED: {
    en: { title: 'Job completed', body: 'Your booking {ref} is complete. Tell us how we did!' },
    so: { title: 'Shaqadii waa dhammaatay', body: 'Dalabkaaga {ref} waa la dhammeeyay. Noo sheeg sida aan u qabannay!' },
  },
  BOOKING_CANCELLED: {
    en: { title: 'Booking cancelled', body: 'Booking {ref} has been cancelled.' },
    so: { title: 'Dalabka waa la joojiyay', body: 'Dalabka {ref} waa la joojiyay.' },
  },
  PAYMENT_RECEIVED: {
    en: { title: 'Payment received', body: 'We received your payment of {amount}. Thank you!' },
    so: { title: 'Lacagta waa la helay', body: 'Waxaan helnay lacagtaada oo dhan {amount}. Mahadsanid!' },
  },
  INVOICE_ISSUED: {
    en: { title: 'Invoice issued', body: 'Invoice {number} for {amount} has been issued for booking {ref}.' },
    so: { title: 'Biil ayaa la soo saaray', body: 'Biilka {number} oo dhan {amount} ayaa loo soo saaray dalabka {ref}.' },
  },
  MAINTENANCE_DUE: {
    en: { title: 'Maintenance visit due', body: 'Your {plan} maintenance visit is due on {date}. Book a time that suits you.' },
    so: { title: 'Booqasho dayactir ayaa dhow', body: 'Booqashada dayactirka {plan} waxay dhacaysaa {date}. Dooro waqti kugu habboon.' },
  },
  // Staff-facing (shown in the admin dashboard notification centre)
  NEW_BOOKING: {
    en: { title: 'New booking {ref}', body: '{customer} booked {service} for {date}.' },
    so: { title: 'Dalab cusub {ref}', body: '{customer} ayaa dalbaday {service}, taariikhda {date}.' },
  },
  QUOTE_RESPONDED: {
    en: { title: 'Quote {number} {decision}', body: '{customer} {decision} the quotation for booking {ref}.' },
    so: { title: 'Qiimaynta {number} {decision}', body: '{customer} wuxuu {decision} qiimaynta dalabka {ref}.' },
  },
  BOOKING_CANCELLED_BY_CUSTOMER: {
    en: { title: 'Booking {ref} cancelled', body: '{customer} cancelled booking {ref}. Reason: {reason}' },
    so: { title: 'Dalabka {ref} waa la joojiyay', body: '{customer} ayaa joojiyay dalabka {ref}. Sababta: {reason}' },
  },
  GENERAL: {
    en: { title: '{title}', body: '{body}' },
    so: { title: '{title}', body: '{body}' },
  },
};

export const OTP_SMS = {
  en: 'Your CoolCare verification code is {code}. It expires in {minutes} minutes. Do not share it with anyone.',
  so: 'Koodhkaaga xaqiijinta CoolCare waa {code}. Wuxuu dhacayaa {minutes} daqiiqo kadib. Cidna ha la wadaagin.',
};

export function interpolate(template: string, vars: Record<string, string | number | undefined>): string {
  return template.replace(/\{(\w+)\}/g, (match, key: string) => (vars[key] !== undefined ? String(vars[key]) : match));
}

export function render(type: NotificationType, locale: 'en' | 'so', vars: Record<string, string | number | undefined>): Copy {
  const copy = TEMPLATES[type][locale] ?? TEMPLATES[type].en;
  return { title: interpolate(copy.title, vars), body: interpolate(copy.body, vars) };
}
