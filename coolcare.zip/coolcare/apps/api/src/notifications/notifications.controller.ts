import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { CurrentUser, Roles } from '../common/decorators';
import { PaginationQueryDto } from '../common/pagination';
import type { AuthUser } from '../common/types';
import { NotificationsService } from './notifications.service';

class BroadcastDto {
  @IsString() @IsNotEmpty() @MaxLength(120) titleEn: string;
  @IsString() @IsNotEmpty() @MaxLength(500) bodyEn: string;
  @IsOptional() @IsString() @MaxLength(120) titleSo?: string;
  @IsOptional() @IsString() @MaxLength(500) bodySo?: string;
}

@ApiTags('Notifications')
@ApiBearerAuth()
@Controller('notifications')
export class NotificationsController {
  constructor(private readonly notifications: NotificationsService) {}

  @Get()
  list(@CurrentUser() user: AuthUser, @Query() q: PaginationQueryDto) {
    return this.notifications.list(user.id, q);
  }

  @Patch('read-all')
  markAll(@CurrentUser() user: AuthUser) {
    return this.notifications.markAllRead(user.id);
  }

  @Patch(':id/read')
  markRead(@CurrentUser() user: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.notifications.markRead(user.id, id);
  }

  @Post('broadcast')
  @Roles('ADMIN')
  broadcast(@Body() dto: BroadcastDto) {
    return this.notifications.broadcast(dto);
  }
}
