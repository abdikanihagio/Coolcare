import { Injectable, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    await this.$connect();
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }

  /**
   * Atomically increments a named counter and returns the new value.
   * Used for human-readable references (CC-2026-000123, Q-2026-0042, INV-2026-0042).
   */
  async nextSequence(name: string): Promise<number> {
    const counter = await this.counter.upsert({
      where: { name },
      create: { name, value: 1 },
      update: { value: { increment: 1 } },
    });
    return counter.value;
  }
}
