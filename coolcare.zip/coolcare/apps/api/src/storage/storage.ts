import {
  BadRequestException,
  Controller,
  Global,
  Injectable,
  Logger,
  Module,
  Post,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiQuery, ApiTags } from '@nestjs/swagger';
import { DeleteObjectCommand, PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { randomUUID } from 'crypto';
import { CurrentUser } from '../common/decorators';
import type { AuthUser } from '../common/types';

const ALLOWED_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/heic': 'heic',
};
export const MAX_UPLOAD_BYTES = 8 * 1024 * 1024;

export interface StoredFile {
  key: string;
  url: string;
  contentType: string;
  size: number;
}

/** S3-compatible object storage (AWS S3, MinIO, Cloudflare R2, DigitalOcean Spaces…). */
@Injectable()
export class StorageService {
  private readonly logger = new Logger('Storage');
  private readonly client: S3Client;
  private readonly bucket = process.env.STORAGE_BUCKET ?? 'coolcare';

  constructor() {
    this.client = new S3Client({
      region: process.env.STORAGE_REGION ?? 'us-east-1',
      endpoint: process.env.STORAGE_ENDPOINT || undefined,
      forcePathStyle: (process.env.STORAGE_FORCE_PATH_STYLE ?? 'true') === 'true',
      credentials:
        process.env.STORAGE_ACCESS_KEY && process.env.STORAGE_SECRET_KEY
          ? { accessKeyId: process.env.STORAGE_ACCESS_KEY, secretAccessKey: process.env.STORAGE_SECRET_KEY }
          : undefined,
    });
  }

  publicUrl(key: string): string {
    const base = (process.env.STORAGE_PUBLIC_URL ?? process.env.STORAGE_ENDPOINT ?? '').replace(/\/$/, '');
    return `${base}/${this.bucket}/${key}`;
  }

  async putImage(folder: string, file: { buffer: Buffer; mimetype: string; size: number }): Promise<StoredFile> {
    const ext = ALLOWED_TYPES[file.mimetype];
    if (!ext) throw new BadRequestException('Only JPEG, PNG, WebP or HEIC images are allowed');
    if (file.size > MAX_UPLOAD_BYTES) throw new BadRequestException('Image must be smaller than 8 MB');

    // Objects under public/ are readable anonymously (see minio-init in docker-compose)
    const key = `public/${folder}/${new Date().toISOString().slice(0, 7)}/${randomUUID()}.${ext}`;
    try {
      await this.client.send(
        new PutObjectCommand({ Bucket: this.bucket, Key: key, Body: file.buffer, ContentType: file.mimetype, CacheControl: 'public, max-age=31536000' }),
      );
    } catch (err) {
      this.logger.error(`upload failed: ${(err as Error).message}`);
      throw new BadRequestException('Could not store the image. Please try again.');
    }
    return { key, url: this.publicUrl(key), contentType: file.mimetype, size: file.size };
  }

  async remove(key: string) {
    await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key })).catch((err) => {
      this.logger.warn(`delete failed for ${key}: ${(err as Error).message}`);
    });
  }
}

const FOLDERS = ['avatars', 'bookings', 'technicians', 'services'] as const;

@ApiTags('Uploads')
@ApiBearerAuth()
@Controller('uploads')
export class UploadsController {
  constructor(private readonly storage: StorageService) {}

  @Post('image')
  @ApiConsumes('multipart/form-data')
  @ApiBody({ schema: { type: 'object', properties: { file: { type: 'string', format: 'binary' } } } })
  @ApiQuery({ name: 'folder', enum: FOLDERS, required: false })
  @UseInterceptors(FileInterceptor('file', { limits: { fileSize: MAX_UPLOAD_BYTES } }))
  async upload(@CurrentUser() user: AuthUser, @UploadedFile() file?: Express.Multer.File, @Query('folder') folder = 'bookings') {
    if (!file) throw new BadRequestException('Attach an image in the "file" field');
    if (!(FOLDERS as readonly string[]).includes(folder)) throw new BadRequestException('Invalid folder');
    if (user.role === 'CUSTOMER' && !['avatars', 'bookings'].includes(folder)) throw new BadRequestException('Invalid folder');
    return this.storage.putImage(folder, file);
  }
}

@Global()
@Module({ controllers: [UploadsController], providers: [StorageService], exports: [StorageService] })
export class StorageModule {}
