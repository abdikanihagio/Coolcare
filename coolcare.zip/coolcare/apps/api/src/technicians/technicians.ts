import { BadRequestException, Body, Controller, Delete, Get, Injectable, Module, NotFoundException, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiProperty, ApiPropertyOptional, ApiTags, PartialType } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { ArrayMaxSize, IsArray, IsBoolean, IsDateString, IsEmail, IsEnum, IsNotEmpty, IsOptional, IsString, IsUrl, IsUUID, MaxLength } from 'class-validator';
import { Prisma, TechnicianStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { CurrentUser, Roles } from '../common/decorators';
import { orderBy, paginate, PaginationQueryDto, skipTake } from '../common/pagination';
import { isValidPhone, normalizePhone } from '../common/phone';
import type { AuthUser } from '../common/types';
import { ACTIVE_STATUSES } from '../bookings/booking-status';

// ── DTOs ──

export class TechnicianDto {
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(100) fullName: string;
  @ApiProperty() @IsString() @IsNotEmpty() phone: string;
  @ApiPropertyOptional() @IsOptional() @IsEmail() email?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() branchId?: string;
  @ApiPropertyOptional({ type: [String], example: ['SPLIT_AC', 'REFRIGERATOR'] })
  @IsOptional() @IsArray() @ArrayMaxSize(20) @IsString({ each: true }) specialties?: string[];
  @ApiPropertyOptional({ enum: TechnicianStatus }) @IsOptional() @IsEnum(TechnicianStatus) status?: TechnicianStatus;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() isAvailable?: boolean;
  @ApiPropertyOptional() @IsOptional() @IsUrl({ require_tld: false }) photoUrl?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(1000) notes?: string;
}
export class UpdateTechnicianDto extends PartialType(TechnicianDto) {}

export class TechnicianQueryDto extends PaginationQueryDto {
  @ApiPropertyOptional({ enum: TechnicianStatus }) @IsOptional() @IsEnum(TechnicianStatus) status?: TechnicianStatus;
  @ApiPropertyOptional() @IsOptional() @Transform(({ value }) => value === 'true' || value === true) @IsBoolean() available?: boolean;
  @ApiPropertyOptional({ description: 'Return workload for this date (YYYY-MM-DD)' }) @IsOptional() @IsDateString() date?: string;
  @ApiPropertyOptional() @IsOptional() @Type(() => String) @IsString() specialty?: string;
}

// ── Service ──

@Injectable()
export class TechniciansService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  async list(q: TechnicianQueryDto) {
    const where: Prisma.TechnicianWhereInput = {
      deletedAt: null,
      status: q.status,
      isAvailable: q.available,
      ...(q.specialty ? { specialties: { has: q.specialty } } : {}),
      ...(q.search
        ? { OR: [{ fullName: { contains: q.search, mode: 'insensitive' } }, { phone: { contains: q.search.replace(/\s/g, '') } }] }
        : {}),
    };
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.technician.findMany({
        where,
        orderBy: orderBy(q.sortBy, q.sortOrder, ['createdAt', 'fullName', 'rating', 'jobsCompleted'], 'fullName'),
        ...skipTake(q),
        include: { branch: { select: { id: true, name: true } } },
      }),
      this.prisma.technician.count({ where }),
    ]);

    // Workload: active jobs overall and (optionally) jobs scheduled on a given date
    const ids = rows.map((r) => r.id);
    const active = await this.prisma.booking.groupBy({
      by: ['technicianId'],
      where: { technicianId: { in: ids }, status: { in: ACTIVE_STATUSES } },
      _count: { _all: true },
    });
    const onDate = q.date
      ? await this.prisma.booking.groupBy({
          by: ['technicianId'],
          where: { technicianId: { in: ids }, scheduledDate: new Date(q.date), status: { not: 'CANCELLED' } },
          _count: { _all: true },
        })
      : [];
    const activeMap = new Map<string | null, number>(active.map((a) => [a.technicianId, a._count._all]));
    const dateMap = new Map<string | null, number>(onDate.map((a) => [a.technicianId, a._count._all]));

    return paginate(
      rows.map((t) => ({ ...t, activeJobs: activeMap.get(t.id) ?? 0, jobsOnDate: q.date ? dateMap.get(t.id) ?? 0 : undefined })),
      total,
      q,
    );
  }

  async detail(id: string) {
    const tech = await this.prisma.technician.findFirst({
      where: { id, deletedAt: null },
      include: {
        branch: true,
        bookings: {
          orderBy: { scheduledDate: 'desc' },
          take: 30,
          include: { service: { select: { nameEn: true, nameSo: true } }, customer: { select: { fullName: true, phone: true } } },
        },
      },
    });
    if (!tech) throw new NotFoundException('Technician not found');
    return tech;
  }

  async create(actorId: string, dto: TechnicianDto) {
    const phone = normalizePhone(dto.phone);
    if (!isValidPhone(phone)) throw new BadRequestException('Invalid phone number');
    const tech = await this.prisma.technician.create({ data: { ...dto, phone, specialties: dto.specialties ?? [] } });
    await this.audit.log(actorId, 'technician.create', 'Technician', tech.id);
    return tech;
  }

  async update(actorId: string, id: string, dto: UpdateTechnicianDto) {
    const phone = dto.phone ? normalizePhone(dto.phone) : undefined;
    if (phone && !isValidPhone(phone)) throw new BadRequestException('Invalid phone number');
    const tech = await this.prisma.technician.update({ where: { id }, data: { ...dto, phone } });
    await this.audit.log(actorId, 'technician.update', 'Technician', id, dto as Record<string, unknown>);
    return tech;
  }

  async remove(actorId: string, id: string) {
    const active = await this.prisma.booking.count({ where: { technicianId: id, status: { in: ACTIVE_STATUSES } } });
    if (active) throw new BadRequestException(`Reassign this technician's ${active} active job(s) first`);
    await this.prisma.technician.update({ where: { id }, data: { deletedAt: new Date(), status: 'INACTIVE', isAvailable: false } });
    await this.audit.log(actorId, 'technician.delete', 'Technician', id);
    return { ok: true };
  }
}

// ── Controller ──

@ApiTags('Admin · Technicians')
@ApiBearerAuth()
@Roles('ADMIN', 'DISPATCHER')
@Controller('admin/technicians')
export class TechniciansController {
  constructor(private readonly technicians: TechniciansService) {}

  @Get()
  list(@Query() q: TechnicianQueryDto) {
    return this.technicians.list(q);
  }

  @Get(':id')
  detail(@Param('id', ParseUUIDPipe) id: string) {
    return this.technicians.detail(id);
  }

  @Post()
  @Roles('ADMIN')
  create(@CurrentUser() u: AuthUser, @Body() dto: TechnicianDto) {
    return this.technicians.create(u.id, dto);
  }

  @Patch(':id')
  update(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateTechnicianDto) {
    return this.technicians.update(u.id, id, dto);
  }

  @Delete(':id')
  @Roles('ADMIN')
  remove(@CurrentUser() u: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.technicians.remove(u.id, id);
  }
}

@Module({ controllers: [TechniciansController], providers: [TechniciansService], exports: [TechniciansService] })
export class TechniciansModule {}
