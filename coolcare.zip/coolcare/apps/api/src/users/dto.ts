import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsBoolean,
  IsDateString,
  IsEmail,
  IsEnum,
  IsIn,
  IsLatitude,
  IsLongitude,
  IsNotEmpty,
  IsOptional,
  IsString,
  IsUrl,
  IsUUID,
  Matches,
  MaxLength,
} from 'class-validator';
import { EquipmentType, Role, UserStatus } from '@prisma/client';
import { PaginationQueryDto } from '../common/pagination';
import { PASSWORD_MESSAGE, PASSWORD_RULE } from '../auth/dto';

export class UpdateProfileDto {
  @ApiPropertyOptional() @IsOptional() @IsString() @IsNotEmpty() @MaxLength(100) fullName?: string;
  @ApiPropertyOptional() @IsOptional() @IsEmail() email?: string;
  @ApiPropertyOptional({ enum: ['en', 'so'] }) @IsOptional() @IsIn(['en', 'so']) locale?: 'en' | 'so';
  @ApiPropertyOptional() @IsOptional() @IsUrl({ require_tld: false }) avatarUrl?: string;
}

export class RegisterDeviceDto {
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(4096) token: string;
  @ApiProperty({ enum: ['ios', 'android', 'web'] }) @IsIn(['ios', 'android', 'web']) platform: string;
}

export class AddressDto {
  @ApiProperty({ example: 'Home' }) @IsString() @IsNotEmpty() @MaxLength(50) label: string;
  @ApiProperty({ example: 'Hodan' }) @IsString() @IsNotEmpty() @MaxLength(80) district: string;
  @ApiPropertyOptional({ example: 'Taleex' }) @IsOptional() @IsString() @MaxLength(80) neighborhood?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(120) street?: string;
  @ApiPropertyOptional({ example: 'Near KM4 junction' }) @IsOptional() @IsString() @MaxLength(160) landmark?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(300) details?: string;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsLatitude() latitude?: number;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsLongitude() longitude?: number;
  @ApiPropertyOptional() @IsOptional() @IsBoolean() isDefault?: boolean;
}

export class EquipmentDto {
  @ApiProperty({ enum: EquipmentType }) @IsEnum(EquipmentType) type: EquipmentType;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(60) brand?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(60) model?: string;
  @ApiPropertyOptional({ example: '1.5 ton / 18,000 BTU' }) @IsOptional() @IsString() @MaxLength(60) capacity?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(80) serialNumber?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() installDate?: string;
  @ApiPropertyOptional({ example: 'Living room' }) @IsOptional() @IsString() @MaxLength(80) location?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() @MaxLength(500) notes?: string;
}

export class UpdateAddressDto extends PartialType(AddressDto) {}
export class UpdateEquipmentDto extends PartialType(EquipmentDto) {}

export class CustomerQueryDto extends PaginationQueryDto {
  @ApiPropertyOptional({ enum: UserStatus }) @IsOptional() @IsEnum(UserStatus) status?: UserStatus;
}

export class UpdateUserStatusDto {
  @ApiProperty({ enum: UserStatus }) @IsEnum(UserStatus) status: UserStatus;
}

const STAFF = ['SUPER_ADMIN', 'ADMIN', 'DISPATCHER', 'ACCOUNTANT'] as const;

export class CreateStaffDto {
  @ApiProperty() @IsString() @IsNotEmpty() @MaxLength(100) fullName: string;
  @ApiProperty() @IsString() @IsNotEmpty() phone: string;
  @ApiProperty() @IsEmail() email: string;
  @ApiProperty({ enum: STAFF }) @IsIn(STAFF as unknown as string[]) role: Role;
  @ApiProperty() @Matches(PASSWORD_RULE, { message: PASSWORD_MESSAGE }) password: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() branchId?: string;
}

export class UpdateStaffDto {
  @ApiPropertyOptional() @IsOptional() @IsString() @IsNotEmpty() @MaxLength(100) fullName?: string;
  @ApiPropertyOptional({ enum: STAFF }) @IsOptional() @IsIn(STAFF as unknown as string[]) role?: Role;
  @ApiPropertyOptional({ enum: UserStatus }) @IsOptional() @IsEnum(UserStatus) status?: UserStatus;
  @ApiPropertyOptional() @IsOptional() @IsUUID() branchId?: string | null;
  @ApiPropertyOptional() @IsOptional() @Matches(PASSWORD_RULE, { message: PASSWORD_MESSAGE }) password?: string;
}
