import { Module } from '@nestjs/common';
import { AdminCustomersController, AdminStaffController } from './admin-users.controller';
import { MeController } from './me.controller';
import { UsersService } from './users.service';

@Module({
  controllers: [MeController, AdminCustomersController, AdminStaffController],
  providers: [UsersService],
  exports: [UsersService],
})
export class UsersModule {}
