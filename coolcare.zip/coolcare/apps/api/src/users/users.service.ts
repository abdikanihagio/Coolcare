import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import * as bcrypt from 'bcryptjs';
import { Prisma, Role } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { orderBy, paginate, skipTake } from '../common/pagination';
import { isValidPhone, normalizePhone } from '../common/phone';
import { STAFF_ROLES } from '../common/types';
import { toPublicUser } from './user.mapper';
import {
  AddressDto,
  CreateStaffDto,
  CustomerQueryDto,
  EquipmentDto,
  RegisterDeviceDto,
  UpdateProfileDto,
  UpdateStaffDto,
} from './dto';

@Injectable()
export class UsersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  // ── Self-service profile ──

  async me(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user || user.deletedAt) throw new NotFoundException('Account not found');
    return toPublicUser(user);
  }

  async updateMe(userId: string, dto: UpdateProfileDto) {
    const user = await this.prisma.user.update({
      where: { id: userId },
      data: {
        fullName: dto.fullName?.trim(),
        email: dto.email === undefined ? undefined : dto.email.trim().toLowerCase(),
        locale: dto.locale,
        avatarUrl: dto.avatarUrl,
      },
    });
    return toPublicUser(user);
  }

  /** Soft-deletes and anonymises a customer account (right to erasure). */
  async deleteMe(userId: string) {
    const open = await this.prisma.booking.count({
      where: { customerId: userId, status: { notIn: ['COMPLETED', 'CANCELLED'] } },
    });
    if (open > 0) throw new BadRequestException('Please cancel or complete your open bookings before deleting your account');
    await this.prisma.$transaction([
      this.prisma.user.update({
        where: { id: userId },
        data: {
          deletedAt: new Date(),
          status: 'SUSPENDED',
          fullName: 'Deleted user',
          email: null,
          phone: `deleted:${userId}`,
          passwordHash: null,
          avatarUrl: null,
        },
      }),
      this.prisma.refreshToken.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } }),
      this.prisma.deviceToken.deleteMany({ where: { userId } }),
    ]);
    return { ok: true };
  }

  async registerDevice(userId: string, dto: RegisterDeviceDto) {
    await this.prisma.deviceToken.upsert({
      where: { token: dto.token },
      create: { userId, token: dto.token, platform: dto.platform },
      update: { userId, platform: dto.platform },
    });
    return { ok: true };
  }

  async removeDevice(userId: string, token: string) {
    await this.prisma.deviceToken.deleteMany({ where: { userId, token } });
    return { ok: true };
  }

  // ── Addresses ──

  listAddresses(userId: string) {
    return this.prisma.address.findMany({
      where: { userId, deletedAt: null },
      orderBy: [{ isDefault: 'desc' }, { createdAt: 'desc' }],
    });
  }

  async createAddress(userId: string, dto: AddressDto) {
    const count = await this.prisma.address.count({ where: { userId, deletedAt: null } });
    const isDefault = dto.isDefault ?? count === 0;
    return this.prisma.$transaction(async (tx) => {
      if (isDefault) await tx.address.updateMany({ where: { userId }, data: { isDefault: false } });
      return tx.address.create({ data: { ...dto, userId, isDefault } });
    });
  }

  async updateAddress(userId: string, id: string, dto: Partial<AddressDto>) {
    await this.ownedAddress(userId, id);
    return this.prisma.$transaction(async (tx) => {
      if (dto.isDefault) await tx.address.updateMany({ where: { userId }, data: { isDefault: false } });
      return tx.address.update({ where: { id }, data: dto });
    });
  }

  async deleteAddress(userId: string, id: string) {
    const address = await this.ownedAddress(userId, id);
    await this.prisma.address.update({ where: { id }, data: { deletedAt: new Date(), isDefault: false } });
    if (address.isDefault) {
      const next = await this.prisma.address.findFirst({ where: { userId, deletedAt: null }, orderBy: { createdAt: 'desc' } });
      if (next) await this.prisma.address.update({ where: { id: next.id }, data: { isDefault: true } });
    }
    return { ok: true };
  }

  async ownedAddress(userId: string, id: string) {
    const address = await this.prisma.address.findFirst({ where: { id, userId, deletedAt: null } });
    if (!address) throw new NotFoundException('Address not found');
    return address;
  }

  // ── Equipment ──

  listEquipment(userId: string) {
    return this.prisma.equipment.findMany({ where: { userId, deletedAt: null }, orderBy: { createdAt: 'desc' } });
  }

  createEquipment(userId: string, dto: EquipmentDto) {
    return this.prisma.equipment.create({
      data: { ...dto, installDate: dto.installDate ? new Date(dto.installDate) : undefined, userId },
    });
  }

  async updateEquipment(userId: string, id: string, dto: Partial<EquipmentDto>) {
    await this.ownedEquipment(userId, id);
    return this.prisma.equipment.update({
      where: { id },
      data: { ...dto, installDate: dto.installDate ? new Date(dto.installDate) : undefined },
    });
  }

  async deleteEquipment(userId: string, id: string) {
    await this.ownedEquipment(userId, id);
    await this.prisma.equipment.update({ where: { id }, data: { deletedAt: new Date() } });
    return { ok: true };
  }

  async ownedEquipment(userId: string, id: string) {
    const item = await this.prisma.equipment.findFirst({ where: { id, userId, deletedAt: null } });
    if (!item) throw new NotFoundException('Equipment not found');
    return item;
  }

  // ── Admin: customers ──

  async listCustomers(q: CustomerQueryDto) {
    const where: Prisma.UserWhereInput = {
      role: 'CUSTOMER',
      deletedAt: null,
      status: q.status,
      ...(q.search
        ? {
            OR: [
              { fullName: { contains: q.search, mode: 'insensitive' } },
              { phone: { contains: q.search.replace(/\s/g, '') } },
              { email: { contains: q.search, mode: 'insensitive' } },
            ],
          }
        : {}),
    };
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.user.findMany({
        where,
        orderBy: orderBy(q.sortBy, q.sortOrder, ['createdAt', 'fullName', 'lastLoginAt']),
        ...skipTake(q),
        include: { _count: { select: { bookings: true } } },
      }),
      this.prisma.user.count({ where }),
    ]);
    return paginate(
      rows.map((u) => ({ ...toPublicUser(u), lastLoginAt: u.lastLoginAt, bookingsCount: u._count.bookings })),
      total,
      q,
    );
  }

  async customerDetail(id: string) {
    const user = await this.prisma.user.findFirst({
      where: { id, role: 'CUSTOMER' },
      include: {
        addresses: { where: { deletedAt: null } },
        equipment: { where: { deletedAt: null } },
        bookings: { orderBy: { createdAt: 'desc' }, take: 20, include: { service: true, technician: true } },
        invoices: { orderBy: { issuedAt: 'desc' }, take: 20 },
        subscriptions: { include: { plan: true } },
      },
    });
    if (!user) throw new NotFoundException('Customer not found');
    const spent = await this.prisma.invoice.aggregate({ where: { customerId: id, status: { not: 'VOID' } }, _sum: { amountPaid: true } });
    const { addresses, equipment, bookings, invoices, subscriptions } = user;
    return {
      ...toPublicUser(user),
      lastLoginAt: user.lastLoginAt,
      totalPaid: spent._sum.amountPaid ?? 0,
      addresses,
      equipment,
      bookings,
      invoices,
      subscriptions,
    };
  }

  async setStatus(actorId: string, id: string, status: 'ACTIVE' | 'SUSPENDED') {
    const user = await this.prisma.user.update({ where: { id }, data: { status } });
    if (status === 'SUSPENDED') {
      await this.prisma.refreshToken.updateMany({ where: { userId: id, revokedAt: null }, data: { revokedAt: new Date() } });
    }
    await this.audit.log(actorId, `user.${status.toLowerCase()}`, 'User', id);
    return toPublicUser(user);
  }

  // ── Admin: staff ──

  async listStaff() {
    const staff = await this.prisma.user.findMany({
      where: { role: { in: STAFF_ROLES }, deletedAt: null },
      orderBy: { createdAt: 'asc' },
      include: { branch: true },
    });
    return staff.map((s) => ({ ...toPublicUser(s), lastLoginAt: s.lastLoginAt, branch: s.branch }));
  }

  private guardRoleChange(actorRole: Role, targetRole?: Role) {
    if (targetRole === 'SUPER_ADMIN' && actorRole !== 'SUPER_ADMIN') {
      throw new ForbiddenException('Only a super admin can grant super admin access');
    }
  }

  async createStaff(actor: { id: string; role: Role }, dto: CreateStaffDto) {
    this.guardRoleChange(actor.role, dto.role);
    const phone = normalizePhone(dto.phone);
    if (!isValidPhone(phone)) throw new BadRequestException('Invalid phone number');
    const user = await this.prisma.user.create({
      data: {
        fullName: dto.fullName.trim(),
        phone,
        email: dto.email.toLowerCase(),
        role: dto.role,
        branchId: dto.branchId,
        passwordHash: await bcrypt.hash(dto.password, 12),
        phoneVerifiedAt: new Date(),
      },
    });
    await this.audit.log(actor.id, 'staff.create', 'User', user.id, { role: dto.role });
    return toPublicUser(user);
  }

  async updateStaff(actor: { id: string; role: Role }, id: string, dto: UpdateStaffDto) {
    const target = await this.prisma.user.findFirst({ where: { id, role: { in: STAFF_ROLES } } });
    if (!target) throw new NotFoundException('Staff member not found');
    if (target.role === 'SUPER_ADMIN' && actor.role !== 'SUPER_ADMIN') throw new ForbiddenException('Cannot modify a super admin');
    this.guardRoleChange(actor.role, dto.role);
    if (id === actor.id && (dto.status === 'SUSPENDED' || (dto.role && dto.role !== target.role))) {
      throw new BadRequestException('You cannot suspend yourself or change your own role');
    }
    const user = await this.prisma.user.update({
      where: { id },
      data: {
        fullName: dto.fullName,
        role: dto.role,
        status: dto.status,
        branchId: dto.branchId,
        passwordHash: dto.password ? await bcrypt.hash(dto.password, 12) : undefined,
      },
    });
    if (dto.status === 'SUSPENDED' || dto.password) {
      await this.prisma.refreshToken.updateMany({ where: { userId: id, revokedAt: null }, data: { revokedAt: new Date() } });
    }
    await this.audit.log(actor.id, 'staff.update', 'User', id, { ...dto, password: dto.password ? '[changed]' : undefined });
    return toPublicUser(user);
  }
}
