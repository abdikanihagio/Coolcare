import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { CurrentUser } from '../common/decorators';
import type { AuthUser } from '../common/types';
import { AddressDto, EquipmentDto, RegisterDeviceDto, UpdateAddressDto, UpdateEquipmentDto, UpdateProfileDto } from './dto';
import { UsersService } from './users.service';

@ApiTags('Me (customer self-service)')
@ApiBearerAuth()
@Controller('me')
export class MeController {
  constructor(private readonly users: UsersService) {}

  @Get()
  me(@CurrentUser() user: AuthUser) {
    return this.users.me(user.id);
  }

  @Patch()
  update(@CurrentUser() user: AuthUser, @Body() dto: UpdateProfileDto) {
    return this.users.updateMe(user.id, dto);
  }

  @Delete()
  remove(@CurrentUser() user: AuthUser) {
    return this.users.deleteMe(user.id);
  }

  @Post('devices')
  registerDevice(@CurrentUser() user: AuthUser, @Body() dto: RegisterDeviceDto) {
    return this.users.registerDevice(user.id, dto);
  }

  @Delete('devices/:token')
  removeDevice(@CurrentUser() user: AuthUser, @Param('token') token: string) {
    return this.users.removeDevice(user.id, token);
  }

  // Addresses
  @Get('addresses')
  addresses(@CurrentUser() user: AuthUser) {
    return this.users.listAddresses(user.id);
  }

  @Post('addresses')
  createAddress(@CurrentUser() user: AuthUser, @Body() dto: AddressDto) {
    return this.users.createAddress(user.id, dto);
  }

  @Patch('addresses/:id')
  updateAddress(@CurrentUser() user: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateAddressDto) {
    return this.users.updateAddress(user.id, id, dto);
  }

  @Delete('addresses/:id')
  deleteAddress(@CurrentUser() user: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.users.deleteAddress(user.id, id);
  }

  // Equipment
  @Get('equipment')
  equipment(@CurrentUser() user: AuthUser) {
    return this.users.listEquipment(user.id);
  }

  @Post('equipment')
  createEquipment(@CurrentUser() user: AuthUser, @Body() dto: EquipmentDto) {
    return this.users.createEquipment(user.id, dto);
  }

  @Patch('equipment/:id')
  updateEquipment(@CurrentUser() user: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateEquipmentDto) {
    return this.users.updateEquipment(user.id, id, dto);
  }

  @Delete('equipment/:id')
  deleteEquipment(@CurrentUser() user: AuthUser, @Param('id', ParseUUIDPipe) id: string) {
    return this.users.deleteEquipment(user.id, id);
  }
}
