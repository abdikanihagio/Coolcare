import type { User } from '@prisma/client';

/** Strips secrets from a user record before it leaves the API. */
export function toPublicUser(user: User) {
  return {
    id: user.id,
    fullName: user.fullName,
    phone: user.phone,
    email: user.email,
    role: user.role,
    status: user.status,
    locale: user.locale,
    avatarUrl: user.avatarUrl,
    phoneVerified: !!user.phoneVerifiedAt,
    branchId: user.branchId,
    createdAt: user.createdAt,
  };
}

export type PublicUser = ReturnType<typeof toPublicUser>;
