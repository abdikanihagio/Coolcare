import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Post, Query } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { CurrentUser, Roles } from '../common/decorators';
import type { AuthUser } from '../common/types';
import { CreateStaffDto, CustomerQueryDto, UpdateStaffDto, UpdateUserStatusDto } from './dto';
import { UsersService } from './users.service';

@ApiTags('Admin · Customers')
@ApiBearerAuth()
@Roles('ADMIN', 'DISPATCHER', 'ACCOUNTANT')
@Controller('admin/customers')
export class AdminCustomersController {
  constructor(private readonly users: UsersService) {}

  @Get()
  list(@Query() q: CustomerQueryDto) {
    return this.users.listCustomers(q);
  }

  @Get(':id')
  detail(@Param('id', ParseUUIDPipe) id: string) {
    return this.users.customerDetail(id);
  }

  @Patch(':id/status')
  @Roles('ADMIN')
  status(@CurrentUser() actor: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateUserStatusDto) {
    return this.users.setStatus(actor.id, id, dto.status);
  }
}

@ApiTags('Admin · Staff')
@ApiBearerAuth()
@Roles('ADMIN')
@Controller('admin/staff')
export class AdminStaffController {
  constructor(private readonly users: UsersService) {}

  @Get()
  list() {
    return this.users.listStaff();
  }

  @Post()
  create(@CurrentUser() actor: AuthUser, @Body() dto: CreateStaffDto) {
    return this.users.createStaff(actor, dto);
  }

  @Patch(':id')
  update(@CurrentUser() actor: AuthUser, @Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateStaffDto) {
    return this.users.updateStaff(actor, id, dto);
  }
}
