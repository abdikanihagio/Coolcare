import { fireEvent, render, screen } from '@testing-library/react-native';
import { Button, Choice } from '../components/ui';

describe('UI components', () => {
  it('calls onPress and exposes a button role', () => {
    const onPress = jest.fn();
    render(<Button title="Confirm booking" onPress={onPress} />);
    fireEvent.press(screen.getByRole('button', { name: 'Confirm booking' }));
    expect(onPress).toHaveBeenCalledTimes(1);
  });

  it('does not fire when disabled', () => {
    const onPress = jest.fn();
    render(<Button title="Save" onPress={onPress} disabled />);
    fireEvent.press(screen.getByRole('button', { name: 'Save' }));
    expect(onPress).not.toHaveBeenCalled();
  });

  it('skips unavailable choices', () => {
    const onChange = jest.fn();
    render(
      <Choice
        value={null}
        onChange={onChange}
        options={[
          { value: 'MORNING', label: 'Morning' },
          { value: 'EVENING', label: 'Evening', disabled: true },
        ]}
      />,
    );
    fireEvent.press(screen.getByText('Evening'));
    fireEvent.press(screen.getByText('Morning'));
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenCalledWith('MORNING');
  });
});
