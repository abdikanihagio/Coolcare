import { addDaysIso, isStrongPassword, isValidPhone, normalizePhone, todayIso } from '../lib/format';
import { pick, translate } from '../i18n/core';
import en from '../i18n/en.json';
import so from '../i18n/so.json';

describe('phone helpers', () => {
  it('normalises local Somali numbers', () => {
    expect(normalizePhone('061 234 5678')).toBe('+252612345678');
    expect(normalizePhone('612345678')).toBe('+252612345678');
    expect(isValidPhone('61 234 5678')).toBe(true);
    expect(isValidPhone('12')).toBe(false);
  });
});

describe('password rule', () => {
  it('matches the API rule', () => {
    expect(isStrongPassword('Secret123')).toBe(true);
    expect(isStrongPassword('secret')).toBe(false);
    expect(isStrongPassword('12345678')).toBe(false);
  });
});

describe('dates', () => {
  it('uses Mogadishu time for today', () => {
    expect(todayIso(new Date('2026-10-22T22:00:00Z'))).toBe('2026-10-23');
    expect(addDaysIso('2026-12-31', 1)).toBe('2027-01-01');
  });
});

describe('translations', () => {
  it('has Somali copy for every English key', () => {
    const missing = Object.keys(en).filter((k) => !(so as Record<string, string>)[k]);
    expect(missing).toEqual([]);
  });

  it('interpolates and picks bilingual fields', () => {
    expect(translate('so', 'home.greeting', { name: 'Amina' })).toBe('Salaan, Amina');
    expect(pick({ nameEn: 'AC Repair', nameSo: 'Dayactirka AC' }, 'name', 'so')).toBe('Dayactirka AC');
    expect(pick({ nameEn: 'AC Repair', nameSo: '' }, 'name', 'so')).toBe('AC Repair');
  });
});
