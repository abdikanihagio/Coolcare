import { MaterialCommunityIcons } from '@expo/vector-icons';
import { forwardRef, useEffect, useRef, type ComponentProps, type ReactNode } from 'react';
import {
  ActivityIndicator,
  Animated,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type StyleProp,
  type TextInputProps,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ApiError } from '@/lib/api';
import { colors, radius, space, toneColors, type, type Tone } from '@/theme';

export type IconName = ComponentProps<typeof MaterialCommunityIcons>['name'];

export function errorText(err: unknown, t: (k: string) => string): string {
  if (err instanceof ApiError && err.status === 0) return t('err.network');
  return (err as Error)?.message || t('err.generic');
}

// ── Layout ──

export function Screen({
  children,
  scroll = true,
  refreshing,
  onRefresh,
  footer,
  padded = true,
  edges = ['bottom'],
}: {
  children: ReactNode;
  scroll?: boolean;
  refreshing?: boolean;
  onRefresh?: () => void;
  footer?: ReactNode;
  padded?: boolean;
  edges?: ('top' | 'bottom')[];
}) {
  const content = scroll ? (
    <ScrollView
      contentContainerStyle={[padded && styles.padded, { paddingBottom: footer ? space.lg : space.xxl }]}
      keyboardShouldPersistTaps="handled"
      refreshControl={onRefresh ? <RefreshControl refreshing={!!refreshing} onRefresh={onRefresh} tintColor={colors.brand} /> : undefined}
    >
      {children}
    </ScrollView>
  ) : (
    <View style={[{ flex: 1 }, padded && styles.padded]}>{children}</View>
  );
  return (
    <SafeAreaView style={styles.screen} edges={edges}>
      {content}
      {footer && <View style={styles.footer}>{footer}</View>}
    </SafeAreaView>
  );
}

export function Card({ children, style, onPress }: { children: ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  if (onPress) {
    return (
      <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && { backgroundColor: colors.surface }, style]} accessibilityRole="button">
        {children}
      </Pressable>
    );
  }
  return <View style={[styles.card, style]}>{children}</View>;
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <View style={styles.sectionTitle}>
      <Text style={type.h3} accessibilityRole="header">
        {children}
      </Text>
      {action}
    </View>
  );
}

export function Row({ children, style }: { children: ReactNode; style?: StyleProp<ViewStyle> }) {
  return <View style={[{ flexDirection: 'row', alignItems: 'center', gap: space.sm }, style]}>{children}</View>;
}

// ── Controls ──

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';

export function Button({
  title,
  onPress,
  variant = 'primary',
  loading,
  disabled,
  icon,
  style,
  accessibilityHint,
}: {
  title: string;
  onPress: () => void;
  variant?: Variant;
  loading?: boolean;
  disabled?: boolean;
  icon?: IconName;
  style?: StyleProp<ViewStyle>;
  accessibilityHint?: string;
}) {
  const v = VARIANTS[variant];
  const off = disabled || loading;
  return (
    <Pressable
      onPress={onPress}
      disabled={off}
      accessibilityRole="button"
      accessibilityState={{ disabled: !!off, busy: !!loading }}
      accessibilityHint={accessibilityHint}
      style={({ pressed }) => [styles.button, { backgroundColor: v.bg, borderColor: v.border }, pressed && { opacity: 0.85 }, off && { opacity: 0.5 }, style]}
    >
      {loading ? (
        <ActivityIndicator color={v.fg} />
      ) : (
        <>
          {icon && <MaterialCommunityIcons name={icon} size={20} color={v.fg} />}
          <Text style={[styles.buttonText, { color: v.fg }]}>{title}</Text>
        </>
      )}
    </Pressable>
  );
}

const VARIANTS: Record<Variant, { bg: string; fg: string; border: string }> = {
  primary: { bg: colors.brand, fg: colors.white, border: colors.brand },
  secondary: { bg: colors.white, fg: colors.navy, border: colors.line },
  ghost: { bg: 'transparent', fg: colors.brand, border: 'transparent' },
  danger: { bg: colors.white, fg: colors.bad, border: colors.line },
};

export const Field = forwardRef<TextInput, TextInputProps & { label: string; hint?: string; error?: string; optional?: boolean; optionalLabel?: string }>(
  function Field({ label, hint, error, optional, optionalLabel = 'optional', style, ...rest }, ref) {
    return (
      <View style={{ gap: 6, marginBottom: space.lg }}>
        <Text style={type.label}>
          {label}
          {optional && <Text style={{ color: colors.muted, fontWeight: '400' }}> ({optionalLabel})</Text>}
        </Text>
        <TextInput
          ref={ref}
          placeholderTextColor={colors.faint}
          accessibilityLabel={label}
          style={[styles.input, rest.multiline && { minHeight: 96, paddingTop: 12, textAlignVertical: 'top' }, !!error && { borderColor: colors.bad }, style]}
          {...rest}
        />
        {error ? <Text style={[type.small, { color: colors.bad }]}>{error}</Text> : hint ? <Text style={type.small}>{hint}</Text> : null}
      </View>
    );
  },
);

/** Single-choice chips, used for time slots, priority and filters. */
export function Choice<T extends string>({
  options,
  value,
  onChange,
  disabled,
}: {
  options: { value: T; label: string; sub?: string; disabled?: boolean }[];
  value: T | null;
  onChange: (v: T) => void;
  disabled?: boolean;
}) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }} accessibilityRole="radiogroup">
      {options.map((o) => {
        const selected = o.value === value;
        const off = disabled || o.disabled;
        return (
          <Pressable
            key={o.value}
            onPress={() => !off && onChange(o.value)}
            accessibilityRole="radio"
            accessibilityState={{ selected, disabled: !!off }}
            style={[styles.choice, selected && styles.choiceOn, off && { opacity: 0.45 }]}
          >
            <Text style={[styles.choiceText, selected && { color: colors.brandDark }]}>{o.label}</Text>
            {o.sub && <Text style={[type.small, selected && { color: colors.brandDark }]}>{o.sub}</Text>}
          </Pressable>
        );
      })}
    </View>
  );
}

export function ListItem({
  icon,
  title,
  subtitle,
  onPress,
  right,
  danger,
}: {
  icon?: IconName;
  title: string;
  subtitle?: string;
  onPress?: () => void;
  right?: ReactNode;
  danger?: boolean;
}) {
  return (
    <Pressable onPress={onPress} disabled={!onPress} accessibilityRole={onPress ? 'button' : undefined} style={({ pressed }) => [styles.listItem, pressed && { backgroundColor: colors.surface }]}>
      {icon && <MaterialCommunityIcons name={icon} size={22} color={danger ? colors.bad : colors.navy700} />}
      <View style={{ flex: 1 }}>
        <Text style={[type.body, danger && { color: colors.bad }]}>{title}</Text>
        {subtitle && <Text style={type.small}>{subtitle}</Text>}
      </View>
      {right ?? (onPress && <MaterialCommunityIcons name="chevron-right" size={22} color={colors.faint} />)}
    </Pressable>
  );
}

// ── Display ──

export function Pill({ label, tone = 'neutral' }: { label: string; tone?: Tone }) {
  const c = toneColors[tone];
  return (
    <View style={[styles.pill, { backgroundColor: c.bg }]}>
      <Text style={{ color: c.fg, fontSize: 12, fontWeight: '600' }}>{label}</Text>
    </View>
  );
}

export function ServiceIcon({ icon, size = 44 }: { icon?: string; size?: number }) {
  const map: Record<string, IconName> = {
    snowflake: 'snowflake',
    fridge: 'fridge-outline',
    tools: 'tools',
    'calendar-check': 'calendar-check-outline',
    building: 'office-building-outline',
  };
  return (
    <View style={{ width: size, height: size, borderRadius: radius.md, backgroundColor: colors.brandSoft, alignItems: 'center', justifyContent: 'center' }}>
      <MaterialCommunityIcons name={map[icon ?? 'snowflake'] ?? 'snowflake'} size={size * 0.52} color={colors.brand} />
    </View>
  );
}

export function EmptyState({ icon = 'snowflake', title, body, action }: { icon?: IconName; title: string; body?: string; action?: ReactNode }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 48, paddingHorizontal: space.xl, gap: space.md }}>
      <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: colors.brandSoft, alignItems: 'center', justifyContent: 'center' }}>
        <MaterialCommunityIcons name={icon} size={30} color={colors.brand} />
      </View>
      <Text style={[type.h3, { textAlign: 'center' }]}>{title}</Text>
      {body && <Text style={[type.small, { textAlign: 'center', maxWidth: 280 }]}>{body}</Text>}
      {action}
    </View>
  );
}

export function ErrorView({ message, onRetry, retryLabel }: { message: string; onRetry?: () => void; retryLabel: string }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 48, gap: space.md }} accessibilityRole="alert">
      <MaterialCommunityIcons name="wifi-alert" size={32} color={colors.muted} />
      <Text style={[type.body, { textAlign: 'center', color: colors.navy700, maxWidth: 300 }]}>{message}</Text>
      {onRetry && <Button title={retryLabel} variant="secondary" onPress={onRetry} />}
    </View>
  );
}

export function Skeleton({ height = 16, width = '100%', style }: { height?: number; width?: number | `${number}%`; style?: StyleProp<ViewStyle> }) {
  const opacity = useRef(new Animated.Value(0.5)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 700, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.5, duration: 700, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);
  return <Animated.View style={[{ height, width, borderRadius: radius.sm, backgroundColor: '#E6ECF2', opacity }, style]} accessibilityElementsHidden />;
}

export function Banner({ tone = 'brand', icon, children }: { tone?: Tone; icon?: IconName; children: ReactNode }) {
  const c = toneColors[tone];
  return (
    <View style={{ flexDirection: 'row', gap: space.sm, backgroundColor: c.bg, padding: space.md, borderRadius: radius.md, alignItems: 'flex-start' }}>
      {icon && <MaterialCommunityIcons name={icon} size={18} color={c.fg} style={{ marginTop: 2 }} />}
      <Text style={{ flex: 1, color: c.fg, fontSize: 14, lineHeight: 20 }}>{children}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.surface },
  padded: { padding: space.lg },
  footer: { padding: space.lg, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.line, backgroundColor: colors.white },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, padding: space.lg, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.line },
  sectionTitle: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: space.xl, marginBottom: space.md },
  button: { minHeight: 52, borderRadius: radius.md, paddingHorizontal: space.xl, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: space.sm, borderWidth: 1 },
  buttonText: { fontSize: 16, fontWeight: '600' },
  input: { minHeight: 52, borderWidth: 1, borderColor: colors.line, borderRadius: radius.md, paddingHorizontal: space.lg, fontSize: 16, color: colors.navy, backgroundColor: colors.white },
  choice: { paddingVertical: 10, paddingHorizontal: 14, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.white, minWidth: 96 },
  choiceOn: { borderColor: colors.brand, backgroundColor: colors.brandSoft },
  choiceText: { fontSize: 15, fontWeight: '600', color: colors.navy },
  pill: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill },
  listItem: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingVertical: 14, paddingHorizontal: space.lg, backgroundColor: colors.white },
});
