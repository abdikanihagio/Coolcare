import { MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Text, View } from 'react-native';
import { pick, useI18n } from '@/i18n';
import { day } from '@/lib/format';
import type { Booking } from '@/lib/types';
import { colors, space, statusTone, type } from '@/theme';
import { Card, Pill, ServiceIcon } from './ui';

export function BookingCard({ booking }: { booking: Booking }) {
  const { t, locale } = useI18n();
  return (
    <Card onPress={() => router.push(`/booking/${booking.id}`)} style={{ gap: space.md }}>
      <View style={{ flexDirection: 'row', gap: space.md, alignItems: 'center' }}>
        <ServiceIcon icon={booking.service.category?.icon} size={40} />
        <View style={{ flex: 1 }}>
          <Text style={type.h3} numberOfLines={1}>
            {pick(booking.service, 'name', locale)}
          </Text>
          <Text style={type.small}>
            {day(booking.scheduledDate, locale)} · {t(`slot.${booking.timeSlot}`)}
          </Text>
        </View>
        <MaterialCommunityIcons name="chevron-right" size={22} color={colors.faint} />
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Pill label={t(`status.${booking.status}`)} tone={statusTone[booking.status]} />
        <Text style={[type.small, { fontVariant: ['tabular-nums'] }]}>{booking.reference}</Text>
      </View>
      {booking.hasPendingQuote && (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <MaterialCommunityIcons name="file-document-edit-outline" size={16} color={colors.warn} />
          <Text style={{ color: '#B45309', fontWeight: '600', fontSize: 13 }}>{t('bk.quoteWaiting')}</Text>
        </View>
      )}
    </Card>
  );
}
