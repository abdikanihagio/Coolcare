import { useRef } from 'react';
import { Pressable, Text, TextInput, View } from 'react-native';
import { colors, radius } from '@/theme';

/** Six-box OTP input backed by one hidden TextInput (supports SMS autofill). */
export function CodeInput({ value, onChange, label }: { value: string; onChange: (v: string) => void; label: string }) {
  const ref = useRef<TextInput>(null);
  return (
    <Pressable onPress={() => ref.current?.focus()} accessibilityLabel={label}>
      <View style={{ flexDirection: 'row', gap: 8, justifyContent: 'space-between' }}>
        {Array.from({ length: 6 }).map((_, i) => {
          const active = i === Math.min(value.length, 5);
          return (
            <View
              key={i}
              style={{
                flex: 1,
                aspectRatio: 0.85,
                maxWidth: 56,
                borderRadius: radius.md,
                borderWidth: active ? 2 : 1,
                borderColor: active ? colors.brand : colors.line,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: colors.white,
              }}
            >
              <Text style={{ fontSize: 24, fontWeight: '700', color: colors.navy }}>{value[i] ?? ''}</Text>
            </View>
          );
        })}
      </View>
      <TextInput
        ref={ref}
        value={value}
        onChangeText={(v) => onChange(v.replace(/\D/g, '').slice(0, 6))}
        keyboardType="number-pad"
        textContentType="oneTimeCode"
        autoComplete="sms-otp"
        maxLength={6}
        autoFocus
        style={{ position: 'absolute', opacity: 0, height: 1, width: 1 }}
      />
    </Pressable>
  );
}
