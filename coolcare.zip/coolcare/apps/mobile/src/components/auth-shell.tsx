import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { ReactNode } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, space, type } from '@/theme';

export function AuthShell({ title, subtitle, children, brand = false }: { title: string; subtitle?: string; children: ReactNode; brand?: boolean }) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }} edges={brand ? ['top', 'bottom'] : ['bottom']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: space.xl, flexGrow: 1 }} keyboardShouldPersistTaps="handled">
          {brand && (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, marginTop: space.xl, marginBottom: space.xxl }}>
              <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: colors.brand, alignItems: 'center', justifyContent: 'center' }}>
                <MaterialCommunityIcons name="snowflake" size={24} color={colors.white} />
              </View>
              <Text style={{ fontSize: 22, fontWeight: '800', color: colors.navy }}>CoolCare</Text>
            </View>
          )}
          <Text style={type.title} accessibilityRole="header">
            {title}
          </Text>
          {subtitle && <Text style={[type.body, { color: colors.muted, marginTop: space.sm, marginBottom: space.xl }]}>{subtitle}</Text>}
          {children}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
