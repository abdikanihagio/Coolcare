/** CoolCare mobile design tokens. System fonts keep the app light on low-end phones. */
export const colors = {
  brand: '#1677C8',
  brandDark: '#105FA6',
  brandSoft: '#E8F4FC',
  navy: '#102A43',
  navy700: '#284B6E',
  muted: '#627D98',
  faint: '#9FB3C8',
  line: '#E2E8EF',
  surface: '#F5F8FB',
  white: '#FFFFFF',
  ok: '#16A34A',
  okSoft: '#ECFDF3',
  warn: '#D97706',
  warnSoft: '#FFFBEB',
  bad: '#DC2626',
  badSoft: '#FEF2F2',
};

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 };
export const radius = { sm: 8, md: 12, lg: 16, pill: 999 };

export const type = {
  title: { fontSize: 26, fontWeight: '700' as const, color: colors.navy, letterSpacing: -0.3 },
  h2: { fontSize: 19, fontWeight: '700' as const, color: colors.navy },
  h3: { fontSize: 16, fontWeight: '600' as const, color: colors.navy },
  body: { fontSize: 15, lineHeight: 22, color: colors.navy },
  small: { fontSize: 13, lineHeight: 18, color: colors.muted },
  label: { fontSize: 14, fontWeight: '600' as const, color: colors.navy700 },
};

export type Tone = 'neutral' | 'brand' | 'ok' | 'warn' | 'bad';
export const toneColors: Record<Tone, { bg: string; fg: string }> = {
  neutral: { bg: '#EEF2F6', fg: colors.navy700 },
  brand: { bg: colors.brandSoft, fg: colors.brandDark },
  ok: { bg: colors.okSoft, fg: '#15803D' },
  warn: { bg: colors.warnSoft, fg: '#B45309' },
  bad: { bg: colors.badSoft, fg: '#B91C1C' },
};

export const statusTone: Record<string, Tone> = {
  PENDING: 'warn',
  CONFIRMED: 'brand',
  ASSIGNED: 'brand',
  ON_THE_WAY: 'brand',
  IN_PROGRESS: 'brand',
  AWAITING_APPROVAL: 'warn',
  COMPLETED: 'ok',
  CANCELLED: 'bad',
};
