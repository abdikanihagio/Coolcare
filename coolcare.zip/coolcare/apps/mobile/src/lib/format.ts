import type { Locale } from '@/i18n/core';

export const TIMEZONE = 'Africa/Mogadishu';

export function money(value: number | string | null | undefined, currency = 'USD', locale: Locale = 'en'): string {
  const n = Number(value ?? 0);
  try {
    return new Intl.NumberFormat(locale === 'so' ? 'so-SO' : 'en-US', { style: 'currency', currency }).format(n);
  } catch {
    return `$${n.toFixed(2)}`;
  }
}

export function day(value: string | null | undefined, locale: Locale = 'en'): string {
  if (!value) return '';
  const d = new Date(`${value.slice(0, 10)}T12:00:00Z`);
  try {
    return new Intl.DateTimeFormat(locale === 'so' ? 'so-SO' : 'en-GB', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' }).format(d);
  } catch {
    return value.slice(0, 10);
  }
}

export function dateTime(value: string | null | undefined, locale: Locale = 'en'): string {
  if (!value) return '';
  try {
    return new Intl.DateTimeFormat(locale === 'so' ? 'so-SO' : 'en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: TIMEZONE }).format(new Date(value));
  } catch {
    return new Date(value).toLocaleString();
  }
}

/** Today's date (YYYY-MM-DD) in Mogadishu. */
export function todayIso(at = new Date()): string {
  const local = new Date(at.getTime() + 3 * 3600_000); // Africa/Mogadishu is UTC+3 with no DST
  return local.toISOString().slice(0, 10);
}

export function addDaysIso(iso: string, days: number): string {
  const d = new Date(`${iso}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** Normalises Somali numbers to +252… (mirrors the API). */
export function normalizePhone(input: string): string {
  const raw = input.trim();
  const digits = raw.replace(/\D/g, '');
  if (!digits) return raw;
  if (raw.startsWith('+')) return `+${digits}`;
  if (digits.startsWith('00')) return `+${digits.slice(2)}`;
  if (digits.startsWith('252') && digits.length >= 11) return `+${digits}`;
  if (digits.startsWith('0')) return `+252${digits.slice(1)}`;
  return `+252${digits}`;
}

export const isValidPhone = (p: string) => /^\+\d{9,15}$/.test(normalizePhone(p));
export const isStrongPassword = (p: string) => /^(?=.*[A-Za-z])(?=.*\d).{8,72}$/.test(p);
