import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { api } from './api';

let currentToken: string | null = null;

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

/**
 * Registers the device's native push token (FCM on Android) with the API.
 * iOS: the native token is an APNs token; to deliver via FCM on iOS, add the
 * Firebase iOS SDK (see docs/PUSH_NOTIFICATIONS.md).
 */
export async function registerForPush(): Promise<void> {
  if (!Device.isDevice) return;
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'CoolCare updates',
      importance: Notifications.AndroidImportance.HIGH,
      lightColor: '#1677C8',
    });
  }
  const existing = await Notifications.getPermissionsAsync();
  let status = existing.status;
  if (status !== 'granted') status = (await Notifications.requestPermissionsAsync()).status;
  if (status !== 'granted') return;

  const token = await Notifications.getDevicePushTokenAsync();
  currentToken = String(token.data);
  await api('/me/devices', { body: { token: currentToken, platform: Platform.OS === 'ios' ? 'ios' : 'android' } });
}

export async function unregisterPush(): Promise<void> {
  if (!currentToken) return;
  await api(`/me/devices/${encodeURIComponent(currentToken)}`, { method: 'DELETE' });
  currentToken = null;
}
