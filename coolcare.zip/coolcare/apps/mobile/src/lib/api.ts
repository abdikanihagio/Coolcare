import Constants from 'expo-constants';
import * as SecureStore from 'expo-secure-store';

export const API_URL = (process.env.EXPO_PUBLIC_API_URL ?? (Constants.expoConfig?.extra?.apiUrl as string | undefined) ?? 'http://localhost:4000/api/v1').replace(/\/$/, '');

const TOKENS_KEY = 'coolcare.tokens';

export interface Tokens {
  accessToken: string;
  refreshToken: string;
}

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

let memoryTokens: Tokens | null = null;
let onSignedOut: (() => void) | null = null;

export function setSignedOutHandler(fn: () => void) {
  onSignedOut = fn;
}

export async function loadTokens(): Promise<Tokens | null> {
  if (memoryTokens) return memoryTokens;
  const raw = await SecureStore.getItemAsync(TOKENS_KEY);
  memoryTokens = raw ? (JSON.parse(raw) as Tokens) : null;
  return memoryTokens;
}

export async function saveTokens(tokens: Tokens | null) {
  memoryTokens = tokens;
  if (tokens) await SecureStore.setItemAsync(TOKENS_KEY, JSON.stringify(tokens));
  else await SecureStore.deleteItemAsync(TOKENS_KEY);
}

let refreshing: Promise<boolean> | null = null;

async function refresh(): Promise<boolean> {
  const tokens = await loadTokens();
  if (!tokens) return false;
  try {
    const res = await fetch(`${API_URL}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken: tokens.refreshToken }),
    });
    if (!res.ok) throw new Error('refresh failed');
    const body = await res.json();
    await saveTokens({ accessToken: body.tokens.accessToken, refreshToken: body.tokens.refreshToken });
    return true;
  } catch {
    await saveTokens(null);
    onSignedOut?.();
    return false;
  }
}

function messageOf(body: unknown, status: number): string {
  const m = (body as { message?: unknown } | null)?.message;
  if (Array.isArray(m)) return m.join('\n');
  if (typeof m === 'string') return m;
  return `Request failed (${status})`;
}

type Query = Record<string, string | number | boolean | undefined | null>;

export async function api<T = unknown>(
  path: string,
  opts: { method?: string; body?: unknown; query?: Query; form?: FormData; auth?: boolean } = {},
  retry = true,
): Promise<T> {
  const tokens = opts.auth === false ? null : await loadTokens();
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (tokens) headers.Authorization = `Bearer ${tokens.accessToken}`;
  if (opts.body !== undefined) headers['Content-Type'] = 'application/json';

  let url = `${API_URL}${path}`;
  if (opts.query) {
    const qs = Object.entries(opts.query)
      .filter(([, v]) => v !== undefined && v !== null && v !== '')
      .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`)
      .join('&');
    if (qs) url += `?${qs}`;
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20_000);
  let res: Response;
  try {
    res = await fetch(url, {
      method: opts.method ?? (opts.body !== undefined || opts.form ? 'POST' : 'GET'),
      headers,
      body: opts.form ?? (opts.body !== undefined ? JSON.stringify(opts.body) : undefined),
      signal: controller.signal,
    });
  } catch {
    throw new ApiError(0, 'NETWORK');
  } finally {
    clearTimeout(timer);
  }

  if (res.status === 401 && retry && tokens) {
    refreshing ??= refresh().finally(() => (refreshing = null));
    if (await refreshing) return api<T>(path, opts, false);
  }

  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) throw new ApiError(res.status, messageOf(body, res.status));
  return body as T;
}

/** Uploads a local image (from expo-image-picker) and returns its stored URL and key. */
export async function uploadImage(uri: string, folder: 'bookings' | 'avatars' = 'bookings') {
  const name = uri.split('/').pop() ?? 'photo.jpg';
  const ext = name.split('.').pop()?.toLowerCase();
  const type = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : ext === 'heic' ? 'image/heic' : 'image/jpeg';
  const form = new FormData();
  // React Native's FormData accepts { uri, name, type } file descriptors
  form.append('file', { uri, name, type } as unknown as Blob);
  return api<{ url: string; key: string }>(`/uploads/image?folder=${folder}`, { method: 'POST', form });
}
