import { useQueryClient } from '@tanstack/react-query';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api, loadTokens, saveTokens, setSignedOutHandler, type Tokens } from './api';
import { registerForPush, unregisterPush } from './push';
import type { User } from './types';

type AuthResult = { requiresOtp: true; phone: string } | { requiresOtp: false; user: User; tokens: Tokens };

interface AuthValue {
  user: User | null;
  ready: boolean;
  login: (phone: string, password: string) => Promise<AuthResult>;
  register: (input: { fullName: string; phone: string; email?: string; password: string; locale: 'en' | 'so' }) => Promise<AuthResult>;
  verifyOtp: (phone: string, code: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  setUser: (u: User) => void;
}

const Ctx = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const qc = useQueryClient();

  const clear = useCallback(() => {
    setUser(null);
    qc.clear();
  }, [qc]);

  useEffect(() => {
    setSignedOutHandler(clear);
    (async () => {
      try {
        if (await loadTokens()) {
          setUser(await api<User>('/me'));
          registerForPush().catch(() => undefined);
        }
      } catch {
        await saveTokens(null);
      } finally {
        setReady(true);
      }
    })();
  }, [clear]);

  const startSession = useCallback(async (result: AuthResult) => {
    if (!result.requiresOtp) {
      await saveTokens(result.tokens);
      setUser(result.user);
      registerForPush().catch(() => undefined);
    }
    return result;
  }, []);

  const login = useCallback(
    async (phone: string, password: string) => startSession(await api<AuthResult>('/auth/login', { body: { identifier: phone, password }, auth: false })),
    [startSession],
  );

  const register = useCallback(
    async (input: { fullName: string; phone: string; email?: string; password: string; locale: 'en' | 'so' }) =>
      startSession(await api<AuthResult>('/auth/register', { body: input, auth: false })),
    [startSession],
  );

  const verifyOtp = useCallback(
    async (phone: string, code: string) => {
      const res = await api<{ user: User; tokens: Tokens }>('/auth/otp/verify', { body: { phone, code }, auth: false });
      await startSession({ requiresOtp: false, ...res });
    },
    [startSession],
  );

  const logout = useCallback(async () => {
    const tokens = await loadTokens();
    await unregisterPush().catch(() => undefined);
    if (tokens) await api('/auth/logout', { body: { refreshToken: tokens.refreshToken }, auth: false }).catch(() => undefined);
    await saveTokens(null);
    clear();
  }, [clear]);

  const refreshUser = useCallback(async () => setUser(await api<User>('/me')), []);

  const value = useMemo(
    () => ({ user, ready, login, register, verifyOtp, logout, refreshUser, setUser }),
    [user, ready, login, register, verifyOtp, logout, refreshUser],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
