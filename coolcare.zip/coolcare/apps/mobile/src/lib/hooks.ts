import { useQuery } from '@tanstack/react-query';
import { api } from './api';
import type { Address, Category, Equipment, PublicSettings } from './types';

export const useCatalog = () =>
  useQuery({ queryKey: ['catalog'], queryFn: () => api<Category[]>('/catalog/categories', { auth: false }), staleTime: 5 * 60_000 });

export const usePublicSettings = () =>
  useQuery({ queryKey: ['settings'], queryFn: () => api<PublicSettings>('/settings/public', { auth: false }), staleTime: 10 * 60_000 });

export const useAddresses = () => useQuery({ queryKey: ['addresses'], queryFn: () => api<Address[]>('/me/addresses') });

export const useEquipment = () => useQuery({ queryKey: ['equipment'], queryFn: () => api<Equipment[]>('/me/equipment') });
