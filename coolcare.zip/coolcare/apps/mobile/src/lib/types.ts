export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'ASSIGNED' | 'ON_THE_WAY' | 'IN_PROGRESS' | 'AWAITING_APPROVAL' | 'COMPLETED' | 'CANCELLED';
export type Slot = 'MORNING' | 'AFTERNOON' | 'EVENING';

export interface User {
  id: string;
  fullName: string;
  phone: string;
  email: string | null;
  locale: 'en' | 'so';
  phoneVerified: boolean;
  avatarUrl?: string | null;
}

export interface Service {
  id: string;
  slug: string;
  nameEn: string;
  nameSo: string;
  descriptionEn?: string | null;
  descriptionSo?: string | null;
  basePrice: string;
  priceType: 'FIXED' | 'STARTING_FROM' | 'INSPECTION_REQUIRED';
  durationMinutes: number;
  categoryId: string;
}

export interface Category {
  id: string;
  slug: string;
  nameEn: string;
  nameSo: string;
  descriptionEn?: string | null;
  descriptionSo?: string | null;
  icon: string;
  services: Service[];
}

export interface Address {
  id: string;
  label: string;
  district: string;
  neighborhood?: string | null;
  street?: string | null;
  landmark?: string | null;
  details?: string | null;
  latitude?: string | number | null;
  longitude?: string | number | null;
  isDefault: boolean;
}

export interface Equipment {
  id: string;
  type: string;
  brand?: string | null;
  model?: string | null;
  capacity?: string | null;
  location?: string | null;
  notes?: string | null;
}

export interface QuoteItem {
  kind: string;
  description: string;
  quantity: string;
  unitPrice: string;
  total: string;
}

export interface Quote {
  id: string;
  number: string;
  status: 'SENT' | 'ACCEPTED' | 'REJECTED' | 'EXPIRED' | 'DRAFT';
  currency: string;
  subtotal: string;
  discount: string;
  taxAmount: string;
  total: string;
  notes?: string | null;
  validUntil?: string | null;
  items: QuoteItem[];
}

export interface Payment {
  id: string;
  amount: string;
  method: string;
  status: 'PENDING' | 'COMPLETED' | 'FAILED' | 'REFUNDED';
  reference?: string | null;
  paidAt: string;
}

export interface Invoice {
  id: string;
  number: string;
  currency: string;
  total: string;
  amountPaid: string;
  status: 'UNPAID' | 'PARTIALLY_PAID' | 'PAID' | 'VOID';
  payments: Payment[];
}

export interface Booking {
  id: string;
  reference: string;
  status: BookingStatus;
  priority: string;
  scheduledDate: string;
  timeSlot: Slot;
  unitCount: number;
  problemDescription?: string | null;
  addressText: string;
  estimatedPrice?: string | null;
  rating?: number | null;
  review?: string | null;
  createdAt: string;
  hasPendingQuote?: boolean;
  service: Service & { category?: { icon?: string; nameEn?: string; nameSo?: string } };
  technician?: { id?: string; fullName: string; phone?: string; photoUrl?: string | null; rating?: string } | null;
  history?: { id: string; toStatus: BookingStatus; note?: string | null; createdAt: string }[];
  photos?: { id: string; url: string; kind: string }[];
  quotes?: Quote[];
  invoice?: Invoice | null;
}

export interface Notification {
  id: string;
  type: string;
  title: string;
  body: string;
  data?: { bookingId?: string; invoiceId?: string } | null;
  readAt: string | null;
  createdAt: string;
}

export interface Plan {
  id: string;
  nameEn: string;
  nameSo: string;
  descriptionEn?: string | null;
  descriptionSo?: string | null;
  price: string;
  currency: string;
  durationMonths: number;
  visitsPerYear: number;
  maxUnits: number;
}

export interface Subscription {
  id: string;
  status: 'PENDING' | 'ACTIVE' | 'PAUSED' | 'CANCELLED' | 'EXPIRED';
  nextVisitDate?: string | null;
  plan: Plan;
}

export interface PublicSettings {
  companyName: string;
  supportPhone: string;
  supportWhatsapp: string;
  supportEmail: string;
  currency: string;
  bookingLeadHours: number;
  emergencySurcharge: number;
  paymentMethods: string[];
  mobileMoneyInstructionsEn: string;
  mobileMoneyInstructionsSo: string;
  serviceDistricts: string[];
  allowCustomerCancellation: boolean;
}

export interface Paginated<T> {
  data: T[];
  meta: { page: number; pageSize: number; total: number; totalPages: number };
}
