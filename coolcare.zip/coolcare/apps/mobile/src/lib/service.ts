import type { Locale } from '@/i18n/core';
import { money } from './format';
import type { Service } from './types';

export function priceLabel(s: Service, t: (k: string, v?: Record<string, string | number>) => string, locale: Locale) {
  if (s.priceType === 'INSPECTION_REQUIRED') return t('svc.inspection');
  const price = money(s.basePrice, 'USD', locale);
  return s.priceType === 'FIXED' ? price : t('svc.from', { price });
}
