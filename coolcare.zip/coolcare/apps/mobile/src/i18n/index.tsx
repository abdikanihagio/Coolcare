import AsyncStorage from '@react-native-async-storage/async-storage';
import { getLocales } from 'expo-localization';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { I18nManager } from 'react-native';
import { DICTS, LOCALE_RTL, pick, translate, type Locale } from './core';

export { pick, translate };
export type { Locale };

const KEY = 'coolcare.locale';

interface I18nValue {
  locale: Locale;
  ready: boolean;
  /** True once the user has explicitly chosen a language (onboarding). */
  chosen: boolean;
  setLocale: (l: Locale) => Promise<void>;
  t: (key: string, vars?: Record<string, string | number>) => string;
}

const Ctx = createContext<I18nValue | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const deviceLang = getLocales()[0]?.languageCode;
  const [locale, setLocaleState] = useState<Locale>(deviceLang === 'so' ? 'so' : 'en');
  const [ready, setReady] = useState(false);
  const [chosen, setChosen] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then((saved) => {
        if (saved && saved in DICTS) {
          setLocaleState(saved as Locale);
          setChosen(true);
        }
      })
      .finally(() => setReady(true));
  }, []);

  useEffect(() => {
    // Keep layout direction in sync with the language (takes effect after reload for RTL changes)
    I18nManager.allowRTL(LOCALE_RTL[locale]);
  }, [locale]);

  const setLocale = useCallback(async (l: Locale) => {
    setLocaleState(l);
    setChosen(true);
    await AsyncStorage.setItem(KEY, l);
  }, []);

  const t = useCallback((key: string, vars?: Record<string, string | number>) => translate(locale, key, vars), [locale]);
  const value = useMemo(() => ({ locale, ready, chosen, setLocale, t }), [locale, ready, chosen, setLocale, t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useI18n must be used inside I18nProvider');
  return ctx;
}
