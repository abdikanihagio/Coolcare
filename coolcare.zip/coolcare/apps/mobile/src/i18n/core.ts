import en from './en.json';
import so from './so.json';

export type Locale = 'en' | 'so';
export const DICTS: Record<Locale, Record<string, string>> = { en, so };
/** Both supported languages are left-to-right. Add RTL locales (e.g. Arabic) here and in LOCALE_RTL. */
export const LOCALE_RTL: Record<Locale, boolean> = { en: false, so: false };

export function translate(locale: Locale, key: string, vars?: Record<string, string | number>): string {
  const template = DICTS[locale][key] ?? DICTS.en[key] ?? key;
  return vars ? template.replace(/\{(\w+)\}/g, (m, k: string) => (vars[k] !== undefined ? String(vars[k]) : m)) : template;
}

/** Picks the Somali or English variant of a bilingual API field (nameEn/nameSo…). */
export function pick(row: object | null | undefined, field: string, locale: Locale): string {
  if (!row) return '';
  const r = row as Record<string, unknown>;
  const value = locale === 'so' && r[`${field}So`] ? r[`${field}So`] : r[`${field}En`];
  return String(value ?? '');
}
