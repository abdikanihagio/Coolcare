import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Alert, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { isStrongPassword } from '@/lib/format';
import { AuthShell } from '@/components/auth-shell';
import { CodeInput } from '@/components/code-input';
import { Banner, Button, errorText, Field } from '@/components/ui';
import { space } from '@/theme';

export default function Reset() {
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const { t } = useI18n();
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!isStrongPassword(password)) return setError(t('err.password'));
    setError('');
    setLoading(true);
    try {
      await api('/auth/password/reset', { body: { phone, code, newPassword: password }, auth: false });
      Alert.alert(t('common.done'), t('auth.resetDone'));
      router.dismissTo('/login');
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthShell title={t('auth.resetTitle')} subtitle={t('auth.verifySub', { phone })}>
      <View style={{ marginBottom: space.xl }}>
        <CodeInput label={t('auth.code')} value={code} onChange={setCode} />
      </View>
      <Field label={t('auth.newPassword')} secureTextEntry autoComplete="new-password" hint={t('auth.passwordHint')} value={password} onChangeText={setPassword} />
      {!!error && (
        <View style={{ marginBottom: space.lg }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}
      <Button title={t('auth.resetBtn')} onPress={submit} loading={loading} disabled={code.length !== 6} />
    </AuthShell>
  );
}
