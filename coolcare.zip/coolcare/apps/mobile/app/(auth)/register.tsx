import { Link, router } from 'expo-router';
import { useState } from 'react';
import { Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { useAuth } from '@/lib/auth';
import { isStrongPassword, isValidPhone, normalizePhone } from '@/lib/format';
import { AuthShell } from '@/components/auth-shell';
import { Banner, Button, errorText, Field } from '@/components/ui';
import { colors, space, type } from '@/theme';

export default function Register() {
  const { t, locale } = useI18n();
  const { register } = useAuth();
  const [f, setF] = useState({ fullName: '', phone: '', email: '', password: '' });
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const errors = {
    fullName: !f.fullName.trim() ? t('err.required') : undefined,
    phone: !isValidPhone(f.phone) ? t('err.phone') : undefined,
    password: !isStrongPassword(f.password) ? t('err.password') : undefined,
  };
  const valid = !errors.fullName && !errors.phone && !errors.password;

  const submit = async () => {
    setTouched(true);
    if (!valid) return;
    setError('');
    setLoading(true);
    try {
      const res = await register({
        fullName: f.fullName.trim(),
        phone: normalizePhone(f.phone),
        email: f.email.trim() || undefined,
        password: f.password,
        locale,
      });
      if (res.requiresOtp) router.replace({ pathname: '/verify', params: { phone: res.phone } });
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthShell title={t('auth.registerTitle')} subtitle={t('auth.registerSub')}>
      <Field label={t('auth.fullName')} autoComplete="name" textContentType="name" value={f.fullName} onChangeText={(v) => setF({ ...f, fullName: v })} error={touched ? errors.fullName : undefined} />
      <Field
        label={t('auth.phone')}
        placeholder={t('auth.phoneHint')}
        keyboardType="phone-pad"
        autoComplete="tel"
        value={f.phone}
        onChangeText={(v) => setF({ ...f, phone: v })}
        error={touched ? errors.phone : undefined}
      />
      <Field
        label={t('auth.email')}
        optional
        optionalLabel={t('common.optional')}
        keyboardType="email-address"
        autoCapitalize="none"
        autoComplete="email"
        value={f.email}
        onChangeText={(v) => setF({ ...f, email: v })}
      />
      <Field
        label={t('auth.password')}
        secureTextEntry
        autoComplete="new-password"
        textContentType="newPassword"
        hint={t('auth.passwordHint')}
        value={f.password}
        onChangeText={(v) => setF({ ...f, password: v })}
        error={touched ? errors.password : undefined}
      />
      {!!error && (
        <View style={{ marginBottom: space.lg }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}
      <Button title={t('auth.register')} onPress={submit} loading={loading} />
      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6, marginTop: space.xl }}>
        <Text style={type.body}>{t('auth.haveAccount')}</Text>
        <Link href="/login" style={{ color: colors.brand, fontWeight: '600', fontSize: 15 }}>
          {t('auth.login')}
        </Link>
      </View>
    </AuthShell>
  );
}
