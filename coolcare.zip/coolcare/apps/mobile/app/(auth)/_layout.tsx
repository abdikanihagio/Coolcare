import { Redirect, Stack } from 'expo-router';
import { useAuth } from '@/lib/auth';
import { colors } from '@/theme';

export default function AuthLayout() {
  const { user } = useAuth();
  if (user) return <Redirect href="/home" />;
  return (
    <Stack
      screenOptions={{
        title: '',
        headerShadowVisible: false,
        headerTintColor: colors.navy,
        headerStyle: { backgroundColor: colors.white },
        contentStyle: { backgroundColor: colors.white },
        headerBackButtonDisplayMode: 'minimal',
      }}
    >
      <Stack.Screen name="login" options={{ headerShown: false }} />
    </Stack>
  );
}
