import { router, useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { AuthShell } from '@/components/auth-shell';
import { CodeInput } from '@/components/code-input';
import { Banner, Button, errorText } from '@/components/ui';
import { space } from '@/theme';

export default function Verify() {
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const { t } = useI18n();
  const { verifyOtp } = useAuth();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(60);

  useEffect(() => {
    if (cooldown <= 0) return;
    const id = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(id);
  }, [cooldown]);

  const submit = async (value = code) => {
    if (value.length !== 6) return;
    setError('');
    setLoading(true);
    try {
      await verifyOtp(phone, value);
      router.replace('/home');
    } catch (err) {
      setError(errorText(err, t));
      setCode('');
    } finally {
      setLoading(false);
    }
  };

  const resend = async () => {
    setError('');
    try {
      await api('/auth/otp/request', { body: { phone, purpose: 'VERIFY_PHONE' }, auth: false });
      setInfo(t('auth.codeSent'));
      setCooldown(60);
    } catch (err) {
      setError(errorText(err, t));
    }
  };

  return (
    <AuthShell title={t('auth.verifyTitle')} subtitle={t('auth.verifySub', { phone })}>
      <CodeInput
        label={t('auth.code')}
        value={code}
        onChange={(v) => {
          setCode(v);
          if (v.length === 6) submit(v);
        }}
      />
      <View style={{ gap: space.md, marginTop: space.xl }}>
        {!!error && (
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        )}
        {!!info && !error && (
          <Banner tone="ok" icon="check-circle-outline">
            {info}
          </Banner>
        )}
        <Button title={t('auth.verify')} onPress={() => submit()} loading={loading} disabled={code.length !== 6} />
        <Button
          title={cooldown > 0 ? t('auth.resendIn', { s: cooldown }) : t('auth.resend')}
          variant="ghost"
          disabled={cooldown > 0}
          onPress={resend}
        />
      </View>
    </AuthShell>
  );
}
