import { router } from 'expo-router';
import { useState } from 'react';
import { View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { isValidPhone, normalizePhone } from '@/lib/format';
import { AuthShell } from '@/components/auth-shell';
import { Banner, Button, errorText, Field } from '@/components/ui';
import { space } from '@/theme';

export default function Forgot() {
  const { t } = useI18n();
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!isValidPhone(phone)) return setError(t('err.phone'));
    setError('');
    setLoading(true);
    try {
      const normalized = normalizePhone(phone);
      await api('/auth/password/forgot', { body: { phone: normalized }, auth: false });
      router.push({ pathname: '/reset', params: { phone: normalized } });
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthShell title={t('auth.forgotTitle')} subtitle={t('auth.forgotSub')}>
      <Field label={t('auth.phone')} placeholder={t('auth.phoneHint')} keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
      {!!error && (
        <View style={{ marginBottom: space.lg }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}
      <Button title={t('auth.sendCode')} onPress={submit} loading={loading} />
    </AuthShell>
  );
}
