import { Link, router } from 'expo-router';
import { useState } from 'react';
import { Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { useAuth } from '@/lib/auth';
import { isValidPhone, normalizePhone } from '@/lib/format';
import { AuthShell } from '@/components/auth-shell';
import { Banner, Button, errorText, Field } from '@/components/ui';
import { colors, space, type } from '@/theme';

export default function Login() {
  const { t } = useI18n();
  const { login } = useAuth();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [touched, setTouched] = useState(false);

  const submit = async () => {
    setTouched(true);
    if (!isValidPhone(phone) || !password) return;
    setError('');
    setLoading(true);
    try {
      const res = await login(normalizePhone(phone), password);
      if (res.requiresOtp) router.push({ pathname: '/verify', params: { phone: res.phone } });
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthShell brand title={t('auth.welcome')} subtitle={t('auth.loginSub')}>
      <Field
        label={t('auth.phone')}
        placeholder={t('auth.phoneHint')}
        keyboardType="phone-pad"
        autoComplete="tel"
        textContentType="telephoneNumber"
        value={phone}
        onChangeText={setPhone}
        error={touched && !isValidPhone(phone) ? t('err.phone') : undefined}
      />
      <Field
        label={t('auth.password')}
        secureTextEntry
        autoComplete="current-password"
        textContentType="password"
        value={password}
        onChangeText={setPassword}
        onSubmitEditing={submit}
        returnKeyType="go"
        error={touched && !password ? t('err.required') : undefined}
      />
      <Link href="/forgot" style={{ color: colors.brand, fontWeight: '600', marginBottom: space.xl }}>
        {t('auth.forgot')}
      </Link>
      {!!error && (
        <View style={{ marginBottom: space.lg }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}
      <Button title={t('auth.login')} onPress={submit} loading={loading} />
      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6, marginTop: space.xl }}>
        <Text style={type.body}>{t('auth.noAccount')}</Text>
        <Link href="/register" style={{ color: colors.brand, fontWeight: '600', fontSize: 15 }}>
          {t('auth.createAccount')}
        </Link>
      </View>
    </AuthShell>
  );
}
