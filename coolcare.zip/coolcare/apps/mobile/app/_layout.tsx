import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import * as Notifications from 'expo-notifications';
import { router, Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { I18nProvider, useI18n } from '@/i18n';
import { ApiError } from '@/lib/api';
import { AuthProvider, useAuth } from '@/lib/auth';
import { colors } from '@/theme';

SplashScreen.preventAutoHideAsync().catch(() => undefined);

function Navigator() {
  const { ready: authReady } = useAuth();
  const { ready: i18nReady, t } = useI18n();
  const ready = authReady && i18nReady;

  useEffect(() => {
    if (ready) SplashScreen.hideAsync().catch(() => undefined);
  }, [ready]);

  // Open the related booking when a push notification is tapped
  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener((response) => {
      const bookingId = response.notification.request.content.data?.bookingId;
      if (typeof bookingId === 'string') router.push(`/booking/${bookingId}`);
    });
    return () => sub.remove();
  }, []);

  if (!ready) return null;

  return (
    <Stack
      screenOptions={{
        headerTintColor: colors.navy,
        headerTitleStyle: { fontWeight: '600' },
        headerShadowVisible: false,
        headerStyle: { backgroundColor: colors.surface },
        contentStyle: { backgroundColor: colors.surface },
        headerBackButtonDisplayMode: 'minimal',
      }}
    >
      <Stack.Screen name="index" options={{ headerShown: false }} />
      <Stack.Screen name="onboarding" options={{ headerShown: false }} />
      <Stack.Screen name="(auth)" options={{ headerShown: false }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="service/[id]" options={{ title: '' }} />
      <Stack.Screen name="book/[serviceId]" options={{ title: '' }} />
      <Stack.Screen name="booking/[id]" options={{ title: '' }} />
      <Stack.Screen name="invoice/[id]" options={{ title: t('pay.title'), presentation: 'modal' }} />
      <Stack.Screen name="addresses/index" options={{ title: t('addr.title') }} />
      <Stack.Screen name="addresses/edit" options={{ title: t('addr.new'), presentation: 'modal' }} />
      <Stack.Screen name="equipment/index" options={{ title: t('eq.title') }} />
      <Stack.Screen name="equipment/edit" options={{ title: t('eq.new'), presentation: 'modal' }} />
      <Stack.Screen name="plans" options={{ title: t('plan.title') }} />
      <Stack.Screen name="support" options={{ title: t('sup.title') }} />
      <Stack.Screen name="profile" options={{ title: t('profile.title') }} />
      <Stack.Screen name="password" options={{ title: t('pw.title') }} />
      <Stack.Screen name="language" options={{ title: t('acc.language') }} />
    </Stack>
  );
}

export default function RootLayout() {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 20_000,
            retry: (count, err) => !(err instanceof ApiError && [401, 403, 404].includes(err.status)) && count < 2,
          },
        },
      }),
  );
  return (
    <SafeAreaProvider>
      <QueryClientProvider client={client}>
        <I18nProvider>
          <AuthProvider>
            <StatusBar style="dark" />
            <Navigator />
          </AuthProvider>
        </I18nProvider>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}
