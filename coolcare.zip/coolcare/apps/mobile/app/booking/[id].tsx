import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Alert, Image, Linking, Platform, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { pick, useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { addDaysIso, dateTime, day, money, todayIso } from '@/lib/format';
import { usePublicSettings } from '@/lib/hooks';
import type { Booking, BookingStatus, Quote, Slot } from '@/lib/types';
import { Banner, Button, Card, Choice, ErrorView, errorText, Pill, Screen, SectionTitle, ServiceIcon, Skeleton } from '@/components/ui';
import { colors, radius, space, statusTone, type } from '@/theme';

const STEPS: BookingStatus[] = ['PENDING', 'CONFIRMED', 'ASSIGNED', 'ON_THE_WAY', 'IN_PROGRESS', 'COMPLETED'];

export default function BookingDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { t, locale } = useI18n();
  const qc = useQueryClient();
  const settings = usePublicSettings();
  const key = ['booking', id];
  const q = useQuery({ queryKey: key, queryFn: () => api<Booking>(`/bookings/${id}`), refetchInterval: 30_000 });
  const [busy, setBusy] = useState<string | null>(null);
  const [rescheduling, setRescheduling] = useState(false);

  const act = async (name: string, fn: () => Promise<Booking>, success?: string) => {
    setBusy(name);
    try {
      const updated = await fn();
      qc.setQueryData(key, updated);
      qc.invalidateQueries({ queryKey: ['bookings'] });
      if (success) Alert.alert(success);
    } catch (err) {
      Alert.alert(t('err.generic'), errorText(err, t));
    } finally {
      setBusy(null);
    }
  };

  if (q.isError) return <ErrorView message={errorText(q.error, t)} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />;
  if (!q.data)
    return (
      <Screen>
        <View style={{ gap: space.md }}>
          <Skeleton height={60} />
          <Skeleton height={180} />
          <Skeleton height={100} />
        </View>
      </Screen>
    );

  const b = q.data;
  const pendingQuote = b.quotes?.find((x) => x.status === 'SENT');
  const cancellable = ['PENDING', 'CONFIRMED', 'ASSIGNED'].includes(b.status) && settings.data?.allowCustomerCancellation !== false;
  const balance = b.invoice ? Number(b.invoice.total) - Number(b.invoice.amountPaid) : 0;
  const reachedIndex = b.status === 'AWAITING_APPROVAL' ? STEPS.indexOf('IN_PROGRESS') : STEPS.indexOf(b.status);

  const confirmCancel = () =>
    Alert.alert(t('bk.cancelConfirm'), undefined, [
      { text: t('bk.keep'), style: 'cancel' },
      {
        text: t('bk.cancel'),
        style: 'destructive',
        onPress: () => act('cancel', () => api<Booking>(`/bookings/${b.id}/cancel`, { body: {} }), t('bk.cancelled')),
      },
    ]);

  return (
    <Screen refreshing={q.isRefetching} onRefresh={() => q.refetch()}>
      <Stack.Screen options={{ title: b.reference }} />

      <View style={{ flexDirection: 'row', gap: space.md, alignItems: 'center' }}>
        <ServiceIcon icon={b.service.category?.icon} size={52} />
        <View style={{ flex: 1, gap: 4 }}>
          <Text style={type.h2}>{pick(b.service, 'name', locale)}</Text>
          <Pill label={t(`status.${b.status}`)} tone={statusTone[b.status]} />
        </View>
      </View>

      {pendingQuote && <QuoteCard quote={pendingQuote} bookingId={b.id} onDone={(u) => qc.setQueryData(key, u)} />}

      {b.status !== 'CANCELLED' ? (
        <>
          <SectionTitle>{t('bk.progress')}</SectionTitle>
          <Card>
            {STEPS.map((step, i) => {
              const done = i <= reachedIndex;
              const current = i === reachedIndex;
              const entry = [...(b.history ?? [])].reverse().find((h) => h.toStatus === step);
              return (
                <View key={step} style={{ flexDirection: 'row', gap: space.md }}>
                  <View style={{ alignItems: 'center' }}>
                    <View
                      style={{
                        width: 22,
                        height: 22,
                        borderRadius: 11,
                        backgroundColor: done ? colors.brand : colors.white,
                        borderWidth: 2,
                        borderColor: done ? colors.brand : colors.line,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      {done && <MaterialCommunityIcons name="check" size={14} color={colors.white} />}
                    </View>
                    {i < STEPS.length - 1 && <View style={{ width: 2, flex: 1, minHeight: 22, backgroundColor: i < reachedIndex ? colors.brand : colors.line }} />}
                  </View>
                  <View style={{ flex: 1, paddingBottom: space.md }}>
                    <Text style={[type.body, { fontWeight: current ? '700' : '500', color: done ? colors.navy : colors.faint }]}>
                      {t(`status.${current && b.status === 'AWAITING_APPROVAL' ? 'AWAITING_APPROVAL' : step}`)}
                    </Text>
                    {entry && <Text style={type.small}>{dateTime(entry.createdAt, locale)}</Text>}
                  </View>
                </View>
              );
            })}
          </Card>
        </>
      ) : (
        <View style={{ marginTop: space.lg }}>
          <Banner tone="bad" icon="close-circle-outline">
            {t('status.CANCELLED')}
          </Banner>
        </View>
      )}

      <SectionTitle>{t('bk.technician')}</SectionTitle>
      <Card>
        {b.technician ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
            <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: colors.brandSoft, alignItems: 'center', justifyContent: 'center' }}>
              <MaterialCommunityIcons name="account-hard-hat" size={26} color={colors.brand} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={type.h3}>{b.technician.fullName}</Text>
              {Number(b.technician.rating) > 0 && (
                <Text style={type.small}>
                  ★ {Number(b.technician.rating).toFixed(1)}
                </Text>
              )}
            </View>
            {b.technician.phone && !['COMPLETED', 'CANCELLED'].includes(b.status) && (
              <Button title={t('bk.call')} icon="phone" variant="secondary" onPress={() => Linking.openURL(`tel:${b.technician!.phone}`)} />
            )}
          </View>
        ) : (
          <Text style={[type.body, { color: colors.muted }]}>{t('bk.notAssigned')}</Text>
        )}
      </Card>

      <SectionTitle>{t('bk.details')}</SectionTitle>
      <Card style={{ gap: space.md }}>
        <Detail icon="calendar-clock" label={t('bk.when')} value={`${day(b.scheduledDate, locale)} · ${t(`slot.${b.timeSlot}`)} (${t(`slotTime.${b.timeSlot}`)})`} />
        <Detail icon="map-marker-outline" label={t('bk.where')} value={b.addressText} />
        <Detail icon="counter" label={t('book.units')} value={t('bk.units', { count: b.unitCount })} />
        {b.estimatedPrice && <Detail icon="cash" label={t('bk.estimate')} value={money(b.estimatedPrice, 'USD', locale)} />}
        {b.problemDescription && <Detail icon="text-box-outline" label={t('book.problem')} value={b.problemDescription} />}
      </Card>

      {!!b.photos?.length && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: space.sm, marginTop: space.md }}>
          {b.photos.map((p) => (
            <Image key={p.id} source={{ uri: p.url }} style={{ width: 96, height: 96, borderRadius: radius.md, backgroundColor: colors.line }} />
          ))}
        </ScrollView>
      )}

      {b.invoice && b.invoice.status !== 'VOID' && (
        <>
          <SectionTitle>{t('bk.invoice', { number: b.invoice.number })}</SectionTitle>
          <Card style={{ gap: space.md }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.body}>{t('common.total')}</Text>
              <Text style={[type.h3, { fontVariant: ['tabular-nums'] }]}>{money(b.invoice.total, b.invoice.currency, locale)}</Text>
            </View>
            {balance > 0 ? (
              <>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <Text style={[type.body, { color: '#B45309' }]}>{t('bk.balance')}</Text>
                  <Text style={[type.h3, { color: '#B45309', fontVariant: ['tabular-nums'] }]}>{money(balance, b.invoice.currency, locale)}</Text>
                </View>
                {b.invoice.payments.some((p) => p.status === 'PENDING') ? (
                  <Pill label={t('pay.pending')} tone="warn" />
                ) : (
                  <Button title={t('bk.pay')} icon="cellphone-text" onPress={() => router.push({ pathname: '/invoice/[id]', params: { id: b.invoice!.id, bookingId: b.id } })} />
                )}
              </>
            ) : (
              <Pill label={t('bk.paid')} tone="ok" />
            )}
          </Card>
        </>
      )}

      {b.status === 'COMPLETED' && <RatingCard booking={b} onDone={(u) => qc.setQueryData(key, u)} />}

      {(cancellable || ['PENDING', 'CONFIRMED'].includes(b.status)) && (
        <View style={{ gap: space.sm, marginTop: space.xl }}>
          {['PENDING', 'CONFIRMED'].includes(b.status) && <Button title={t('bk.reschedule')} variant="secondary" icon="calendar-edit" onPress={() => setRescheduling(true)} />}
          {cancellable && <Button title={t('bk.cancel')} variant="danger" onPress={confirmCancel} loading={busy === 'cancel'} />}
        </View>
      )}

      {rescheduling && (
        <RescheduleCard
          onClose={() => setRescheduling(false)}
          onSave={(date, slot) =>
            act('reschedule', () => api<Booking>(`/bookings/${b.id}/reschedule`, { body: { scheduledDate: date, timeSlot: slot } }), t('bk.rescheduled')).then(() =>
              setRescheduling(false),
            )
          }
          saving={busy === 'reschedule'}
        />
      )}

      {settings.data?.supportPhone && (
        <Pressable onPress={() => Linking.openURL(`tel:${settings.data!.supportPhone}`)} style={{ alignItems: 'center', marginTop: space.xl }} accessibilityRole="link">
          <Text style={type.small}>{t('bk.helpCall')}</Text>
          <Text style={{ color: colors.brand, fontWeight: '600', marginTop: 2 }}>{settings.data.supportPhone}</Text>
        </Pressable>
      )}
    </Screen>
  );
}

function Detail({ icon, label, value }: { icon: 'calendar-clock' | 'map-marker-outline' | 'counter' | 'cash' | 'text-box-outline'; label: string; value: string }) {
  return (
    <View style={{ flexDirection: 'row', gap: space.md }}>
      <MaterialCommunityIcons name={icon} size={20} color={colors.muted} style={{ marginTop: 2 }} />
      <View style={{ flex: 1 }}>
        <Text style={type.small}>{label}</Text>
        <Text style={type.body}>{value}</Text>
      </View>
    </View>
  );
}

function QuoteCard({ quote, bookingId, onDone }: { quote: Quote; bookingId: string; onDone: (b: Booking) => void }) {
  const { t, locale } = useI18n();
  const qc = useQueryClient();
  const [busy, setBusy] = useState<'accept' | 'reject' | null>(null);

  const respond = async (accept: boolean, reason?: string) => {
    setBusy(accept ? 'accept' : 'reject');
    try {
      const updated = await api<Booking>(`/quotes/${quote.id}/${accept ? 'accept' : 'reject'}`, { body: accept ? {} : { reason } });
      onDone(updated);
      qc.invalidateQueries({ queryKey: ['bookings'] });
      Alert.alert(accept ? t('bk.quoteAccepted') : t('bk.quoteRejected'));
    } catch (err) {
      Alert.alert(t('err.generic'), errorText(err, t));
    } finally {
      setBusy(null);
    }
  };

  const reject = () => {
    if (Platform.OS === 'ios') {
      Alert.prompt(t('bk.rejectQuote'), t('bk.rejectReason'), [
        { text: t('common.cancel'), style: 'cancel' },
        { text: t('bk.rejectQuote'), style: 'destructive', onPress: (reason?: string) => respond(false, reason) },
      ]);
    } else {
      Alert.alert(t('bk.rejectQuote'), undefined, [
        { text: t('common.cancel'), style: 'cancel' },
        { text: t('bk.rejectQuote'), style: 'destructive', onPress: () => respond(false) },
      ]);
    }
  };

  return (
    <Card style={{ marginTop: space.lg, borderColor: colors.warn, borderWidth: 1.5, gap: space.md }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
        <MaterialCommunityIcons name="file-document-edit-outline" size={22} color={colors.warn} />
        <Text style={[type.h3, { flex: 1 }]}>{t('bk.quote', { number: quote.number })}</Text>
      </View>
      {quote.items.map((it, i) => (
        <View key={i} style={{ flexDirection: 'row', justifyContent: 'space-between', gap: space.md }}>
          <Text style={[type.body, { flex: 1 }]}>
            {it.description}
            {Number(it.quantity) !== 1 && <Text style={type.small}> × {Number(it.quantity)}</Text>}
          </Text>
          <Text style={[type.body, { fontVariant: ['tabular-nums'] }]}>{money(it.total, quote.currency, locale)}</Text>
        </View>
      ))}
      {Number(quote.discount) > 0 && (
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={type.small}>{t('bk.discount')}</Text>
          <Text style={[type.small, { color: colors.ok }]}>−{money(quote.discount, quote.currency, locale)}</Text>
        </View>
      )}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: colors.line, paddingTop: space.md }}>
        <Text style={type.h3}>{t('common.total')}</Text>
        <Text style={[type.h2, { fontVariant: ['tabular-nums'] }]}>{money(quote.total, quote.currency, locale)}</Text>
      </View>
      {quote.notes && <Text style={type.small}>{quote.notes}</Text>}
      {quote.validUntil && <Text style={type.small}>{t('bk.validUntil', { date: day(quote.validUntil, locale) })}</Text>}
      <Button title={t('bk.acceptQuote')} onPress={() => respond(true)} loading={busy === 'accept'} disabled={!!busy} />
      <Button title={t('bk.rejectQuote')} variant="secondary" onPress={reject} loading={busy === 'reject'} disabled={!!busy} />
    </Card>
  );
}

function RatingCard({ booking, onDone }: { booking: Booking; onDone: (b: Booking) => void }) {
  const { t } = useI18n();
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [saving, setSaving] = useState(false);

  if (booking.rating) {
    return (
      <Card style={{ marginTop: space.lg, alignItems: 'center', gap: space.sm }}>
        <Text style={{ fontSize: 26, color: colors.warn }}>{'★'.repeat(booking.rating)}</Text>
        <Text style={type.small}>{t('bk.thanks')}</Text>
      </Card>
    );
  }

  const submit = async () => {
    setSaving(true);
    try {
      onDone(await api<Booking>(`/bookings/${booking.id}/rate`, { body: { rating, review: review.trim() || undefined } }));
    } catch (err) {
      Alert.alert(t('err.generic'), errorText(err, t));
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <SectionTitle>{t('bk.rate')}</SectionTitle>
      <Card style={{ gap: space.md }}>
        <View style={{ flexDirection: 'row', justifyContent: 'center', gap: space.sm }} accessibilityRole="adjustable" accessibilityValue={{ min: 0, max: 5, now: rating }}>
          {[1, 2, 3, 4, 5].map((n) => (
            <Pressable key={n} onPress={() => setRating(n)} hitSlop={8} accessibilityLabel={`${n}`}>
              <MaterialCommunityIcons name={n <= rating ? 'star' : 'star-outline'} size={40} color={n <= rating ? colors.warn : colors.faint} />
            </Pressable>
          ))}
        </View>
        {rating > 0 && (
          <>
            <TextInput
              value={review}
              onChangeText={setReview}
              placeholder={t('bk.ratePlaceholder')}
              placeholderTextColor={colors.faint}
              multiline
              maxLength={1000}
              style={{ minHeight: 80, borderWidth: 1, borderColor: colors.line, borderRadius: radius.md, padding: space.md, fontSize: 15, color: colors.navy, textAlignVertical: 'top' }}
            />
            <Button title={t('bk.submitRating')} onPress={submit} loading={saving} />
          </>
        )}
      </Card>
    </>
  );
}

function RescheduleCard({ onClose, onSave, saving }: { onClose: () => void; onSave: (date: string, slot: Slot) => void; saving: boolean }) {
  const { t, locale } = useI18n();
  const today = todayIso();
  const [date, setDate] = useState(addDaysIso(today, 1));
  const [slot, setSlot] = useState<Slot | null>(null);
  const availability = useQuery({
    queryKey: ['availability', date],
    queryFn: () => api<{ slot: Slot; available: boolean }[]>('/bookings/availability', { query: { date } }),
  });
  return (
    <Card style={{ marginTop: space.lg, gap: space.md }}>
      <Text style={type.h3}>{t('bk.reschedule')}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: space.sm }}>
        {Array.from({ length: 14 }, (_, i) => addDaysIso(today, i)).map((d) => (
          <Pressable
            key={d}
            onPress={() => setDate(d)}
            style={{ padding: 10, borderRadius: radius.md, borderWidth: 1, borderColor: d === date ? colors.brand : colors.line, backgroundColor: d === date ? colors.brandSoft : colors.white }}
          >
            <Text style={{ fontWeight: '600', color: colors.navy }}>{day(d, locale)}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <Choice
        value={slot}
        onChange={setSlot}
        options={(['MORNING', 'AFTERNOON', 'EVENING'] as Slot[]).map((s) => {
          const avail = availability.data?.find((a) => a.slot === s)?.available ?? false;
          return { value: s, label: t(`slot.${s}`), sub: avail ? t(`slotTime.${s}`) : t('book.slotFull'), disabled: !avail };
        })}
      />
      <Button title={t('common.save')} onPress={() => slot && onSave(date, slot)} disabled={!slot} loading={saving} />
      <Button title={t('common.cancel')} variant="ghost" onPress={onClose} />
    </Card>
  );
}
