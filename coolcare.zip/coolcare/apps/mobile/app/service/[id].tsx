import { useQuery } from '@tanstack/react-query';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { Text, View } from 'react-native';
import { pick, useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { priceLabel } from '@/lib/service';
import type { Service } from '@/lib/types';
import { Button, Card, ErrorView, errorText, Screen, SectionTitle, ServiceIcon, Skeleton } from '@/components/ui';
import { colors, space, type } from '@/theme';

export default function ServiceScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { t, locale } = useI18n();
  const q = useQuery({
    queryKey: ['service', id],
    queryFn: () => api<Service & { category: { icon: string; nameEn: string; nameSo: string } }>(`/catalog/services/${id}`, { auth: false }),
  });

  if (q.isError) return <ErrorView message={errorText(q.error, t)} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />;
  const s = q.data;

  return (
    <Screen footer={s && <Button title={t('svc.book')} onPress={() => router.push(`/book/${s.id}`)} />}>
      <Stack.Screen options={{ title: s ? pick(s.category, 'name', locale) : '' }} />
      {!s ? (
        <View style={{ gap: space.md }}>
          <Skeleton height={56} width={56} />
          <Skeleton height={28} />
          <Skeleton height={80} />
        </View>
      ) : (
        <>
          <ServiceIcon icon={s.category.icon} size={64} />
          <Text style={[type.title, { marginTop: space.lg }]}>{pick(s, 'name', locale)}</Text>
          <Text style={[type.h3, { color: colors.brand, marginTop: space.sm }]}>{priceLabel(s, t, locale)}</Text>
          <Text style={[type.small, { marginTop: 2 }]}>{t('svc.duration', { min: s.durationMinutes })}</Text>
          {!!pick(s, 'description', locale) && <Text style={[type.body, { marginTop: space.lg, fontSize: 16, lineHeight: 24 }]}>{pick(s, 'description', locale)}</Text>}

          <SectionTitle>{t('svc.howItWorks')}</SectionTitle>
          <Card style={{ gap: space.lg }}>
            {['svc.step1', 'svc.step2', 'svc.step3'].map((k, i) => (
              <View key={k} style={{ flexDirection: 'row', gap: space.md, alignItems: 'flex-start' }}>
                <View style={{ width: 26, height: 26, borderRadius: 13, backgroundColor: colors.brandSoft, alignItems: 'center', justifyContent: 'center' }}>
                  <Text style={{ color: colors.brand, fontWeight: '700' }}>{i + 1}</Text>
                </View>
                <Text style={[type.body, { flex: 1 }]}>{t(k)}</Text>
              </View>
            ))}
          </Card>
        </>
      )}
    </Screen>
  );
}
