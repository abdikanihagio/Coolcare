import { Linking, Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { usePublicSettings } from '@/lib/hooks';
import { ListItem, Screen, Skeleton } from '@/components/ui';
import { colors, radius, space, type } from '@/theme';

export default function Support() {
  const { t } = useI18n();
  const s = usePublicSettings().data;
  return (
    <Screen>
      <Text style={[type.body, { color: colors.navy700, marginBottom: space.lg }]}>{t('sup.hours')}</Text>
      {!s ? (
        <Skeleton height={160} />
      ) : (
        <View style={{ borderRadius: radius.lg, overflow: 'hidden', borderWidth: 1, borderColor: colors.line }}>
          <ListItem icon="phone" title={t('sup.call')} subtitle={s.supportPhone} onPress={() => Linking.openURL(`tel:${s.supportPhone}`)} />
          <ListItem icon="whatsapp" title={t('sup.whatsapp')} subtitle={s.supportWhatsapp} onPress={() => Linking.openURL(`https://wa.me/${s.supportWhatsapp.replace(/\D/g, '')}`)} />
          <ListItem icon="email-outline" title={t('sup.email')} subtitle={s.supportEmail} onPress={() => Linking.openURL(`mailto:${s.supportEmail}`)} />
        </View>
      )}
    </Screen>
  );
}
