import { router } from 'expo-router';
import { useState } from 'react';
import { Alert, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import type { User } from '@/lib/types';
import { Banner, Button, errorText, Field, Screen } from '@/components/ui';
import { space } from '@/theme';

export default function Profile() {
  const { t } = useI18n();
  const { user, setUser } = useAuth();
  const [fullName, setFullName] = useState(user?.fullName ?? '');
  const [email, setEmail] = useState(user?.email ?? '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!fullName.trim()) return setError(t('err.required'));
    setSaving(true);
    setError('');
    try {
      const updated = await api<User>('/me', { method: 'PATCH', body: { fullName: fullName.trim(), ...(email.trim() ? { email: email.trim() } : {}) } });
      setUser(updated);
      Alert.alert(t('profile.saved'));
      router.back();
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen footer={<Button title={t('common.save')} onPress={save} loading={saving} />}>
      <Field label={t('auth.fullName')} value={fullName} onChangeText={setFullName} autoComplete="name" />
      <Field label={t('auth.phone')} value={user?.phone} editable={false} style={{ opacity: 0.6 }} />
      <Field label={t('auth.email')} optional optionalLabel={t('common.optional')} value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
      {!!error && (
        <View style={{ marginTop: space.sm }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}
    </Screen>
  );
}
