import { router } from 'expo-router';
import { useState } from 'react';
import { Alert, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { isStrongPassword } from '@/lib/format';
import { Banner, Button, errorText, Field, Screen } from '@/components/ui';
import { space } from '@/theme';

export default function ChangePassword() {
  const { t } = useI18n();
  const { logout } = useAuth();
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!isStrongPassword(next)) return setError(t('err.password'));
    setSaving(true);
    setError('');
    try {
      await api('/auth/password/change', { body: { currentPassword: current, newPassword: next } });
      // All sessions are revoked server-side after a password change
      Alert.alert(t('pw.changed'));
      await logout();
      router.replace('/login');
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen footer={<Button title={t('common.save')} onPress={save} loading={saving} disabled={!current || !next} />}>
      <Field label={t('pw.current')} secureTextEntry autoComplete="current-password" value={current} onChangeText={setCurrent} />
      <Field label={t('auth.newPassword')} secureTextEntry autoComplete="new-password" hint={t('auth.passwordHint')} value={next} onChangeText={setNext} />
      {!!error && (
        <View style={{ marginTop: space.sm }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}
    </Screen>
  );
}
