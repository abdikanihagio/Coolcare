import { MaterialCommunityIcons } from '@expo/vector-icons';
import { View } from 'react-native';
import { useI18n, type Locale } from '@/i18n';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { ListItem, Screen } from '@/components/ui';
import { colors, radius } from '@/theme';

export default function Language() {
  const { locale, setLocale } = useI18n();
  const { user, setUser } = useAuth();

  const choose = async (l: Locale) => {
    await setLocale(l);
    // Store on the account too, so SMS and push notifications arrive in this language
    if (user) api('/me', { method: 'PATCH', body: { locale: l } }).then(() => setUser({ ...user, locale: l })).catch(() => undefined);
  };

  return (
    <Screen>
      <View style={{ borderRadius: radius.lg, overflow: 'hidden', borderWidth: 1, borderColor: colors.line }}>
        {(['so', 'en'] as Locale[]).map((l) => (
          <ListItem
            key={l}
            title={l === 'so' ? 'Af-Soomaali' : 'English'}
            onPress={() => choose(l)}
            right={<MaterialCommunityIcons name={locale === l ? 'radiobox-marked' : 'radiobox-blank'} size={22} color={locale === l ? colors.brand : colors.faint} />}
          />
        ))}
      </View>
    </Screen>
  );
}
