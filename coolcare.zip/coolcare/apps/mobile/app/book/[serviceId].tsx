import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import * as ImagePicker from 'expo-image-picker';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import { Image, Pressable, ScrollView, Text, View } from 'react-native';
import { pick, useI18n } from '@/i18n';
import { api, uploadImage } from '@/lib/api';
import { addDaysIso, day, money, todayIso } from '@/lib/format';
import { useAddresses, useEquipment, usePublicSettings } from '@/lib/hooks';
import type { Booking, Service, Slot } from '@/lib/types';
import { Banner, Button, Card, Choice, EmptyState, errorText, Field, Screen, SectionTitle } from '@/components/ui';
import { colors, radius, space, type } from '@/theme';

type Photo = { uri: string; url?: string; key?: string; uploading?: boolean; failed?: boolean };

export default function BookService() {
  const { serviceId } = useLocalSearchParams<{ serviceId: string }>();
  const { t, locale } = useI18n();
  const qc = useQueryClient();
  const service = useQuery({ queryKey: ['service', serviceId], queryFn: () => api<Service>(`/catalog/services/${serviceId}`, { auth: false }) });
  const addresses = useAddresses();
  const equipment = useEquipment();
  const settings = usePublicSettings();

  const today = todayIso();
  const dates = useMemo(() => Array.from({ length: 14 }, (_, i) => addDaysIso(today, i)), [today]);
  const [addressId, setAddressId] = useState<string | null>(null);
  const [date, setDate] = useState(dates[0]!);
  const [slot, setSlot] = useState<Slot | null>(null);
  const [equipmentId, setEquipmentId] = useState<string>('none');
  const [units, setUnits] = useState(1);
  const [priority, setPriority] = useState<'NORMAL' | 'URGENT' | 'EMERGENCY'>('NORMAL');
  const [problem, setProblem] = useState('');
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [created, setCreated] = useState<Booking | null>(null);

  const availability = useQuery({
    queryKey: ['availability', date],
    queryFn: () => api<{ slot: Slot; available: boolean }[]>('/bookings/availability', { query: { date } }),
  });

  useEffect(() => {
    if (!addressId && addresses.data?.length) setAddressId((addresses.data.find((a) => a.isDefault) ?? addresses.data[0]!).id);
  }, [addresses.data, addressId]);

  useEffect(() => {
    // Clear a slot that became unavailable for the newly chosen date
    if (slot && availability.data && !availability.data.find((a) => a.slot === slot)?.available) setSlot(null);
  }, [availability.data, slot]);

  const s = service.data;
  const surcharge = priority === 'EMERGENCY' ? settings.data?.emergencySurcharge ?? 0 : 0;
  const estimate = s && s.priceType !== 'INSPECTION_REQUIRED' ? Number(s.basePrice) * units + surcharge : null;

  const addPhoto = async (fromCamera: boolean) => {
    const perm = fromCamera ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return;
    const result = fromCamera
      ? await ImagePicker.launchCameraAsync({ quality: 0.6, mediaTypes: ['images'] })
      : await ImagePicker.launchImageLibraryAsync({ quality: 0.6, mediaTypes: ['images'], allowsMultipleSelection: true, selectionLimit: 6 - photos.length });
    if (result.canceled) return;
    for (const asset of result.assets) {
      const entry: Photo = { uri: asset.uri, uploading: true };
      setPhotos((p) => [...p, entry].slice(0, 6));
      try {
        const stored = await uploadImage(asset.uri, 'bookings');
        setPhotos((p) => p.map((x) => (x.uri === asset.uri ? { ...x, ...stored, uploading: false } : x)));
      } catch {
        setPhotos((p) => p.map((x) => (x.uri === asset.uri ? { ...x, uploading: false, failed: true } : x)));
      }
    }
  };

  const submit = async () => {
    if (!s || !addressId || !slot) return;
    setError('');
    setSubmitting(true);
    try {
      const booking = await api<Booking>('/bookings', {
        body: {
          serviceId: s.id,
          addressId,
          equipmentId: equipmentId === 'none' ? undefined : equipmentId,
          scheduledDate: date,
          timeSlot: slot,
          priority,
          unitCount: units,
          problemDescription: problem.trim() || undefined,
          photos: photos.filter((p) => p.url && p.key).map((p) => ({ url: p.url!, key: p.key! })),
        },
      });
      qc.invalidateQueries({ queryKey: ['bookings'] });
      setCreated(booking);
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setSubmitting(false);
    }
  };

  if (created) {
    return (
      <Screen footer={<Button title={t('book.viewBooking')} onPress={() => router.replace(`/booking/${created.id}`)} />}>
        <Stack.Screen options={{ title: '', headerBackVisible: false, gestureEnabled: false }} />
        <View style={{ alignItems: 'center', paddingTop: 64, gap: space.lg }}>
          <View style={{ width: 88, height: 88, borderRadius: 44, backgroundColor: colors.okSoft, alignItems: 'center', justifyContent: 'center' }}>
            <MaterialCommunityIcons name="check" size={48} color={colors.ok} />
          </View>
          <Text style={[type.title, { textAlign: 'center' }]}>{t('book.success', { ref: created.reference })}</Text>
          <Text style={[type.body, { textAlign: 'center', color: colors.navy700, maxWidth: 320 }]}>{t('book.successBody')}</Text>
        </View>
      </Screen>
    );
  }

  const canSubmit = !!s && !!addressId && !!slot && !photos.some((p) => p.uploading);

  return (
    <Screen
      footer={
        <View style={{ gap: space.sm }}>
          {estimate !== null && (
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={type.label}>{t('book.estimate')}</Text>
              <Text style={[type.h3, { fontVariant: ['tabular-nums'] }]}>{money(estimate, 'USD', locale)}</Text>
            </View>
          )}
          <Button title={t('book.confirm')} onPress={submit} loading={submitting} disabled={!canSubmit} />
        </View>
      }
    >
      <Stack.Screen options={{ title: s ? t('book.title', { service: pick(s, 'name', locale) }) : '' }} />

      <SectionTitle action={<Button title={t('book.addAddress')} variant="ghost" icon="plus" onPress={() => router.push('/addresses/edit')} />}>
        {t('book.where')}
      </SectionTitle>
      {addresses.data?.length === 0 ? (
        <Card>
          <EmptyState icon="map-marker-plus-outline" title={t('addr.empty')} action={<Button title={t('book.addAddress')} onPress={() => router.push('/addresses/edit')} />} />
        </Card>
      ) : (
        <View style={{ gap: space.sm }}>
          {addresses.data?.map((a) => (
            <Pressable
              key={a.id}
              onPress={() => setAddressId(a.id)}
              accessibilityRole="radio"
              accessibilityState={{ selected: addressId === a.id }}
              style={[cardStyle, addressId === a.id && selectedStyle]}
            >
              <MaterialCommunityIcons name={addressId === a.id ? 'radiobox-marked' : 'radiobox-blank'} size={22} color={addressId === a.id ? colors.brand : colors.faint} />
              <View style={{ flex: 1 }}>
                <Text style={type.h3}>{a.label}</Text>
                <Text style={type.small}>{[a.neighborhood, a.district, a.landmark].filter(Boolean).join(', ')}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      )}

      <SectionTitle>{t('book.when')}</SectionTitle>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: space.sm, paddingBottom: space.md }}>
        {dates.map((d, i) => {
          const on = d === date;
          return (
            <Pressable
              key={d}
              onPress={() => setDate(d)}
              accessibilityRole="radio"
              accessibilityState={{ selected: on }}
              style={{ paddingVertical: 10, paddingHorizontal: 14, borderRadius: radius.md, borderWidth: 1, borderColor: on ? colors.brand : colors.line, backgroundColor: on ? colors.brand : colors.white, minWidth: 76, alignItems: 'center' }}
            >
              <Text style={{ fontSize: 13, color: on ? colors.brandSoft : colors.muted }}>{i === 0 ? t('book.today') : i === 1 ? t('book.tomorrow') : day(d, locale).split(' ')[0]}</Text>
              <Text style={{ fontSize: 17, fontWeight: '700', color: on ? colors.white : colors.navy }}>{d.slice(8, 10)}</Text>
            </Pressable>
          );
        })}
      </ScrollView>
      <Choice
        value={slot}
        onChange={setSlot}
        options={(['MORNING', 'AFTERNOON', 'EVENING'] as Slot[]).map((sl) => {
          const avail = availability.data?.find((a) => a.slot === sl)?.available ?? false;
          return { value: sl, label: t(`slot.${sl}`), sub: avail ? t(`slotTime.${sl}`) : t('book.slotFull'), disabled: !avail };
        })}
      />

      {!!equipment.data?.length && (
        <>
          <SectionTitle>{t('book.unit')}</SectionTitle>
          <Choice
            value={equipmentId}
            onChange={setEquipmentId}
            options={[
              ...equipment.data.map((e) => ({ value: e.id, label: t(`equip.${e.type}`), sub: [e.brand, e.location].filter(Boolean).join(' · ') || undefined })),
              { value: 'none', label: t('book.noUnit') },
            ]}
          />
        </>
      )}

      <SectionTitle>{t('book.units')}</SectionTitle>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.lg }}>
        <Stepper icon="minus" onPress={() => setUnits((u) => Math.max(1, u - 1))} disabled={units <= 1} label="-" />
        <Text style={[type.h2, { minWidth: 32, textAlign: 'center' }]} accessibilityLiveRegion="polite">
          {units}
        </Text>
        <Stepper icon="plus" onPress={() => setUnits((u) => Math.min(20, u + 1))} disabled={units >= 20} label="+" />
      </View>

      <SectionTitle>{t('book.priority')}</SectionTitle>
      <Choice
        value={priority}
        onChange={setPriority}
        options={(['NORMAL', 'URGENT', 'EMERGENCY'] as const).map((p) => ({ value: p, label: t(`priority.${p}`) }))}
      />
      {priority === 'EMERGENCY' && surcharge > 0 && (
        <View style={{ marginTop: space.md }}>
          <Banner tone="warn" icon="alert-outline">
            {t('book.surcharge', { amount: money(surcharge, 'USD', locale) })}
          </Banner>
        </View>
      )}

      <SectionTitle>{t('book.problem')}</SectionTitle>
      <Field label={t('book.problem')} placeholder={t('book.problemHint')} multiline value={problem} onChangeText={setProblem} maxLength={2000} />

      <Text style={type.label}>{t('book.photos')}</Text>
      <Text style={[type.small, { marginBottom: space.md }]}>{t('book.photosHint')}</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
        {photos.map((p) => (
          <View key={p.uri} style={{ width: 80, height: 80, borderRadius: radius.md, overflow: 'hidden', backgroundColor: colors.line }}>
            <Image source={{ uri: p.uri }} style={{ width: '100%', height: '100%', opacity: p.uploading ? 0.5 : 1 }} accessibilityIgnoresInvertColors />
            {p.failed && (
              <View style={{ position: 'absolute', inset: 0, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(220,38,38,0.4)' }}>
                <MaterialCommunityIcons name="alert" size={24} color={colors.white} />
              </View>
            )}
            <Pressable
              onPress={() => setPhotos((all) => all.filter((x) => x.uri !== p.uri))}
              accessibilityLabel={t('common.delete')}
              style={{ position: 'absolute', top: 4, right: 4, backgroundColor: 'rgba(16,42,67,0.7)', borderRadius: 12, padding: 2 }}
            >
              <MaterialCommunityIcons name="close" size={16} color={colors.white} />
            </Pressable>
          </View>
        ))}
        {photos.length < 6 && (
          <>
            <PhotoButton icon="camera-outline" onPress={() => addPhoto(true)} />
            <PhotoButton icon="image-multiple-outline" onPress={() => addPhoto(false)} />
          </>
        )}
      </View>

      {estimate !== null && <Text style={[type.small, { marginTop: space.xl }]}>{t('book.estimateNote')}</Text>}
      {!!error && (
        <View style={{ marginTop: space.lg }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}
    </Screen>
  );
}

const cardStyle = {
  flexDirection: 'row' as const,
  alignItems: 'center' as const,
  gap: space.md,
  padding: space.lg,
  borderRadius: radius.md,
  borderWidth: 1,
  borderColor: colors.line,
  backgroundColor: colors.white,
};
const selectedStyle = { borderColor: colors.brand, backgroundColor: colors.brandSoft };

function Stepper({ icon, onPress, disabled, label }: { icon: 'plus' | 'minus'; onPress: () => void; disabled?: boolean; label: string }) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={{ width: 48, height: 48, borderRadius: 24, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.4 : 1 }}
    >
      <MaterialCommunityIcons name={icon} size={22} color={colors.navy} />
    </Pressable>
  );
}

function PhotoButton({ icon, onPress }: { icon: 'camera-outline' | 'image-multiple-outline'; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      style={{ width: 80, height: 80, borderRadius: radius.md, borderWidth: 1.5, borderStyle: 'dashed', borderColor: colors.faint, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.white }}
    >
      <MaterialCommunityIcons name={icon} size={28} color={colors.brand} />
    </Pressable>
  );
}
