import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import * as Location from 'expo-location';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Modal, Platform, Pressable, ScrollView, Text, View } from 'react-native';
import MapView, { PROVIDER_GOOGLE, type Region } from 'react-native-maps';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAddresses, usePublicSettings } from '@/lib/hooks';
import { Banner, Button, errorText, Field, Row, Screen } from '@/components/ui';
import { colors, radius, space, type } from '@/theme';

const MOGADISHU: Region = { latitude: 2.0469, longitude: 45.3182, latitudeDelta: 0.06, longitudeDelta: 0.06 };

export default function EditAddress() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { t } = useI18n();
  const qc = useQueryClient();
  const addresses = useAddresses();
  const settings = usePublicSettings();
  const existing = addresses.data?.find((a) => a.id === id);

  const [f, setF] = useState({
    label: existing?.label ?? '',
    district: existing?.district ?? '',
    neighborhood: existing?.neighborhood ?? '',
    street: existing?.street ?? '',
    landmark: existing?.landmark ?? '',
    details: existing?.details ?? '',
    isDefault: existing?.isDefault ?? false,
  });
  const [coords, setCoords] = useState<{ latitude: number; longitude: number } | null>(
    existing?.latitude != null && existing?.longitude != null ? { latitude: Number(existing.latitude), longitude: Number(existing.longitude) } : null,
  );
  const [districtOpen, setDistrictOpen] = useState(false);
  const [mapOpen, setMapOpen] = useState(false);
  const [info, setInfo] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [locating, setLocating] = useState(false);

  const useLocation = async () => {
    setLocating(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return setInfo(t('addr.locationDenied'));
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setCoords({ latitude: pos.coords.latitude, longitude: pos.coords.longitude });
      setMapOpen(true);
    } catch (err) {
      setInfo(errorText(err, t));
    } finally {
      setLocating(false);
    }
  };

  const save = async () => {
    if (!f.label.trim() || !f.district) return setError(t('err.required'));
    setError('');
    setSaving(true);
    try {
      const body = {
        label: f.label.trim(),
        district: f.district,
        neighborhood: f.neighborhood.trim() || undefined,
        street: f.street.trim() || undefined,
        landmark: f.landmark.trim() || undefined,
        details: f.details.trim() || undefined,
        isDefault: f.isDefault || undefined,
        latitude: coords?.latitude,
        longitude: coords?.longitude,
      };
      if (existing) await api(`/me/addresses/${existing.id}`, { method: 'PATCH', body });
      else await api('/me/addresses', { body });
      await qc.invalidateQueries({ queryKey: ['addresses'] });
      router.back();
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen footer={<Button title={t('common.save')} onPress={save} loading={saving} />}>
      <Stack.Screen options={{ title: existing ? t('addr.edit') : t('addr.new') }} />
      <Field label={t('addr.label')} placeholder={t('addr.labelHint')} value={f.label} onChangeText={(v) => setF({ ...f, label: v })} />

      <Text style={[type.label, { marginBottom: 6 }]}>{t('addr.district')}</Text>
      <Pressable
        onPress={() => setDistrictOpen(true)}
        accessibilityRole="button"
        style={{ minHeight: 52, borderWidth: 1, borderColor: colors.line, borderRadius: radius.md, paddingHorizontal: space.lg, backgroundColor: colors.white, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: space.lg }}
      >
        <Text style={{ fontSize: 16, color: f.district ? colors.navy : colors.faint }}>{f.district || t('addr.chooseDistrict')}</Text>
        <MaterialCommunityIcons name="chevron-down" size={22} color={colors.muted} />
      </Pressable>

      <Field label={t('addr.neighborhood')} optional optionalLabel={t('common.optional')} value={f.neighborhood} onChangeText={(v) => setF({ ...f, neighborhood: v })} />
      <Field label={t('addr.street')} optional optionalLabel={t('common.optional')} value={f.street} onChangeText={(v) => setF({ ...f, street: v })} />
      <Field label={t('addr.landmark')} placeholder={t('addr.landmarkHint')} optional optionalLabel={t('common.optional')} value={f.landmark} onChangeText={(v) => setF({ ...f, landmark: v })} />
      <Field label={t('addr.details')} multiline optional optionalLabel={t('common.optional')} value={f.details} onChangeText={(v) => setF({ ...f, details: v })} />

      <Button
        title={coords ? t('addr.locationSaved') : t('addr.useLocation')}
        icon={coords ? 'map-marker-check' : 'crosshairs-gps'}
        variant="secondary"
        onPress={coords ? () => setMapOpen(true) : useLocation}
        loading={locating}
      />
      {!!info && (
        <View style={{ marginTop: space.md }}>
          <Banner tone="warn" icon="map-marker-alert-outline">
            {info}
          </Banner>
        </View>
      )}

      <Pressable onPress={() => setF({ ...f, isDefault: !f.isDefault })} accessibilityRole="checkbox" accessibilityState={{ checked: f.isDefault }} style={{ marginTop: space.lg }}>
        <Row>
          <MaterialCommunityIcons name={f.isDefault ? 'checkbox-marked' : 'checkbox-blank-outline'} size={24} color={f.isDefault ? colors.brand : colors.faint} />
          <Text style={type.body}>{t('addr.default')}</Text>
        </Row>
      </Pressable>

      {!!error && (
        <View style={{ marginTop: space.lg }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}

      <Modal visible={districtOpen} animationType="slide" onRequestClose={() => setDistrictOpen(false)}>
        <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
          <Row style={{ justifyContent: 'space-between', padding: space.lg }}>
            <Text style={type.h2}>{t('addr.chooseDistrict')}</Text>
            <Button title={t('common.close')} variant="ghost" onPress={() => setDistrictOpen(false)} />
          </Row>
          <ScrollView>
            {(settings.data?.serviceDistricts ?? []).map((d) => (
              <Pressable
                key={d}
                onPress={() => {
                  setF({ ...f, district: d });
                  setDistrictOpen(false);
                }}
                style={({ pressed }) => ({ padding: space.lg, backgroundColor: pressed || d === f.district ? colors.brandSoft : colors.white, borderBottomWidth: 1, borderBottomColor: colors.line })}
              >
                <Text style={[type.body, d === f.district && { fontWeight: '700', color: colors.brand }]}>{d}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </SafeAreaView>
      </Modal>

      <Modal visible={mapOpen} animationType="slide" onRequestClose={() => setMapOpen(false)}>
        <View style={{ flex: 1 }}>
          <MapView
            style={{ flex: 1 }}
            provider={Platform.OS === 'android' ? PROVIDER_GOOGLE : undefined}
            initialRegion={coords ? { ...coords, latitudeDelta: 0.004, longitudeDelta: 0.004 } : MOGADISHU}
            onRegionChangeComplete={(r) => setCoords({ latitude: r.latitude, longitude: r.longitude })}
            showsUserLocation
          />
          {/* Fixed centre pin: the map moves underneath it */}
          <View pointerEvents="none" style={{ position: 'absolute', top: '50%', left: '50%', marginLeft: -20, marginTop: -40 }}>
            <MaterialCommunityIcons name="map-marker" size={40} color={colors.brand} />
          </View>
          <SafeAreaView edges={['bottom']} style={{ backgroundColor: colors.white, padding: space.lg, gap: space.sm }}>
            <Text style={[type.small, { textAlign: 'center' }]}>{t('addr.mapHint')}</Text>
            <Button title={t('common.done')} onPress={() => setMapOpen(false)} />
          </SafeAreaView>
        </View>
      </Modal>
    </Screen>
  );
}
