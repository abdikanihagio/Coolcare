import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';
import { Alert, Pressable, Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAddresses } from '@/lib/hooks';
import { Button, Card, EmptyState, ErrorView, errorText, Pill, Screen, Skeleton } from '@/components/ui';
import { colors, space, type } from '@/theme';

export default function Addresses() {
  const { t } = useI18n();
  const qc = useQueryClient();
  const q = useAddresses();

  const remove = (id: string) =>
    Alert.alert(t('addr.deleteConfirm'), undefined, [
      { text: t('common.cancel'), style: 'cancel' },
      {
        text: t('common.delete'),
        style: 'destructive',
        onPress: () =>
          api(`/me/addresses/${id}`, { method: 'DELETE' })
            .then(() => qc.invalidateQueries({ queryKey: ['addresses'] }))
            .catch((err) => Alert.alert(errorText(err, t))),
      },
    ]);

  return (
    <Screen
      refreshing={q.isRefetching}
      onRefresh={() => q.refetch()}
      footer={<Button title={t('addr.new')} icon="plus" onPress={() => router.push('/addresses/edit')} />}
    >
      {q.isError ? (
        <ErrorView message={errorText(q.error, t)} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />
      ) : q.isLoading ? (
        <Skeleton height={80} />
      ) : q.data?.length ? (
        <View style={{ gap: space.md }}>
          {q.data.map((a) => (
            <Card key={a.id} onPress={() => router.push({ pathname: '/addresses/edit', params: { id: a.id } })}>
              <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: space.md }}>
                <MaterialCommunityIcons name="map-marker-outline" size={22} color={colors.brand} />
                <View style={{ flex: 1, gap: 2 }}>
                  <View style={{ flexDirection: 'row', gap: space.sm, alignItems: 'center' }}>
                    <Text style={type.h3}>{a.label}</Text>
                    {a.isDefault && <Pill label={t('common.default')} tone="brand" />}
                  </View>
                  <Text style={type.body}>{[a.street, a.neighborhood, a.district].filter(Boolean).join(', ')}</Text>
                  {a.landmark && <Text style={type.small}>{a.landmark}</Text>}
                </View>
                <Pressable onPress={() => remove(a.id)} hitSlop={10} accessibilityLabel={t('common.delete')}>
                  <MaterialCommunityIcons name="trash-can-outline" size={22} color={colors.muted} />
                </Pressable>
              </View>
            </Card>
          ))}
        </View>
      ) : (
        <EmptyState icon="map-marker-plus-outline" title={t('addr.empty')} />
      )}
    </Screen>
  );
}
