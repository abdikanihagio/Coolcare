import { Redirect } from 'expo-router';
import { useI18n } from '@/i18n';
import { useAuth } from '@/lib/auth';

export default function Index() {
  const { user } = useAuth();
  const { chosen } = useI18n();
  if (!chosen) return <Redirect href="/onboarding" />;
  if (!user) return <Redirect href="/login" />;
  return <Redirect href="/home" />;
}
