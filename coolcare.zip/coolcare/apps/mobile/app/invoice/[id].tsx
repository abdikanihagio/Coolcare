import { useQuery, useQueryClient } from '@tanstack/react-query';
import { router, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { money } from '@/lib/format';
import { usePublicSettings } from '@/lib/hooks';
import type { Invoice } from '@/lib/types';
import { Banner, Button, Card, Choice, ErrorView, errorText, Field, Screen, Skeleton } from '@/components/ui';
import { space, type } from '@/theme';

const MOBILE_METHODS = ['EVC_PLUS', 'ZAAD', 'SAHAL', 'EDAHAB', 'BANK_TRANSFER'] as const;

export default function PayInvoice() {
  const { id, bookingId } = useLocalSearchParams<{ id: string; bookingId?: string }>();
  const { t, locale } = useI18n();
  const qc = useQueryClient();
  const settings = usePublicSettings();
  const q = useQuery({ queryKey: ['invoice', id], queryFn: () => api<Invoice>(`/invoices/${id}`) });
  const methods = MOBILE_METHODS.filter((m) => settings.data?.paymentMethods.includes(m) ?? true);
  const [method, setMethod] = useState<string>('EVC_PLUS');
  const [reference, setReference] = useState('');
  const [payerPhone, setPayerPhone] = useState('');
  const [amount, setAmount] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (q.isError) return <ErrorView message={errorText(q.error, t)} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />;
  if (!q.data)
    return (
      <Screen>
        <Skeleton height={120} />
      </Screen>
    );

  const inv = q.data;
  const balance = Number(inv.total) - Number(inv.amountPaid);
  const value = amount ?? balance.toFixed(2);

  const submit = async () => {
    const n = Number(value);
    if (!(n > 0) || n > balance + 0.005 || !reference.trim()) return setError(t('err.required'));
    setError('');
    setSaving(true);
    try {
      await api(`/invoices/${inv.id}/payments`, { body: { amount: n, method, reference: reference.trim(), payerPhone: payerPhone.trim() || undefined } });
      qc.invalidateQueries({ queryKey: ['invoice', id] });
      if (bookingId) qc.invalidateQueries({ queryKey: ['booking', bookingId] });
      Alert.alert(t('common.done'), t('pay.submitted'));
      router.back();
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen footer={<Button title={t('pay.submit')} onPress={submit} loading={saving} disabled={!reference.trim()} />}>
      <Card style={{ alignItems: 'center', gap: 4 }}>
        <Text style={type.small}>{t('bk.balance')}</Text>
        <Text style={[type.title, { fontVariant: ['tabular-nums'] }]}>{money(balance, inv.currency, locale)}</Text>
        <Text style={type.small}>{inv.number}</Text>
      </Card>

      {settings.data && (
        <View style={{ marginVertical: space.lg }}>
          <Banner tone="brand" icon="information-outline">
            {locale === 'so' ? settings.data.mobileMoneyInstructionsSo : settings.data.mobileMoneyInstructionsEn}
          </Banner>
        </View>
      )}

      <Text style={[type.label, { marginBottom: space.sm }]}>{t('pay.method')}</Text>
      <Choice value={method} onChange={setMethod} options={methods.map((m) => ({ value: m, label: t(`method.${m}`) }))} />

      <View style={{ marginTop: space.xl }}>
        <Field label={t('pay.amount')} keyboardType="decimal-pad" value={value} onChangeText={setAmount} />
        <Field label={t('pay.reference')} hint={t('pay.referenceHint')} autoCapitalize="characters" value={reference} onChangeText={setReference} />
        <Field label={t('pay.payerPhone')} optional optionalLabel={t('common.optional')} keyboardType="phone-pad" value={payerPhone} onChangeText={setPayerPhone} />
      </View>

      <Text style={type.small}>{t('pay.cash')}</Text>
      {!!error && (
        <View style={{ marginTop: space.lg }}>
          <Banner tone="bad" icon="alert-circle-outline">
            {error}
          </Banner>
        </View>
      )}
    </Screen>
  );
}
