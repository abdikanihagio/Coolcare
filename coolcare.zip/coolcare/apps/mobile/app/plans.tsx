import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { pick, useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { day, money } from '@/lib/format';
import type { Plan, Subscription } from '@/lib/types';
import { Button, Card, ErrorView, errorText, Pill, Screen, SectionTitle, Skeleton } from '@/components/ui';
import { colors, space, type } from '@/theme';

export default function Plans() {
  const { t, locale } = useI18n();
  const qc = useQueryClient();
  const plans = useQuery({ queryKey: ['plans'], queryFn: () => api<Plan[]>('/maintenance/plans', { auth: false }) });
  const mine = useQuery({ queryKey: ['subscriptions'], queryFn: () => api<Subscription[]>('/maintenance/subscriptions') });
  const [busy, setBusy] = useState<string | null>(null);

  const request = async (plan: Plan) => {
    setBusy(plan.id);
    try {
      await api('/maintenance/subscriptions', { body: { planId: plan.id } });
      await qc.invalidateQueries({ queryKey: ['subscriptions'] });
      Alert.alert(pick(plan, 'name', locale), t('plan.requested'));
    } catch (err) {
      Alert.alert(t('err.generic'), errorText(err, t));
    } finally {
      setBusy(null);
    }
  };

  const owned = new Set((mine.data ?? []).filter((s) => ['PENDING', 'ACTIVE'].includes(s.status)).map((s) => s.plan.id));

  return (
    <Screen refreshing={plans.isRefetching} onRefresh={() => (plans.refetch(), mine.refetch())}>
      {!!mine.data?.length && (
        <>
          <SectionTitle>{t('plan.yours')}</SectionTitle>
          <View style={{ gap: space.sm, marginBottom: space.md }}>
            {mine.data.map((s) => (
              <Card key={s.id} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <View style={{ flex: 1 }}>
                  <Text style={type.h3}>{pick(s.plan, 'name', locale)}</Text>
                  {s.nextVisitDate && <Text style={type.small}>{t('plan.next', { date: day(s.nextVisitDate, locale) })}</Text>}
                </View>
                <Pill label={t(`plan.status.${s.status}`)} tone={s.status === 'ACTIVE' ? 'ok' : s.status === 'PENDING' ? 'warn' : 'neutral'} />
              </Card>
            ))}
          </View>
        </>
      )}

      {plans.isError ? (
        <ErrorView message={errorText(plans.error, t)} onRetry={() => plans.refetch()} retryLabel={t('common.retry')} />
      ) : plans.isLoading ? (
        <Skeleton height={180} />
      ) : (
        <View style={{ gap: space.lg, marginTop: space.md }}>
          {plans.data?.map((p) => (
            <Card key={p.id} style={{ gap: space.sm }}>
              <Text style={type.h2}>{pick(p, 'name', locale)}</Text>
              <Text style={[type.h3, { color: colors.brand }]}>{t('plan.perYear', { price: money(p.price, p.currency, locale), months: p.durationMonths })}</Text>
              {!!pick(p, 'description', locale) && <Text style={type.body}>{pick(p, 'description', locale)}</Text>}
              <View style={{ flexDirection: 'row', gap: space.sm, flexWrap: 'wrap', marginVertical: space.xs }}>
                <Pill label={t('plan.visits', { n: p.visitsPerYear })} tone="brand" />
                <Pill label={t('plan.units', { n: p.maxUnits })} tone="brand" />
              </View>
              {!owned.has(p.id) && <Button title={t('plan.request')} onPress={() => request(p)} loading={busy === p.id} variant="secondary" />}
            </Card>
          ))}
        </View>
      )}
    </Screen>
  );
}
