import { MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useRef, useState } from 'react';
import { FlatList, Pressable, Text, useWindowDimensions, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useI18n, type Locale } from '@/i18n';
import { Button, type IconName } from '@/components/ui';
import { colors, radius, space, type } from '@/theme';

const SLIDES: { key: string; icon: IconName }[] = [
  { key: 's1', icon: 'air-conditioner' },
  { key: 's2', icon: 'fridge-outline' },
  { key: 's3', icon: 'file-check-outline' },
];

export default function Onboarding() {
  const { t, locale, setLocale } = useI18n();
  const { width } = useWindowDimensions();
  const [step, setStep] = useState<'language' | number>('language');
  const list = useRef<FlatList>(null);

  const finish = () => router.replace('/login');

  if (step === 'language') {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.brand }}>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', gap: space.md, paddingHorizontal: space.xl }}>
          <View style={{ width: 88, height: 88, borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.14)', alignItems: 'center', justifyContent: 'center' }}>
            <MaterialCommunityIcons name="snowflake" size={56} color={colors.white} />
          </View>
          <Text style={{ fontSize: 34, fontWeight: '800', color: colors.white, letterSpacing: -0.5 }}>CoolCare</Text>
          <Text style={{ fontSize: 16, color: colors.brandSoft }}>{t('app.tagline')}</Text>
        </View>
        <View style={{ backgroundColor: colors.white, borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: space.xl, gap: space.md }}>
          <Text style={[type.h2, { marginBottom: space.sm }]}>{t('onb.chooseLanguage')}</Text>
          {(['so', 'en'] as Locale[]).map((l) => (
            <Pressable
              key={l}
              onPress={() => setLocale(l)}
              accessibilityRole="radio"
              accessibilityState={{ selected: locale === l }}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: space.lg,
                borderRadius: radius.md,
                borderWidth: 1.5,
                borderColor: locale === l ? colors.brand : colors.line,
                backgroundColor: locale === l ? colors.brandSoft : colors.white,
              }}
            >
              <Text style={{ fontSize: 17, fontWeight: '600', color: colors.navy }}>{l === 'so' ? 'Af-Soomaali' : 'English'}</Text>
              <MaterialCommunityIcons name={locale === l ? 'radiobox-marked' : 'radiobox-blank'} size={22} color={locale === l ? colors.brand : colors.faint} />
            </Pressable>
          ))}
          <Button title={t('onb.continue')} onPress={() => setStep(0)} style={{ marginTop: space.md }} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
      <View style={{ alignItems: 'flex-end', paddingHorizontal: space.lg }}>
        <Button title={t('onb.skip')} variant="ghost" onPress={finish} />
      </View>
      <FlatList
        ref={list}
        data={SLIDES}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(s) => s.key}
        onMomentumScrollEnd={(e) => setStep(Math.round(e.nativeEvent.contentOffset.x / width))}
        renderItem={({ item }) => (
          <View style={{ width, paddingHorizontal: space.xl, justifyContent: 'center', gap: space.lg }}>
            <View style={{ width: 120, height: 120, borderRadius: 32, backgroundColor: colors.brandSoft, alignItems: 'center', justifyContent: 'center' }}>
              <MaterialCommunityIcons name={item.icon} size={64} color={colors.brand} />
            </View>
            <Text style={type.title}>{t(`onb.${item.key}.title`)}</Text>
            <Text style={[type.body, { fontSize: 17, lineHeight: 26, color: colors.navy700 }]}>{t(`onb.${item.key}.body`)}</Text>
          </View>
        )}
      />
      <View style={{ padding: space.xl, gap: space.lg }}>
        <View style={{ flexDirection: 'row', gap: 6 }} accessibilityLabel={`${Number(step) + 1} / ${SLIDES.length}`}>
          {SLIDES.map((s, i) => (
            <View key={s.key} style={{ height: 6, width: i === step ? 24 : 6, borderRadius: 3, backgroundColor: i === step ? colors.brand : colors.line }} />
          ))}
        </View>
        <Button
          title={step === SLIDES.length - 1 ? t('onb.getStarted') : t('onb.continue')}
          onPress={() => {
            const next = Number(step) + 1;
            if (next >= SLIDES.length) return finish();
            list.current?.scrollToIndex({ index: next });
            setStep(next);
          }}
        />
      </View>
    </SafeAreaView>
  );
}
