import { useQueryClient } from '@tanstack/react-query';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useEquipment } from '@/lib/hooks';
import { Banner, Button, Choice, errorText, Field, Screen } from '@/components/ui';
import { space, type } from '@/theme';

const TYPES = ['SPLIT_AC', 'WINDOW_AC', 'CENTRAL_AC', 'PORTABLE_AC', 'REFRIGERATOR', 'FREEZER', 'COLD_ROOM', 'WATER_COOLER', 'OTHER'];

export default function EditEquipment() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { t } = useI18n();
  const qc = useQueryClient();
  const existing = useEquipment().data?.find((e) => e.id === id);
  const [f, setF] = useState({
    type: existing?.type ?? 'SPLIT_AC',
    brand: existing?.brand ?? '',
    model: existing?.model ?? '',
    capacity: existing?.capacity ?? '',
    location: existing?.location ?? '',
  });
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    setError('');
    try {
      const body = {
        type: f.type,
        brand: f.brand.trim() || undefined,
        model: f.model.trim() || undefined,
        capacity: f.capacity.trim() || undefined,
        location: f.location.trim() || undefined,
      };
      if (existing) await api(`/me/equipment/${existing.id}`, { method: 'PATCH', body });
      else await api('/me/equipment', { body });
      await qc.invalidateQueries({ queryKey: ['equipment'] });
      router.back();
    } catch (err) {
      setError(errorText(err, t));
    } finally {
      setSaving(false);
    }
  };

  const remove = () =>
    Alert.alert(t('eq.deleteConfirm'), undefined, [
      { text: t('common.cancel'), style: 'cancel' },
      {
        text: t('common.delete'),
        style: 'destructive',
        onPress: async () => {
          await api(`/me/equipment/${existing!.id}`, { method: 'DELETE' }).catch(() => undefined);
          await qc.invalidateQueries({ queryKey: ['equipment'] });
          router.back();
        },
      },
    ]);

  return (
    <Screen footer={<Button title={t('common.save')} onPress={save} loading={saving} />}>
      <Stack.Screen options={{ title: existing ? t('common.edit') : t('eq.new') }} />
      <Text style={[type.label, { marginBottom: space.sm }]}>{t('eq.type')}</Text>
      <Choice value={f.type} onChange={(v) => setF({ ...f, type: v })} options={TYPES.map((x) => ({ value: x, label: t(`equip.${x}`) }))} />
      <View style={{ marginTop: space.xl }}>
        <Field label={t('eq.brand')} optional optionalLabel={t('common.optional')} placeholder="Gree, LG, Samsung…" value={f.brand} onChangeText={(v) => setF({ ...f, brand: v })} />
        <Field label={t('eq.model')} optional optionalLabel={t('common.optional')} value={f.model} onChangeText={(v) => setF({ ...f, model: v })} />
        <Field label={t('eq.capacity')} optional optionalLabel={t('common.optional')} placeholder={t('eq.capacityHint')} value={f.capacity} onChangeText={(v) => setF({ ...f, capacity: v })} />
        <Field label={t('eq.location')} optional optionalLabel={t('common.optional')} placeholder={t('eq.locationHint')} value={f.location} onChangeText={(v) => setF({ ...f, location: v })} />
      </View>
      {!!error && (
        <Banner tone="bad" icon="alert-circle-outline">
          {error}
        </Banner>
      )}
      {existing && <Button title={t('common.delete')} variant="danger" onPress={remove} style={{ marginTop: space.lg }} />}
    </Screen>
  );
}
