import { MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { useEquipment } from '@/lib/hooks';
import { Button, Card, EmptyState, ErrorView, errorText, Screen, Skeleton } from '@/components/ui';
import { colors, space, type } from '@/theme';

export default function EquipmentList() {
  const { t } = useI18n();
  const q = useEquipment();
  return (
    <Screen refreshing={q.isRefetching} onRefresh={() => q.refetch()} footer={<Button title={t('eq.new')} icon="plus" onPress={() => router.push('/equipment/edit')} />}>
      {q.isError ? (
        <ErrorView message={errorText(q.error, t)} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />
      ) : q.isLoading ? (
        <Skeleton height={72} />
      ) : q.data?.length ? (
        <View style={{ gap: space.md }}>
          {q.data.map((e) => (
            <Card key={e.id} onPress={() => router.push({ pathname: '/equipment/edit', params: { id: e.id } })}>
              <View style={{ flexDirection: 'row', gap: space.md, alignItems: 'center' }}>
                <MaterialCommunityIcons name={e.type.includes('AC') ? 'air-conditioner' : 'fridge-outline'} size={26} color={colors.brand} />
                <View style={{ flex: 1 }}>
                  <Text style={type.h3}>{t(`equip.${e.type}`)}</Text>
                  <Text style={type.small}>{[e.brand, e.model, e.capacity, e.location].filter(Boolean).join(' · ')}</Text>
                </View>
                <MaterialCommunityIcons name="chevron-right" size={22} color={colors.faint} />
              </View>
            </Card>
          ))}
        </View>
      ) : (
        <EmptyState icon="air-conditioner" title={t('eq.empty')} />
      )}
    </Screen>
  );
}
