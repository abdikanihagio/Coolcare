import Constants from 'expo-constants';
import { router } from 'expo-router';
import { Alert, Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { errorText, ListItem, Screen } from '@/components/ui';
import { colors, radius, space, type } from '@/theme';

export default function Account() {
  const { t, locale } = useI18n();
  const { user, logout } = useAuth();

  const confirmLogout = () =>
    Alert.alert(t('acc.logoutConfirm'), undefined, [
      { text: t('common.cancel'), style: 'cancel' },
      { text: t('acc.logout'), style: 'destructive', onPress: () => logout().then(() => router.replace('/login')) },
    ]);

  const confirmDelete = () =>
    Alert.alert(t('acc.delete'), t('acc.deleteConfirm'), [
      { text: t('common.cancel'), style: 'cancel' },
      {
        text: t('common.delete'),
        style: 'destructive',
        onPress: async () => {
          try {
            await api('/me', { method: 'DELETE' });
            await logout();
            router.replace('/login');
          } catch (err) {
            Alert.alert(t('acc.delete'), errorText(err, t));
          }
        },
      },
    ]);

  return (
    <Screen padded={false}>
      <View style={{ padding: space.lg, flexDirection: 'row', alignItems: 'center', gap: space.md }}>
        <View style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: colors.brandSoft, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 20, fontWeight: '700', color: colors.brand }}>
            {user?.fullName
              .split(' ')
              .slice(0, 2)
              .map((p) => p[0])
              .join('')
              .toUpperCase()}
          </Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={type.h2}>{user?.fullName}</Text>
          <Text style={type.small}>{user?.phone}</Text>
        </View>
      </View>

      <View style={{ marginHorizontal: space.lg, borderRadius: radius.lg, overflow: 'hidden', borderWidth: 1, borderColor: colors.line }}>
        <ListItem icon="account-edit-outline" title={t('acc.editProfile')} onPress={() => router.push('/profile')} />
        <ListItem icon="map-marker-outline" title={t('acc.addresses')} onPress={() => router.push('/addresses')} />
        <ListItem icon="air-conditioner" title={t('acc.equipment')} onPress={() => router.push('/equipment')} />
        <ListItem icon="calendar-check-outline" title={t('acc.plans')} onPress={() => router.push('/plans')} />
      </View>

      <View style={{ margin: space.lg, borderRadius: radius.lg, overflow: 'hidden', borderWidth: 1, borderColor: colors.line }}>
        <ListItem icon="translate" title={t('acc.language')} subtitle={locale === 'so' ? 'Af-Soomaali' : 'English'} onPress={() => router.push('/language')} />
        <ListItem icon="lifebuoy" title={t('acc.support')} onPress={() => router.push('/support')} />
        <ListItem icon="lock-reset" title={t('acc.changePassword')} onPress={() => router.push('/password')} />
      </View>

      <View style={{ marginHorizontal: space.lg, borderRadius: radius.lg, overflow: 'hidden', borderWidth: 1, borderColor: colors.line }}>
        <ListItem icon="logout" title={t('acc.logout')} onPress={confirmLogout} right={<View />} />
        <ListItem icon="account-remove-outline" title={t('acc.delete')} danger onPress={confirmDelete} right={<View />} />
      </View>

      <Text style={[type.small, { textAlign: 'center', marginTop: space.xl }]}>{t('acc.version', { v: Constants.expoConfig?.version ?? '1.0.0' })}</Text>
    </Screen>
  );
}
