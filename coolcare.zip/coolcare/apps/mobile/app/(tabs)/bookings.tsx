import { useInfiniteQuery } from '@tanstack/react-query';
import { router } from 'expo-router';
import { useState } from 'react';
import { ActivityIndicator, FlatList, RefreshControl, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import type { Booking, Paginated } from '@/lib/types';
import { BookingCard } from '@/components/booking-card';
import { Button, Choice, EmptyState, ErrorView, errorText, Skeleton } from '@/components/ui';
import { colors, space } from '@/theme';

export default function Bookings() {
  const { t } = useI18n();
  const [scope, setScope] = useState<'active' | 'past'>('active');
  const q = useInfiniteQuery({
    queryKey: ['bookings', scope, 'list'],
    queryFn: ({ pageParam }) => api<Paginated<Booking>>('/bookings', { query: { scope, page: pageParam, pageSize: 15 } }),
    initialPageParam: 1,
    getNextPageParam: (last) => (last.meta.page < last.meta.totalPages ? last.meta.page + 1 : undefined),
  });
  const rows = q.data?.pages.flatMap((p) => p.data) ?? [];

  return (
    <View style={{ flex: 1 }}>
      <View style={{ paddingHorizontal: space.lg, paddingTop: space.sm, paddingBottom: space.md }}>
        <Choice
          value={scope}
          onChange={setScope}
          options={[
            { value: 'active', label: t('bk.active') },
            { value: 'past', label: t('bk.past') },
          ]}
        />
      </View>
      {q.isError ? (
        <ErrorView message={errorText(q.error, t)} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />
      ) : q.isLoading ? (
        <View style={{ padding: space.lg, gap: space.md }}>
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} height={110} />
          ))}
        </View>
      ) : (
        <FlatList
          data={rows}
          keyExtractor={(b) => b.id}
          contentContainerStyle={{ padding: space.lg, paddingTop: 0, gap: space.md, flexGrow: 1 }}
          renderItem={({ item }) => <BookingCard booking={item} />}
          refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => q.refetch()} tintColor={colors.brand} />}
          onEndReached={() => q.hasNextPage && !q.isFetchingNextPage && q.fetchNextPage()}
          onEndReachedThreshold={0.4}
          ListFooterComponent={q.isFetchingNextPage ? <ActivityIndicator color={colors.brand} /> : null}
          ListEmptyComponent={
            <EmptyState
              icon="clipboard-text-outline"
              title={t('bk.empty')}
              body={t('bk.emptyBody')}
              action={<Button title={t('bk.bookNow')} onPress={() => router.push('/home')} />}
            />
          }
        />
      )}
    </View>
  );
}
