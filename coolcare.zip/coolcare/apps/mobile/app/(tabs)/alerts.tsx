import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import { router, useNavigation } from 'expo-router';
import { useLayoutEffect } from 'react';
import { FlatList, Pressable, RefreshControl, Text, View } from 'react-native';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { dateTime } from '@/lib/format';
import type { Notification, Paginated } from '@/lib/types';
import { Button, EmptyState, ErrorView, errorText, Skeleton } from '@/components/ui';
import { colors, space, type } from '@/theme';

export default function Alerts() {
  const { t, locale } = useI18n();
  const qc = useQueryClient();
  const navigation = useNavigation();
  const q = useInfiniteQuery({
    queryKey: ['notifications'],
    queryFn: ({ pageParam }) => api<Paginated<Notification> & { unread: number }>('/notifications', { query: { page: pageParam, pageSize: 20 } }),
    initialPageParam: 1,
    getNextPageParam: (last) => (last.meta.page < last.meta.totalPages ? last.meta.page + 1 : undefined),
  });
  const rows = q.data?.pages.flatMap((p) => p.data) ?? [];
  const unread = q.data?.pages[0]?.unread ?? 0;

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['notifications'] });
    qc.invalidateQueries({ queryKey: ['notifications-unread'] });
  };

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () =>
        unread > 0 ? <Button title={t('notif.markAll')} variant="ghost" onPress={() => api('/notifications/read-all', { method: 'PATCH' }).then(refresh)} /> : null,
    });
  });

  const open = async (n: Notification) => {
    if (!n.readAt) api(`/notifications/${n.id}/read`, { method: 'PATCH' }).then(refresh).catch(() => undefined);
    if (n.data?.bookingId) router.push(`/booking/${n.data.bookingId}`);
  };

  if (q.isError) return <ErrorView message={errorText(q.error, t)} onRetry={() => q.refetch()} retryLabel={t('common.retry')} />;
  if (q.isLoading)
    return (
      <View style={{ padding: space.lg, gap: space.md }}>
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} height={64} />
        ))}
      </View>
    );

  return (
    <FlatList
      data={rows}
      keyExtractor={(n) => n.id}
      contentContainerStyle={{ flexGrow: 1 }}
      ItemSeparatorComponent={() => <View style={{ height: 1, backgroundColor: colors.line }} />}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => q.refetch()} tintColor={colors.brand} />}
      onEndReached={() => q.hasNextPage && q.fetchNextPage()}
      renderItem={({ item: n }) => (
        <Pressable
          onPress={() => open(n)}
          accessibilityRole="button"
          style={({ pressed }) => ({ flexDirection: 'row', gap: space.md, padding: space.lg, backgroundColor: pressed ? colors.surface : n.readAt ? colors.white : colors.brandSoft })}
        >
          <View style={{ width: 8, height: 8, borderRadius: 4, marginTop: 7, backgroundColor: n.readAt ? 'transparent' : colors.brand }} />
          <View style={{ flex: 1, gap: 2 }}>
            <Text style={[type.h3, { fontWeight: n.readAt ? '500' : '700' }]}>{n.title}</Text>
            <Text style={[type.body, { color: colors.navy700 }]}>{n.body}</Text>
            <Text style={type.small}>{dateTime(n.createdAt, locale)}</Text>
          </View>
        </Pressable>
      )}
      ListEmptyComponent={<EmptyState icon="bell-outline" title={t('notif.empty')} body={t('notif.emptyBody')} />}
    />
  );
}
