import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { Redirect, Tabs } from 'expo-router';
import { useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { colors } from '@/theme';

export default function TabsLayout() {
  const { user } = useAuth();
  const { t } = useI18n();
  const unread = useQuery({
    queryKey: ['notifications-unread'],
    queryFn: () => api<{ unread: number }>('/notifications', { query: { pageSize: 1 } }),
    enabled: !!user,
    refetchInterval: 60_000,
  });

  if (!user) return <Redirect href="/login" />;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.brand,
        tabBarInactiveTintColor: colors.muted,
        tabBarLabelStyle: { fontSize: 12, fontWeight: '600' },
        tabBarStyle: { borderTopColor: colors.line, backgroundColor: colors.white },
        headerShadowVisible: false,
        headerStyle: { backgroundColor: colors.surface },
        headerTitleStyle: { fontWeight: '700', color: colors.navy },
        sceneStyle: { backgroundColor: colors.surface },
      }}
    >
      <Tabs.Screen
        name="home"
        options={{ title: t('tabs.home'), headerShown: false, tabBarIcon: ({ color, size }) => <MaterialCommunityIcons name="snowflake" color={color} size={size} /> }}
      />
      <Tabs.Screen
        name="bookings"
        options={{ title: t('tabs.bookings'), tabBarIcon: ({ color, size }) => <MaterialCommunityIcons name="clipboard-text-clock-outline" color={color} size={size} /> }}
      />
      <Tabs.Screen
        name="alerts"
        options={{
          title: t('tabs.alerts'),
          tabBarBadge: unread.data?.unread ? Math.min(unread.data.unread, 99) : undefined,
          tabBarIcon: ({ color, size }) => <MaterialCommunityIcons name="bell-outline" color={color} size={size} />,
        }}
      />
      <Tabs.Screen
        name="account"
        options={{ title: t('tabs.account'), tabBarIcon: ({ color, size }) => <MaterialCommunityIcons name="account-circle-outline" color={color} size={size} /> }}
      />
    </Tabs>
  );
}
