import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import { Linking, Pressable, Text, TextInput, View } from 'react-native';
import { pick, useI18n } from '@/i18n';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { priceLabel } from '@/lib/service';
import { useCatalog, usePublicSettings } from '@/lib/hooks';
import type { Booking, Paginated, Service } from '@/lib/types';
import { BookingCard } from '@/components/booking-card';
import { Button, Card, ErrorView, errorText, Screen, SectionTitle, ServiceIcon, Skeleton } from '@/components/ui';
import { colors, radius, space, type } from '@/theme';

export default function Home() {
  const { t, locale } = useI18n();
  const { user } = useAuth();
  const catalog = useCatalog();
  const settings = usePublicSettings();
  const active = useQuery({ queryKey: ['bookings', 'active'], queryFn: () => api<Paginated<Booking>>('/bookings', { query: { scope: 'active', pageSize: 3 } }) });
  const [search, setSearch] = useState('');

  const results = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return null;
    return (catalog.data ?? []).flatMap((c) => c.services.map((s) => ({ ...s, icon: c.icon }))).filter((s) => `${s.nameEn} ${s.nameSo}`.toLowerCase().includes(q));
  }, [search, catalog.data]);

  const firstName = user?.fullName.split(' ')[0] ?? '';

  return (
    <Screen edges={['top']} refreshing={catalog.isRefetching || active.isRefetching} onRefresh={() => (catalog.refetch(), active.refetch())}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: space.sm }}>
        <View style={{ flex: 1 }}>
          <Text style={type.small}>{t('home.greeting', { name: firstName })}</Text>
          <Text style={[type.title, { marginTop: 2 }]}>{t('home.question')}</Text>
        </View>
      </View>

      <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm, backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, paddingHorizontal: space.md, marginTop: space.lg }}>
        <MaterialCommunityIcons name="magnify" size={22} color={colors.muted} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder={t('home.search')}
          placeholderTextColor={colors.faint}
          style={{ flex: 1, height: 50, fontSize: 16, color: colors.navy }}
          accessibilityLabel={t('home.search')}
          returnKeyType="search"
        />
      </View>

      {results ? (
        <View style={{ marginTop: space.lg, gap: space.sm }}>
          {results.map((s) => (
            <ServiceRow key={s.id} service={s} icon={s.icon} />
          ))}
        </View>
      ) : (
        <>
          {!!active.data?.data.length && (
            <>
              <SectionTitle>{t('home.active')}</SectionTitle>
              <View style={{ gap: space.md }}>
                {active.data.data.map((b) => (
                  <BookingCard key={b.id} booking={b} />
                ))}
              </View>
            </>
          )}

          {catalog.isError ? (
            <ErrorView message={errorText(catalog.error, t)} onRetry={() => catalog.refetch()} retryLabel={t('common.retry')} />
          ) : catalog.isLoading ? (
            <View style={{ gap: space.md, marginTop: space.xl }}>
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} height={72} />
              ))}
            </View>
          ) : (
            catalog.data?.map((c) => (
              <View key={c.id}>
                <SectionTitle>{pick(c, 'name', locale)}</SectionTitle>
                <View style={{ gap: space.sm }}>
                  {c.services.map((s) => (
                    <ServiceRow key={s.id} service={s} icon={c.icon} />
                  ))}
                </View>
              </View>
            ))
          )}

          <Card style={{ marginTop: space.xl, backgroundColor: colors.navy, borderColor: colors.navy, gap: space.sm }}>
            <Text style={[type.h3, { color: colors.white }]}>{t('home.plansTitle')}</Text>
            <Text style={[type.body, { color: '#BCCCDC' }]}>{t('home.plansBody')}</Text>
            <Button title={t('home.seePlans')} variant="secondary" onPress={() => router.push('/plans')} style={{ marginTop: space.sm, alignSelf: 'flex-start' }} />
          </Card>

          {settings.data?.supportPhone && (
            <Button
              title={t('home.emergency')}
              icon="phone"
              variant="ghost"
              onPress={() => Linking.openURL(`tel:${settings.data!.supportPhone}`)}
              style={{ marginTop: space.lg }}
            />
          )}
        </>
      )}
    </Screen>
  );
}

function ServiceRow({ service, icon }: { service: Service; icon?: string }) {
  const { t, locale } = useI18n();
  return (
    <Pressable
      onPress={() => router.push(`/service/${service.id}`)}
      accessibilityRole="button"
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'center',
        gap: space.md,
        padding: space.md,
        backgroundColor: pressed ? colors.brandSoft : colors.white,
        borderRadius: radius.md,
        borderWidth: 1,
        borderColor: colors.line,
      })}
    >
      <ServiceIcon icon={icon} />
      <View style={{ flex: 1 }}>
        <Text style={type.h3}>{pick(service, 'name', locale)}</Text>
        <Text style={type.small}>{priceLabel(service, t, locale)}</Text>
      </View>
      <MaterialCommunityIcons name="chevron-right" size={22} color={colors.faint} />
    </Pressable>
  );
}
