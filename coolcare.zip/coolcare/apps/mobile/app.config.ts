import type { ExpoConfig } from 'expo/config';
import { existsSync } from 'node:fs';

const googleServices = process.env.GOOGLE_SERVICES_JSON ?? './google-services.json';

const BRAND_BLUE = '#1677C8';

const config: ExpoConfig = {
  name: 'CoolCare',
  slug: 'coolcare',
  scheme: 'coolcare',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/icon.png',
  userInterfaceStyle: 'light',
  newArchEnabled: true,
  ios: {
    bundleIdentifier: 'so.coolcare.app',
    supportsTablet: true,
    config: { googleMapsApiKey: process.env.EXPO_PUBLIC_GOOGLE_MAPS_API_KEY },
    infoPlist: {
      NSLocationWhenInUseUsageDescription: 'CoolCare uses your location so the technician can find your address.',
      NSCameraUsageDescription: 'Take photos of the unit so the technician can prepare.',
      NSPhotoLibraryUsageDescription: 'Attach photos of the unit to your booking.',
    },
  },
  android: {
    package: 'so.coolcare.app',
    adaptiveIcon: { foregroundImage: './assets/adaptive-icon.png', backgroundColor: BRAND_BLUE },
    edgeToEdgeEnabled: true,
    permissions: ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'CAMERA', 'POST_NOTIFICATIONS'],
    config: { googleMaps: { apiKey: process.env.EXPO_PUBLIC_GOOGLE_MAPS_API_KEY } },
    // Place google-services.json from your Firebase project in apps/mobile to enable FCM push
    ...(existsSync(googleServices) ? { googleServicesFile: googleServices } : {}),
  },
  web: { favicon: './assets/favicon.png' },
  plugins: [
    'expo-router',
    'expo-secure-store',
    'expo-localization',
    [
      'expo-splash-screen',
      { image: './assets/splash-icon.png', imageWidth: 160, resizeMode: 'contain', backgroundColor: BRAND_BLUE },
    ],
    ['expo-notifications', { icon: './assets/notification-icon.png', color: BRAND_BLUE }],
    ['expo-location', { locationWhenInUsePermission: 'CoolCare uses your location so the technician can find your address.' }],
    ['expo-image-picker', { photosPermission: 'Attach photos of the unit to your booking.', cameraPermission: 'Take photos of the unit so the technician can prepare.' }],
  ],
  experiments: { typedRoutes: false },
  extra: {
    apiUrl: process.env.EXPO_PUBLIC_API_URL,
    eas: { projectId: process.env.EAS_PROJECT_ID },
  },
};

export default config;
