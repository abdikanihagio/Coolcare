# CoolCare

**Comfort You Can Count On.** A cooling, air-conditioning, refrigeration and maintenance service platform for Mogadishu, built to expand to more cities and branches.

| App | Stack | Folder |
| --- | --- | --- |
| Customer mobile app (Android & iOS) | Expo SDK 54, React Native 0.81, Expo Router, TypeScript | `apps/mobile` |
| Admin dashboard (web) | Next.js 15, React 19, Tailwind CSS 4, TanStack Query | `apps/admin` |
| REST API | NestJS 11, Prisma 6, PostgreSQL 16, Swagger | `apps/api` |

Both apps talk to the same API and database. There is no technician app: staff update job progress for technicians from the dashboard.

---

## Quick start (Docker)

```bash
cp .env.example .env
# Edit .env — at minimum set POSTGRES_PASSWORD, STORAGE_SECRET_KEY,
# JWT_ACCESS_SECRET, JWT_REFRESH_SECRET and SEED_ADMIN_PASSWORD.
#   openssl rand -base64 48   # use for each JWT secret

npm install                      # creates package-lock.json for the Docker builds
docker compose up -d --build     # postgres, minio, api (runs migrations), admin
docker compose exec api npx prisma db seed   # catalog, plans, settings, super admin
```

| Service | URL |
| --- | --- |
| Admin dashboard | http://localhost:3000 — sign in with `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` |
| API | http://localhost:4000/api/v1 |
| API docs (Swagger) | http://localhost:4000/api/docs |
| MinIO console | http://localhost:9001 |

To also load demo technicians and a demo customer (`+252 61 555 9999` / `Demo1234`), run the seed with `SEED_DEMO=true`.

## Local development (without Docker for the apps)

```bash
cp .env.example .env
docker compose up -d postgres minio minio-init
npm install
npm run db:migrate && npm run db:seed
npm run dev:api        # http://localhost:4000
npm run dev:admin      # http://localhost:3000
```

### Mobile app

The mobile app is a standalone Expo project (not an npm workspace, which keeps Metro simple).

```bash
cd apps/mobile
cp .env.example .env   # set EXPO_PUBLIC_API_URL to your computer's LAN IP, e.g. http://192.168.1.10:4000/api/v1
npm install
npx expo install --fix # aligns native module versions with the installed Expo SDK
npx expo start         # scan the QR code with Expo Go, or press a / i
```

Maps and push notifications need a development build (`npx expo run:android` or `eas build --profile development`), not Expo Go. See [docs/PUSH_NOTIFICATIONS.md](docs/PUSH_NOTIFICATIONS.md).

## Testing

```bash
npm test                         # API unit tests (Jest) + admin unit tests (Vitest)
npm run test:e2e -w apps/api     # API booking flow against a real database (see file header)
npm run test:e2e:admin           # Playwright: set ADMIN_EMAIL / ADMIN_PASSWORD
cd apps/mobile && npm test       # jest-expo + React Native Testing Library
npm run typecheck                # all three apps
```

The end-to-end API test walks the full workflow: register → add address → book → assign technician → on the way → in progress → quotation → customer approves → complete → invoice issued → EVC Plus payment → rating.

---

## How the workflow fits together

```
Customer app                    API                             Admin dashboard
────────────                    ───                             ───────────────
Book service ─────────────────► Booking PENDING ──notify staff──► New request (badge)
                                                                 Confirm ▸ Assign technician
Push: "Technician assigned" ◄── ASSIGNED ◄──────────────────────┘
Push: "On the way" ◄─────────── ON_THE_WAY ◄──────────────────── Mark on the way
                                IN_PROGRESS ◄─────────────────── Start work
Push: "Quotation ready" ◄────── AWAITING_APPROVAL ◄───────────── Send quotation (line items)
Approve quotation ────────────► IN_PROGRESS ──notify staff────►
Push: "Job completed" ◄──────── COMPLETED ◄──────────────────── Complete (invoice auto-issued)
Pay by EVC Plus (txn ID) ─────► Payment PENDING ──────────────► Verify ▸ Confirm received
Push: "Payment received" ◄───── Invoice PAID
Rate technician ──────────────► Technician rating updated
```

Status changes are validated by a single state machine (`apps/api/src/bookings/booking-status.ts`) and every change is written to the booking timeline and the audit log.

## What's included

**Customer app** — language choice (Somali/English) and onboarding; registration, OTP verification, login, password reset; service catalog with search; booking with saved address, 14-day date picker, live slot availability, appliance, unit count, urgency, problem description and photos; booking tracking with progress timeline, technician contact, quotation approval/decline, rescheduling, cancellation, invoice and mobile-money payment submission, rating; notifications with push; saved addresses with district picker, GPS and map pin; appliances; maintenance plans; profile, password, language, support, account deletion.

**Admin dashboard** — today's dispatch board grouped by time slot, KPIs, bookings and revenue trend, top services, technician performance; bookings table with search, status/date filters, sorting and pagination; booking detail with status actions, technician assignment with daily workload, rescheduling, internal notes, before/after photos, quotation builder, invoice, payments and timeline; customers; technicians; services and categories (bilingual); quotations; printable invoices; payments with mobile-money verification and refunds; maintenance plans, subscriber activation and visit scheduling; notification centre and broadcast; staff and roles; company settings and branches; activity log. Fully translated into Somali.

**API** — JWT access tokens + rotating refresh tokens with reuse detection, phone OTP, bcrypt passwords, role-based access (super admin, admin, dispatcher, accountant), rate limiting, validation, Swagger, S3-compatible uploads, FCM push, pluggable SMS gateway, bilingual notification templates, daily maintenance reminders, audit log, reports.

## Configuration notes

- **Currency and timezone** — USD and `Africa/Mogadishu` by default; both are editable in Settings, and each branch has its own.
- **SMS / OTP** — `SMS_PROVIDER=console` logs codes to the API log for development. Set `http` and adapt `apps/api/src/notifications/sms.provider.ts` for your gateway. `none` turns OTP off.
- **Payments** — EVC Plus, ZAAD, Sahal, eDahab and bank transfers are recorded with their transaction ID. Customers can submit a transaction ID from the app; staff confirm it after checking the statement. Direct merchant-API integration can be added in `billing.ts`.
- **Secrets** — nothing sensitive is hard-coded; the API refuses to start in production with weak JWT secrets.

## Documentation

- [docs/ASSUMPTIONS.md](docs/ASSUMPTIONS.md) — decisions made where the brief was incomplete
- [docs/API.md](docs/API.md) — endpoint overview (full reference at `/api/docs`)
- [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) — production checklist
- [docs/PUSH_NOTIFICATIONS.md](docs/PUSH_NOTIFICATIONS.md) — Firebase setup
- [docs/TRANSLATIONS.md](docs/TRANSLATIONS.md) — editing Somali/English copy
