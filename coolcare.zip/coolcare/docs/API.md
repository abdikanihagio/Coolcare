# API overview

Base URL: `/api/v1`. Interactive reference with request/response schemas: `/api/docs`.

Authenticate with `Authorization: Bearer <accessToken>`. Access tokens last 15 minutes; exchange the refresh token at `POST /auth/refresh` (refresh tokens rotate on every use, and reusing an old one signs out every session). Errors use `{ statusCode, message, error }`. Money is returned as decimal strings.

## Public
| Method | Path | Purpose |
| --- | --- | --- |
| GET | /health | Liveness + database check |
| GET | /auth/config | Whether OTP is enforced |
| POST | /auth/register, /auth/login | Customer sign-up / sign-in (may return `requiresOtp`) |
| POST | /auth/otp/request, /auth/otp/verify | Phone verification |
| POST | /auth/password/forgot, /auth/password/reset | Reset by SMS code |
| POST | /auth/refresh, /auth/logout | Session management |
| POST | /auth/admin/login | Staff sign-in |
| GET | /catalog/categories, /catalog/services, /catalog/services/:idOrSlug | Service catalog |
| GET | /maintenance/plans, /branches, /settings/public | Plans, branches, public settings |

## Customer
| Method | Path | Purpose |
| --- | --- | --- |
| GET/PATCH/DELETE | /me | Profile, language, account deletion |
| POST/DELETE | /me/devices | Push token registration |
| CRUD | /me/addresses, /me/equipment | Saved addresses and appliances |
| GET | /bookings/availability?date= | Slot availability |
| POST/GET | /bookings | Create / list (`scope=active|past`) |
| GET | /bookings/:id | Detail with timeline, quotes, invoice |
| POST | /bookings/:id/cancel, /reschedule, /rate, /photos | Booking actions |
| POST | /quotes/:id/accept, /quotes/:id/reject | Respond to a quotation |
| GET | /invoices, /invoices/:id | Invoices |
| POST | /invoices/:id/payments | Submit a mobile-money payment for verification |
| GET/POST | /maintenance/subscriptions | My plans / request a plan |
| GET/PATCH | /notifications, /notifications/:id/read, /notifications/read-all | Notification centre |
| POST | /uploads/image?folder= | Multipart image upload (JPEG/PNG/WebP/HEIC, 8 MB) |

## Staff (`/admin/...`)
| Area | Endpoints |
| --- | --- |
| Bookings | list with filters, detail, create, update, `assign`, `status`, photos |
| Quotes | `bookings/:id/quotes`, `quotes/:id` (edit draft), `send`, delete |
| Billing | invoices, `bookings/:id/invoice`, `invoices/:id/payments`, `void`; payments, `confirm`, `reject`, `refund` |
| Customers | list, detail, `status` (suspend/activate) |
| Technicians | CRUD with workload (`?date=` returns jobs that day) |
| Catalog | categories and services CRUD |
| Maintenance | plans CRUD, subscriptions, `visits`, `run-reminders` |
| Reports | `reports/overview?from&to`, `reports/audit-logs` |
| Staff, branches, settings | `staff`, `branches`, `PATCH /settings` |
| Broadcast | `POST /notifications/broadcast` |
