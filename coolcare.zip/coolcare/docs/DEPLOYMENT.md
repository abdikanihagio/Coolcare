# Production checklist

1. **Secrets** — generate `JWT_ACCESS_SECRET` and `JWT_REFRESH_SECRET` with `openssl rand -base64 48`. Set strong database and storage passwords. Keep `.env` out of version control (it is git-ignored).
2. **Database** — use managed PostgreSQL 16 with daily backups. Migrations run automatically when the API container starts (`prisma migrate deploy`). Run the seed once.
3. **Storage** — point `STORAGE_*` at S3, Cloudflare R2 or DigitalOcean Spaces. Objects under `public/` must be publicly readable (booking photos are shown in both apps); set `STORAGE_PUBLIC_URL` to the CDN/bucket URL.
4. **HTTPS** — put the API and dashboard behind a TLS-terminating reverse proxy (Caddy, Nginx, or a load balancer). Set `CORS_ORIGINS` to the dashboard's domain.
5. **SMS** — set `SMS_PROVIDER=http` and adapt `sms.provider.ts` to your gateway. The API warns at startup if production still uses the console provider.
6. **Push** — set `FIREBASE_SERVICE_ACCOUNT_BASE64` (see PUSH_NOTIFICATIONS.md).
7. **Dashboard** — build with `NEXT_PUBLIC_API_URL=https://api.example.so/api/v1` (it is baked in at build time).
8. **Mobile** — set `EXPO_PUBLIC_API_URL` and `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY` as EAS environment variables, add `google-services.json`, then `eas build -p android --profile production` and `eas build -p ios --profile production`.
9. **Scaling** — the maintenance reminder job runs inside the API at 08:00 Mogadishu time. If you run more than one API replica, keep the job on one instance (or move it to a separate worker) so reminders are not sent twice.
10. **New city** — add a branch in Settings, add its districts, and assign staff and technicians to it.
