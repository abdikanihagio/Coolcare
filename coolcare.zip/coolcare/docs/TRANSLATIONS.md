# Translations

| App | Files |
| --- | --- |
| Admin dashboard | `apps/admin/src/lib/locales/en.json`, `so.json` |
| Mobile app | `apps/mobile/src/i18n/en.json`, `so.json` |
| Notifications and SMS (sent by the API) | `apps/api/src/notifications/templates.ts` |
| Service catalog, plans | Edited in the dashboard (each has English and Somali fields) |

- Keys are identical in both files; unit tests fail if a Somali string is missing or if notification placeholders differ between languages.
- Placeholders look like `{name}` and must be kept exactly.
- Users choose their language in the app; it is saved to their account so SMS and push notifications arrive in that language.
- Both languages are left-to-right. The apps set `dir`/`I18nManager` from a per-locale table (`LOCALE_DIR`, `LOCALE_RTL`) and use logical (start/end) layout, so adding an RTL language such as Arabic means adding the locale file and marking it RTL.
- The Somali copy was written for this project; have a native speaker review it, especially service and status names, before launch.
