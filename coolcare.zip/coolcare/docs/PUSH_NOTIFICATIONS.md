# Push notifications

The API sends push notifications through Firebase Cloud Messaging (FCM) and always stores an in-app copy, so customers still see updates in the Alerts tab if push is off.

## API
1. In the Firebase console, create a project and a service account key (Project settings → Service accounts → Generate new private key).
2. `base64 -w0 service-account.json` and put the result in `FIREBASE_SERVICE_ACCOUNT_BASE64`.
3. Restart the API; the log shows `Firebase Cloud Messaging ready`.

## Android
1. Add an Android app in Firebase with package `so.coolcare.app` and download `google-services.json` into `apps/mobile/`.
2. Build a development or production build (push does not work in Expo Go). The app registers its FCM token with `POST /me/devices` after sign-in.

## iOS
`expo-notifications` returns an APNs token on iOS. To deliver iOS pushes through FCM, either:
- add `@react-native-firebase/app` and `@react-native-firebase/messaging`, upload your APNs key to Firebase, and register `messaging().getToken()` instead of the device token in `apps/mobile/src/lib/push.ts`; or
- switch `push.provider.ts` to Expo's push service and register `getExpoPushTokenAsync()`.

Invalid tokens reported by FCM are deleted automatically.
