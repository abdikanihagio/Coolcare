# Assumptions and decisions

The project brief ended partway through section 5B (customer authentication). Everything after that point was designed from the earlier sections and standard practice for field-service platforms. Review these and adjust as needed.

## Product

- **Booking lifecycle**: `PENDING → CONFIRMED → ASSIGNED → ON_THE_WAY → IN_PROGRESS → (AWAITING_APPROVAL ↔ IN_PROGRESS) → COMPLETED`, with `CANCELLED` available until work starts. Customers may cancel until a technician is on the way (configurable in Settings).
- **Scheduling** uses three time slots per day (morning 8–12, afternoon 12–16, evening 16–19) with a per-slot capacity and a minimum notice period, rather than exact appointment times. This matches how field teams in Mogadishu typically plan routes.
- **Pricing**: services are fixed price, "from" price, or priced after inspection. The booking shows an estimate; extra work goes through a quotation that the customer approves in the app. Emergency bookings add a configurable surcharge.
- **Invoices** are issued automatically when a job is completed, from the accepted quotation or the estimate. Staff can void and re-issue.
- **Payments**: mobile money (EVC Plus, ZAAD, Sahal, eDahab), bank transfer, cash and card are recorded against invoices. Customers submit a mobile-money transaction ID; staff confirm it. No merchant API is called, because gateway contracts differ per company.
- **Maintenance plans**: customers request a plan in the app; staff activate it once the fee is collected and schedule each visit, which creates a normal booking at zero cost. Customers get a reminder a few days before each visit.
- **Addresses** are district-based (Mogadishu's 18 districts, editable) with a landmark field and an optional GPS pin, because street addresses are often not used.
- **Account deletion** anonymises personal data but keeps completed booking and invoice records for accounting.

## Technical

- **Password + phone OTP**: customers register with a password; the phone is verified by OTP whenever an SMS channel is configured. Password reset is by SMS code.
- **Staff roles**: Super admin, Admin, Dispatcher (bookings, technicians, maintenance), Accountant (invoices, payments). Super admin can do everything, including managing other admins.
- **Styling**: the brief allowed "NativeWind or an appropriate React Native styling solution". The mobile app uses a typed `StyleSheet` theme (`apps/mobile/src/theme.ts`) to avoid extra build configuration; the dashboard uses Tailwind CSS 4.
- **Mobile is not an npm workspace**: Expo and Metro work most reliably as a standalone project.
- **Somali translations** were written for this project and should be reviewed by a native speaker before launch.
- **Package versions** target Expo SDK 54, Next.js 15, NestJS 11 and Prisma 6. Packages could not be installed in the build environment, so run `npx expo install --fix` in `apps/mobile` after installing to align native module versions.
